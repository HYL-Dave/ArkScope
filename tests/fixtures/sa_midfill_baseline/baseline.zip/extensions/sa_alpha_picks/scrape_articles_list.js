// scrape_articles_list.js — Injected into SA Alpha Picks articles page
// Extracts ALL articles (with or without ticker).
// Returns: array of { article_id, url, title, ticker, date, comments_count, article_type }
//
// v3: Returns ALL articles (not just ticker-tagged).
// article_type auto-detected from title keywords.

(function () {
  "use strict";

  var links = document.querySelectorAll('a[href*="/alpha-picks/articles/"]');
  var seen = {};
  var articles = [];

  for (var i = 0; i < links.length; i++) {
    var a = links[i];
    var href = a.href.split("#")[0];
    var text = a.innerText.trim();

    if (!text || text.length < 15 || /^\d+\s*Comments?$/i.test(text)) continue;
    if (seen[href]) continue;
    seen[href] = true;

    // Extract article_id from URL: /alpha-picks/articles/6272753-... → "6272753"
    var idMatch = href.match(/\/articles\/(\d+)/);
    var articleId = idMatch ? idMatch[1] : null;
    if (!articleId) continue;

    // Find the enclosing <article> card
    var card = a.closest("article");
    if (!card) {
      card = a.parentElement;
      while (card && card.innerText.length < 100) card = card.parentElement;
    }
    var cardText = card ? card.innerText : "";

    // Extract date
    var dateMatch = cardText.match(
      /(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\.?\s+\d{1,2},\s+\d{4}/
    );
    var date = dateMatch ? dateMatch[0] : null;

    // Provider-owned identity is card-scoped and independent of title/body text.
    var ticker = ArkScopeArticleIdentity.extractListTicker(card, date);
    var observedAt = new Date().toISOString();

    // Extract comments count from comment label or post-date metadata.
    var comments = extractCommentsCount(card, cardText, date);
    var commentsObservedAt = comments.observed ? new Date().toISOString() : null;

    // Auto-detect article_type from title + ticker presence
    var articleType = detectArticleType(text, ticker);

    articles.push({
      article_id: articleId,
      url: href,
      title: text.substring(0, 200),
      ticker: ticker,
      list_ticker: ticker,
      list_ticker_observed_at: ticker ? observedAt : null,
      date: date,
      comments_count: comments.value,
      comments_count_observed_at: commentsObservedAt,
      article_type: articleType,
    });
  }

  return articles.length > 0
    ? articles
    : { error: "No articles found", total_links: links.length };

  function extractCommentsCount(card, cardText, date) {
    if (card) {
      var nodes = card.querySelectorAll("a, span, div, p, li, small, strong");
      for (var i = 0; i < nodes.length; i++) {
        var nodeText = normalizeInlineText(nodes[i].innerText || "");
        if (!nodeText) continue;
        var exactMatch = nodeText.match(/^(\d{1,5})\s*Comments?$/i);
        if (exactMatch) {
          return {
            value: sanitizeCommentsCount(parseInt(exactMatch[1], 10), date),
            observed: true,
          };
        }
      }
    }

    var searchText = cardText || "";
    if (date) {
      var dateIdx = searchText.indexOf(date);
      if (dateIdx >= 0) {
        searchText = searchText.substring(dateIdx + date.length);
      }
    }

    var count = extractCommentsCountFromText(searchText);
    if (count === null && searchText !== cardText) {
      count = extractCommentsCountFromText(cardText);
    }
    return {
      value: sanitizeCommentsCount(count, date),
      observed: count !== null,
    };
  }

  function extractCommentsCountFromText(text) {
    var normalized = normalizeInlineText(text);
    if (!normalized) return null;
    var match = normalized.match(/(?:^|\s)(\d{1,5})\s*Comments?\b/i);
    return match ? parseInt(match[1], 10) : null;
  }

  function sanitizeCommentsCount(count, date) {
    if (count == null || isNaN(count) || count < 0) return 0;
    var yearMatch = date && date.match(/(\d{4})$/);
    if (!yearMatch) return count;
    var yearText = yearMatch[1];
    var countText = String(count);
    if (count >= 10000 && countText.indexOf(yearText) === 0 && countText.length > yearText.length) {
      var suffix = parseInt(countText.slice(yearText.length), 10);
      if (!isNaN(suffix) && suffix >= 0 && suffix <= 9999) {
        return suffix;
      }
    }
    return count;
  }

  function normalizeInlineText(text) {
    return (text || "").replace(/\s+/g, " ").trim();
  }

  function detectArticleType(title, ticker) {
    var t = title.toLowerCase();
    if (t.indexOf("webinar") >= 0 || t.indexOf("transcript") >= 0) return "webinar";
    if (t.indexOf("market recap") >= 0 || t.indexOf("portfolio review") >= 0) return "recap";
    if (
      t.indexOf("sold") >= 0 ||
      t.indexOf("closing") >= 0 ||
      t.indexOf("removing") >= 0 ||
      t.indexOf("initial stake") >= 0
    )
      return "removal";
    if (t.indexOf("stock buy") >= 0 || t.indexOf("stock sell") >= 0) return "analysis";
    // Has ticker → likely analysis (stock-specific article)
    if (ticker) return "analysis";
    return "commentary";
  }
})();
