# Task6 Follow-up: Interrupted Publication Recovery

Read this first. This is the sole fix brief for the user-reported publication
window, after accepted source78157e62 / evidencec4574800. Do not redo completed
Task5/6 work or begin Task7. Worktree: /tmp/arkscope-research-output-boundary.
BASE: c457480014a12f965c9521276705bad532827744.

## Verified Defect

The controller ran the unchanged capture/lock/maintenance/admin/CLI owners:
task6-publication-baseline-01,178 passed. The disposable
task6-publication-probe.py creates an unrelated registered orphan and interrupts
put either before publish or before register. Its isolated runner receipt
task6-publication-probe-01 is1F/1P: only before_register fails after recover,
returning blocked/capture_path_unsafe/zero candidates. The actual object/stage
pair has st_nlink==2. `_recover` deduplicates/charges but never removes the stage
alias; `inventory/inspect_owned` require unique regular single-link objects.
This is a functional recovery gap, not a justification to weaken admin inventory.

## Required Fix

Fix the existing writer recovery path. Once durable orphan accounting is committed,
it may remove ONLY a demonstrably redundant staging name for a valid published
object under the existing capture-writer/root protection. Keep the published
bytes, their accounting and registered-read behavior intact. Preserve the strict
admin inventory rule. Do not add a broad nlink exception, a new GC framework,
automatic deletion of unpaired stage bodies, forced reset or filesystem repair.

Derive the ownership proof from current descriptor-bound metadata: canonical
object/staging names, same device/inode and size, exactly the locally observed
two links, regular files, valid content-addressed object. A foreign link, extra
alias, malformed path, mismatching object body or changed identity cannot authorize
an unlink. Confirm current root/entry identity at the unlink boundary. Choose a
small local helper consistent with CaptureDirectory, not a generic FS abstraction.

Commit accounting BEFORE unlink; fsync the staging directory before returning
success. No long scan/hash/unlink/fsync under the global market writer lock.
If unlink/fsync fails, preserve accounting and return the existing typed error;
next explicit recovery must be idempotent. Dead-worker recovery is allowed;
a live writer must remain excluded. Recovery does not acquire provider data.

## Boundaries

Product scope: src/sec_research/captures.py and capture_lock.py, plus only
demonstrably necessary local adjustments. Tests: test_sec_research_captures.py,
test_sec_research_capture_lock.py, test_sec_research_maintenance.py. Controller
owns plan/spec/runbook/evidence changes. No schema, scheduling, model/auth,
transport, compatibility, dependency or unrelated cleanup changes. Escalate a
necessary extra boundary before editing it.

No production DB/config/.env/token access, real provider calls, installation,
App restart, merge or push. Tests use isolated disposable stores and injected
transport responses; implementation approval is not destructive rollout approval.
Only you own product edits/index. No subagents, no reviewer dispatch, no
concurrent test runners. Use the unchanged run_checks.py/offline_pytest.py in
this same plan workspace, unique task6-publication-* receipt names. Do not read
other plan scratch or change the runner to hide a failure.

## RED-first Acceptance

Add durable named tests for the actual production put/publication path and retain
RED before product edits. Include:
- before_register: nlink2 -> recover -> nlink1 object retained, stage alias gone,
  unchanged single body charge -> preview ready with target AND unrelated orphan.
  Apply the approved cleanup and verify both object deletion and final charge.
- before_publish: stage-only remains charged/eligible, no implicit body deletion.
- after_register: failed stage cleanup -> recovered alias removed; registered
  object remains readable, exact bytes/count intact.
- repeated recover, failed accounting commit, unlink failure and post-unlink
  fsync failure; prove charge is not lost and recovery retry converges.
- foreign/extra aliases and entry replacement are rejected without unlinking
  the unproven name; strict admin behavior remains unchanged.
- ordinary market writer remains possible during long recovery filesystem work,
  while the capture writer still excludes a competing live writer.

Do not assert mock calls in place of the file/DB result. Use real tiny files and
DBs; fault injection targets actual publication and durability boundaries. Keep
existing owners; migrate none away to silence regressions. Re-run the controller
probe, full changed suites and adjacent service/operation/reference/schema
controls once covering. Whole backend suite is the later controller gate.
Add one named behavioral inverse that omits the alias recovery and reproduces
the cleanup failure, with original/mutant/restored source and test hashes.

Write the full report to task6-publication-report.md beside this brief: exact
files/commits, RED/GREEN/inverse receipts, self-review, remaining limits and any
unmet requirement. Preserve intermediate failures. Commit your product/tests
after verification. Return only status, commits, short test result, concerns and
report path. The controller will independently review before continuing Task7.
