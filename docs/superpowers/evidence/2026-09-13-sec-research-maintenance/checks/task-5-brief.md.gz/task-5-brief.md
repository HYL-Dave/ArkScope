### Task 5: Operation Leases And Portable Export

**Files:** extend `src/sec_research/capture_lock.py`, Store/CaptureStore,
ResearchService/DocumentService, issuer/tool/query/citation entrypoints;
create `src/sec_research/operations.py`, `__main__.py`; tests
`tests/test_sec_research_operations.py`, existing capture-lock/service/query tests.
Research execution/persistence owners participate in the operation lease where
they can publish SEC refs. No unrelated resource-root or lock redesign.

**Interfaces:** `research_operation(root, *, exclusive=False, create=False)` is
a reentrant owner-scoped shared/exclusive context manager in the existing trusted
root-hashed lock namespace. No missing capture-root creation on stored read or
preview. POSIX no-follow/fd checks remain; unsupported platforms fail explicitly,
not unlocked. Lock order: operation -> issuer/document -> capture writer ->
market write -> SQLite. Exclusive acquisition is bounded/nonblocking with typed
`sec_research_operation_busy`. Complete put->reference publication, multi-read
queries, exports and Research ref publication hold shared protection. A run that
has produced SEC results retains protection through durable event/message commit;
do not rely on an unprotected gap between tool return and reference publication.
Avoid transferring/reusing mutable Context objects across concurrent workers.

`export_bundle(paths, destination: Path, *, free_bytes=None) -> dict` creates an
explicit new bundle. Reuse `backup_market_db(str(source), str(staged_db),
overwrite=False)`. Derive all registered object requirements from that backup,
not the changing live DB. Include all registered historical objects, full
FK/JSON/citation reference closure; exclude unregistered staging/orphan files.
Only in the private backup, clear transient reservations/orphan accounting and
record that normalization. Never claim that normalized DB bytes equal source.
Source is unmodified, no network/config access.

`restore_bundle(bundle: Path, destination: Path, *, database_name="market_data.db",
free_bytes=None) -> dict` requires a new enclosing destination directory and a
safe basename. It restores the DB and `SecResearchPaths.from_market_db` capture
directory as one published bundle, then verifies actual readers. No existing
destination DB/capture/WAL/SHM can be overwritten; no SQL import or archive extract.
Whole market DB rows are included by SQLite backup, but the bundle packages only
SEC capture objects, not independent SA/profile credentials or other capture
roots. Manifest and CLI must state this scope accurately.

Closed version-1 manifest: format/version, DB relative name/hash/size, current
SEC schema fingerprint, exact object-key/hash/size inventory, transient
normalization policy and verified reference counts. Reject unknown versions,
duplicate or undeclared members, symlinks, special files, unsafe paths, missing
objects and invalid hashes/closure. Copies/hashes stream in bounded chunks.
Preflight full DB + object + staging needs independently of the100GiB quota;
handle ENOSPC/fsync failure after admission. Use create-only destination ownership
and atomic final verified manifest publication; no directory is a successful
bundle before that marker exists. On interruption retain a clearly incomplete
owned operation, never a success marker or overwritten user directory.

Expose `python -m src.sec_research export --destination ...` and
`restore --bundle ... --destination ... --database-name ...` through one thin CLI.
No model-facing filesystem operation. Explicit path/operation validation happens
before opening a DB; reports contain counts/digests, not source contents/secrets.

- [ ] RED owners: `test_export_uses_backup_inventory_during_concurrent_publish`,
  `test_export_restore_preserves_wal_and_historical_citations`,
  `test_maintenance_cannot_enter_put_to_publish_gap`,
  `test_stored_reader_lease_does_not_create_capture_root`,
  `test_bundle_rejects_missing_corrupt_and_unsafe_members`,
  `test_create_only_publication_never_overwrites_competing_destination`,
  `test_incomplete_bundle_has_no_success_marker`,
  `test_restore_renamed_database_reopens_same_capture`.

```python
def test_export_restore_preserves_wal_and_historical_citations(bundle_fixture):
    result = bundle_fixture.export_and_restore_with_uncheckpointed_wal()
    assert result["restored_fact"] == result["original_fact"]
    assert result["restored_passage"] == result["original_passage"]
    assert result["source_digest_before"] == result["source_digest_after"]
```

- [ ] Run RED: absent command/lease or admitted exclusive operation inside a
  protected publication gap. Use deterministic barriers, no provider processes.
- [ ] Implement the lease at all actual current entrypoints, then export/restore
  over verified backup. Protect no-path-create behavior. Include schema/receipt
  JSON closure, not only SQL FK_check. No third generic SQLite backup primitive.
- [ ] GREEN new operation tests, capture/store/service/document/citation owners,
  backup tests. Inverses: skip outer lease; enumerate live DB; omit catalog source;
  bypass hash; accept existing destination. Each kills named owner without errors.
- [ ] Commit; report acquired lock order and phase failure semantics. No real
  operator export/restore occurs in this task.

