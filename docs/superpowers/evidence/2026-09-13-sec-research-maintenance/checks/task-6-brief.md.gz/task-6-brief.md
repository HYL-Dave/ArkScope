### Task 6: Explicit Cleanup And Schema Recovery

**Files:** create `src/sec_research/maintenance.py`, `schema_admin.py`; extend
`__main__.py`, `operations.py` and capture/store helpers only for audited admin
transactions. Tests `tests/test_sec_research_maintenance.py`,
`test_sec_research_schema_admin.py`, `test_sec_research_cli.py`.

**Interfaces:**

```python
def preview_cleanup(paths, *, profile_connection) -> dict: ...
def apply_cleanup(paths, preview, *, approval_sha256, receipt_path,
                  profile_connection) -> dict: ...
def preview_schema_reset(paths, *, mode, profile_connection) -> dict: ...
def apply_schema_reset(paths, preview, *, approval_sha256, backup_path,
                       receipt_path, profile_connection) -> dict: ...
```

These are new synchronous operator commands, not startup behavior. CLI explicitly
opens the configured profile query-only and reads only Research citation roots;
do not use a constructor that initializes/migrates profile data. Preview does not
call recover, create roots, change accounting or write a receipt. Apply requires
an exact preview digest, new receipt path and fresh exclusive operation lease,
then rechecks root/schema/candidates/complete Task3 reference closure. Unknown or
corrupt references block, never become an empty set. File keys are descriptor-
bound owned relative keys; no generic recursive deletion command.

Cleanup distinguishes unregistered owned objects/staging from registered but
unreferenced objects. Retain every snapshot, receipt, filing/fact observation,
document/directory/attempt, issuer-map observation and Research ref, regardless
of age/current pin. Only unreferenced object registry rows are candidates. A
reviewed admin transaction can suspend the exact object DELETE guard, delete
only digest-approved rows, restore the guard and verify schema/FKs before commit.
Charge still-present files as orphans before unlink; interrupted unlink stays
charged and resumable. Shared leases protect active exports/readers/producers.
Unknown entries/symlinks/inode ambiguity block rather than being swept away.
Receipts distinguish selected, removed, remaining, blocked and measured freed
bytes. Never report reclaimed bytes before verified durable deletion.

Schema `mode` is reset/uninstall. Inventory exact known owned tables/indexes/
triggers even if their definitions mismatch; unknown owned objects or external
dependencies block pending inspection. Never DROP by a prefix alone. Verify no
retained Research/pin reference would be broken; if present, return
`sec_research_reset_references_present` with counts and leave state untouched.
Back up DB AND captures before any admitted reset. A mismatched schema's safety
backup must be labeled raw, not advertised as a canonical portable export.
Reset requires a new digest-bound observed state after backup and exclusive
operation protection. Drop/recreate only approved owned objects in a transaction;
uninstall leaves them absent. Leave SQLite shared objects and all unrelated rows,
settings, credentials and capture files untouched. Archive/audit lives outside
the removed schema and survives interruption. No live-user assertion flag is
accepted as a substitute for actual lock exclusion.

CLI subcommands `cleanup-preview`, `cleanup-apply`, `schema-preview`,
`schema-apply` read/write explicit versioned preview/receipt JSON. Approval applies
only to that preview, no automatic confirm. Actual production execution is NOT
authorized by this plan. This completes SEC-RECOVERY-001/002 implementation by
this task, before scheduling/final release verification.

- [ ] RED owners: `test_cleanup_preserves_every_retained_reference_class`,
  `test_new_reference_invalidates_cleanup_preview`,
  `test_registered_orphan_unlink_failure_remains_charged`,
  `test_cleanup_restores_immutability_after_rollback`,
  `test_schema_reset_requires_backup_and_exclusive_lease`,
  `test_schema_reset_refuses_research_references`,
  `test_schema_reset_preserves_unrelated_rows_and_sqlite_sequence`,
  `test_unknown_owned_objects_are_not_prefix_drop_targets`,
  `test_maintenance_preview_is_observational`.

```python
def test_new_reference_invalidates_cleanup_preview(maintenance_fixture):
    preview = maintenance_fixture.preview()
    maintenance_fixture.publish_reference()
    result = maintenance_fixture.apply(preview)
    assert result["status"] == "blocked"
    assert maintenance_fixture.original_object_still_exists()
```

- [ ] Record concrete RED before implementing operations. Small fixture stores
  only; inject failure between DB/file/receipt stages and retry explicitly.
- [ ] Implement inspect/approval/recheck/backup/phase receipts, not a permanent
  old-schema execution branch. Cancellation never silently abandons a destructive
  stage; report its last durable phase accurately.
- [ ] GREEN all maintenance/admin/CLI/capture/citation controls. Inverses skip
  recheck, ignore event-only citations, clear charge before unlink, omit backup,
  drop unknown prefix, ignore active lease. Named behavioral failures required.
- [ ] Commit and mark the two operational owners implemented, separately from
  their unperformed actual-store rollout. Unrecoverable unknown schema retains an
  explicit blocked diagnostic plus safety-backup path, not raw SQL instructions.

