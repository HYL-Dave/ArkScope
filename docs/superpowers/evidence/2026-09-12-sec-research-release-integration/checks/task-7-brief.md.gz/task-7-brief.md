### Task 7: Disabled Daily Schedule And Settings

**Files:** create `src/sec_research/scheduled.py`, `schedule_store.py`; modify
schema/service receipt scope, `src/service/data_scheduler.py`, schedule/SEC API
adapters, `apps/arkscope-web/src/api.ts`, Settings SecResearchPanel,
dataScheduleControls/settingsBackendCopy, en/zh-Hant resources. Tests
`tests/test_sec_research_schedule.py`, `test_data_scheduler.py`,
`test_scheduler_state.py`, new API/Settings owners and existing macro controls.

**Interfaces:** `run_current_universe(*, universe_reader, issuer_resolver,
service, limits, clock, progress_cb=None, check=None) -> dict` is the synchronous
core; `run_incremental(*, progress_cb=None) -> dict` composes runtime dependencies.
Register source `sec_research_filings`, default disabled, interval1440min,
`writes_market_db=True`, `universe_tickers=False`, adapter to run_incremental.
Core reads the active-universe owner each run, distinguishing valid empty from
unavailable. No fixed tickers, YAML fallbacks, profile identity changes or LLM.
Deduplicate resolved issuers by canonical CIK; retain missing/ambiguous outcomes.

Add explicit `scope="recent"` structured acquisition for scheduled work, with
separate receipt/continuation ownership from on-demand full history. It requests
only current submissions and Company Facts, never historical/documents. Preserve
historical-not-requested coverage and previous historical continuation; do not
pretend max_sources=2 alone gives a complete-history result. Normalized schedule
counts apply forms10-K/10-Q/20-F/40-F and amendments; raw source bytes unchanged.

Per run bounds: at most500 distinct issuer dispatches,1001 provider requests (one
optional map+two per issuer),15min wall budget. Check before each source. Persist
remaining CIK/ticker scope; each continuation intersects fresh active membership
and rotates deferred/new issuers so no current member starves. Request bound is
derived from this shape; no retries. Partial receipts never imply missing issuers
are empty. No automatic paid-provider fallback or full-document prefetch.
This raises the draft plan's50-issuer limit: a daily source should not split the
previously reported roughly187-member universe across four days solely because
of that arbitrary limit. The500-issuer ceiling is an application safety bound,
not a measured current universe count or a guarantee that every provider request
finishes within15min. Limits remain injectable for small deterministic fixtures.
The provider governor remains authoritative for pacing; no live run is authorized.

SEC-owned durable batch receipt records attempted/confirmed/failed/deferred CIKs,
request counts, scoped filing/fact counts and gaps; expose last attempt separately
from last successful actual acquisition. A valid empty-universe run can succeed
without claiming an acquisition timestamp. Failed work leaves earlier committed
issuer data and previous success intact. SEC-only scheduler mapping returns
succeeded/partial/failed truthfully, never generic success for unavailable/error.
Keep existing news/macro status contracts unchanged. Next run is next eligible
time, not a guaranteed provider dispatch time.

Add stored-only GET `/sec-research/schedule-status` before dynamic CIK routes;
reuse existing schedule enable/interval/Run Now controls, no second enable key.
SecResearchPanel shows last acquisition/attempt, issuer coverage, counts/gaps and
capacity separately. Terminal schedule changes refresh local status/capacity,
not pinned captures, cursor snapshots or dirty budget drafts. Old SEC enabled
keys are never inherited. Budget PUT cannot enable or dispatch.

- [ ] RED owners `test_sec_schedule_disabled_even_with_old_enabled_key`,
  `test_empty_universe_success_is_not_acquisition`,
  `test_unavailable_universe_never_dispatches`,
  `test_schedule_deduplicates_cik_and_exposes_unresolved_symbols`,
  `test_recent_schedule_preserves_explicit_history_continuation`,
  `test_batch_bounds_defer_without_starving_current_members`,
  `test_sec_partial_failure_retains_previous_success`,
  `test_budget_edit_never_enables_schedule`.

```python
def test_sec_schedule_disabled_even_with_old_enabled_key(schedule_fixture):
    schedule_fixture.set_old_sec_enabled()
    state = schedule_fixture.read_current_source()
    assert state["enabled"] is False
    assert state["interval_min"] == 1440
    assert schedule_fixture.tick_dispatches() == []
```

- [ ] RED with real disposable scheduler/profile/market stores; provider transport
  only fake. Use deterministic time/dispatch recorders, no supervisor launch.
- [ ] Implement scoped receipts, bounded scheduler outcome mapping and real
  Settings consumer. Preserve current route/write permission controls and
  accurate current-tool/category counts if schema tests move.
- [ ] GREEN schedule/API/frontend controls, macro/news unchanged controls and
  desktop/mobile screenshots. Inverses enable by default, traverse a historical
  pointer, drop partial status, erase last success, reuse removed membership.
- [ ] Commit with source/body request inventory and scope definitions, leaving the
  actual user's schedule disabled and production configuration untouched.

