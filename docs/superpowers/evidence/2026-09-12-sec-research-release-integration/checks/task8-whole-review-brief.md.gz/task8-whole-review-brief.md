# SEC Release Whole-Change Review

Review the entire implementation range c997a6c9817b80857ba7211989cdf6412d3b1003
through a77a7c2e7cb1bb1b8d2b92cd4cfb129f299f6687, not merely the latest workflow
test or schedule fix. This is the one final whole-change review required by
Task8. Tasks1-7 and the publication fix already have scoped reviews; they do not
substitute for this gate or preclude finding cross-task defects.

## Inputs And Scope

- `task8-whole-current-source-01.diff` contains all210 changed product, test,
  dependency, current documentation and skill paths, with exact base/head.
- `task8-whole-review-01.diff` is the unfiltered74-commit package. The smaller
  view omits only1685 archived evidence/scratch paths, not runtime/test code.
  Its inventory and generation helper are retained. Read in bounded passes if
  needed; do not rederive the diff or silently claim unread code was reviewed.
- Approved spec: `docs/superpowers/specs/2026-09-10-sec-research-substrate-design.md`.
- Current plan: `docs/superpowers/plans/2026-09-12-sec-research-release-integration.md`.
- `docs/design/SEC_RESEARCH_OPERATIONS.md` and release-evidence `RULINGS.md`
  carry current operational scope and every controller ruling. These pending
  controller doc changes are not part of the immutable source package yet;
  final verification/status text will follow actual results, not precede them.
- `progress.md` carries historical review findings, rulings and deferred items.
  N1/i18next/React act warnings remain qualified nonblocking observations; raw
  final frontend log retains1016 act lines. The current build is1201.53kB,
  360.97kB gzip, and still warns about its chunk size. Triage these on their
  merits; no suppression or clean-output claim is made.
- Task8 scoped review is spec compliant/quality approved with minorM1: the
  interrupted stored-read workflow observes transport calls but not entry into
  its acquisition factory. Healthy stored/pinned contract owners count both;
  this is a nonblocking coverage suggestion, not a claimed product defect.
  Triage it together with the other deferred observations in the final review.

## Binding Global Constraints

- No production DB/config/.env/token access, real provider calls, installation,
  App restart, merge or push. Tests use isolated disposable stores and injected
  transport responses; implementation approval is not destructive rollout approval.
- Preserve prices/news/SA/financial_cache, present lifecycle decisions and
  research history. No model, auth, effort default or transport fallback change.
- One canonical SEC schema; mismatch is explicit. No startup repair/DROP,
  hypothetical legacy execution lane or migration chain. Retained data is not
  disposable merely because the product is pre-release.
- All three SEC tools use the existing `analysis` category and closed envelopes:
  status, data, gaps, observed_at, coverage, next_cursor. No bare-list empty
  success. Stored/pinned reads acquire nothing; revalidation never replaces pins.
- Preserve exact Decimal TEXT, immutable source hashes, UTF-8 half-open passage
  ranges, complete citation envelopes, snapshot/filter-bound cursors and current
  32 MiB wire /128 MiB decoded per-response document limits. Capture budget stays
  adjustable100GiB by default. No general bridge-budget increase.
- New ticker resolution is issuer metadata, not a ticker identity/rename signal.
  Ambiguity must not be collapsed to an arbitrary CIK. SEC contact/pacing use the
  existing profile-owned configuration and transport, not an env fallback.
- Three-tool replacement is atomic across registry, both API adapters, both
  OAuth allowlists, subagent inventories, seven current skills and tool catalog.
  Required tools must not silently disappear in filtering.
- Persist references before recovery admits deletion. Cleanup rechecks all
  snapshot/document/Research citation/pin/export references under coordination;
  schema reset backs up, checks live users and protects unrelated objects.
- TOC recognition requires structural evidence. Do not choose a duplicate
  heading by position or loosen ambiguity checks. Full text remains available.

## Current Evidence

Current worker reports: task6-publication-report.md and its independent review;
task-7-report.md, task7-fix1-report.md, task7-review-01.md and
task7-rereview-1.md; task-8-report.md and task8-workflow-review-01.md.
Earlier task evidence is linked from the current plan. The final complete
backend gate is pending this review and will run alone on the resulting frozen
source. Do not manufacture a full-suite claim from overlapping focused runs.

Controller readbacks: publication1092P; schedule2493P/449P; workflow9P;
fresh full frontend1833P/126files, typecheck/build/literals pass. Browser final
`task7-fix1-29-browser-final` uses real generated HTTP/service/store data in
en/zh-Hant at1280x960/390x844; helpers, request/body inventories and16 images are
retained. It is not live-provider or all-Settings health evidence.

`task8-final-census-reconciliation.json` and `task8-census-adjudication.md`
retain review_required, not an automatic-clean verdict.70 new candidates have
current consumers/intentional CLI or scheduler entrypoints; remaining SQL/i18n
uncertainty, C12/C15/C20 and actual-store disposition stay open. No current
source is deletable merely because a heuristic marks it as a candidate.

## Review Method And Output

Read-only product/index/branch. Do not launch subagents or repeat existing test
suites. Any concrete unanswered probe must be coordinated before execution.
No actual-store or runtime operation. Follow the requesting-code-review
code-reviewer template: findings by severity with file/line, impact and proposed
repair, then scope/checks/limits and a clear assessment. Explicitly distinguish
source readiness from actual deployment/merge authorization and pending full
verification. Save full report to `task8-whole-review-01.md`; return concise
verdict/findings count/report path. Source fixes belong to a separate worker.
