### Task 8: Release Verification And Current-Surface Cleanup

**Files:** focused remaining SEC aliases/current descriptions discovered by
Task 2's exact reference scan; `docs/design/PROJECT_PRIORITY_MAP.md`, current SEC
spec status and new tracked evidence. Tests use actual existing owners plus
`tests/test_sec_research_release_workflow.py` and frontend integration fixtures.
No unrelated news-provider/collector rewrite is bundled into a SEC verification
fix. C09/C11/C12 and CSS/I18n-wide cleanup keep their independent recorded owners;
this gate must state their status, not claim the whole repository is clean.

**Interfaces:** End-to-end fixtures use the actual ToolService, Store,
CaptureStore, Research trace/persistence, export/restore and maintenance commands.
Only remote response bytes/time/filesystem failures and model transport messages
are injected. This is offline workflow validation, not live provider/model proof.

- [ ] Write `test_research_catalog_fact_document_reload_export_restore` with a
  generated mapping, submissions, Company Facts, directory and HTML filing.
  Execute all three tools through a real adapter, persist the trace, reopen exact
  fact/passage references, export, restore to a new root and reopen again.

```python
def test_research_catalog_fact_document_reload_export_restore(release_fixture):
    before, after = release_fixture.round_trip()
    assert after["value"] == before["value"]
    assert after["text"] == before["text"]
    assert after["text_sha256"] == before["text_sha256"]
    assert after["capture_id"] == before["capture_id"]
```

Add explicit interrupted-refresh->stored-reference-read->cleanup-negative
workflow and default-disabled schedule controls. First run records the missing
workflow's concrete RED, if any; do not manufacture a regression when already
implemented behavior passes, instead label that as a positive integration check.
- [ ] Re-run mechanical repository census against the sealed document baseline;
  classify every new candidate, dependency change and coverage reduction with a
  current owner. Remove only confirmed abandoned SEC aliases/entrypoints and
  move their useful tests to the real workflow. No deletion based solely on a
  candidate ID, locale string or SQL scanner false positive.
- [ ] Run all frontend tests, typecheck, i18n checks and Playwright at desktop
  1280x960/mobile390x844 in en/zh-Hant. Real HTTP/service/store fixture, screenshots,
  no horizontal overflow or overlapping controls. Exercise stored reads,
  citations, background completion, config, schedule and operator previews;
  destructive confirmations operate only on generated stores.
- [ ] Freeze all product/test/resource/dependency paths, collect exact backend
  nodes with explicit `tests`, run one full backend suite, and reconcile every
  executed node plus the unchanged skip identities. Run inverse scripts against
  the final source; any changed boundary since its task gets fresh inverse proof.
  A fixture runner failure is recorded separately, never fixed by weakening
  product contracts or quietly skipping a test.
- [ ] Independent whole-change review over `c997a6c9..HEAD`; task reviews are not
  a substitute. Route findings through the original implementer/final-fix worker
  with focused RED/GREEN and scoped re-review. No controller product fixes.
- [ ] Seal reports, commands, logs, source identities, node reconciliation,
  inverse results, screenshots and census into
  `docs/superpowers/evidence/2026-09-12-sec-research-release-integration/`.
  Hash original and archive bytes, verify Git index bytes, exclude disposable
  DBs/tokens/user config. Publish evidence before removing this plan's scratch.
  Record every `Ruling:` in the final report with its tradeoff.
- [ ] State exactly which workflows are verified offline, which live canary is
  still unauthorized, and which actual-store rollout/old-schema disposition and
  separate wider cleanup remain. Do not merge/push/restart. Existing worktree is
  retained for explicit user review and later merge authorization.

## Evidence Format

Each implementer writes `task-N-report.md` next to its brief, with exact changed
files, RED/GREEN command paths/results and self-review. Each named inverse has
one entry in `task-N-inverses.json`:

```json
{"run":"taskN-inverse-name","restored":{"src/path.py":"sha256"},
 "mutated":{"src/path.py":"different-sha256"},
 "failed_testcases":["tests.test_module::test_named_owner"],
 "mutation_script":"task-N/inverse.py"}
```

Hashes in actual evidence are computed, not these illustrative labels. Store
re-runnable inverse scripts under this plan's scratch, not product test APIs.
No syntax/import/collection error counts as a killed behavioral owner. The final
source and named tests must match recorded restored hashes. Full-suite execution
belongs to the final gate; focused task regression suites avoid repeating the
entire backend for each implementation or review.

## Preflight Review

Spec coverage: issuer/freshness Task1; three contracts/four transports/skills and
whole pages Task2; persistent refs/reopening Task3; section quality Task4;
coordination/export Task5; both recovery owners Task6; schedule/Settings Task7;
integration/collateral/census Task8. Existing exact parsers/captures remain the
foundation. Actual-store cleanup/activation and separate news/collector cleanup
are not represented as completed by these offline steps.

The concrete interfaces above were checked against the current stores/queries,
both bridge caps and Layer0's smaller default, transport retry behavior and two
read-only preflight reports. No product files changed during preflight. The
collected baseline is exactly9180 nodes. No guessed pass totals are used for new
work. The initially missing schema-test filename is retained as a runner mistake.
