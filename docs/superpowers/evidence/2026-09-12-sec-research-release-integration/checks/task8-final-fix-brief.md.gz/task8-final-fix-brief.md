# Task8 Final Review Fix Wave

BASE:a77a7c2e7cb1bb1b8d2b92cd4cfb129f299f6687.
Worktree:/tmp/arkscope-research-output-boundary.
Read task8-whole-review-01.md first for the complete ImportantI1 and MinorM1
findings. This is the one consolidated final fix wave, not a restart of the
SEC release plan. Do not read the entire parent plan or sibling scratch.

## Required Repair

Reproduce actual async Anthropic parent -> delegate_to_subagent -> configured
Anthropic child -> each of the three SEC tools. Keep real parent/child/bridge/
ToolService dispatch intact, inject only fake SDK responses and generated data.
The current path calls asyncio.run on the parent's running event-loop thread.
Record the intended failing assertion before changing implementation.

Repair async delegation in the smallest coherent shared ownership boundary.
Choose based on actual existing async/owned-worker patterns, not a nested-loop
patch or an abandoned worker. Preserve the configured provider/model/auth/effort
and optional/required tool filtering; do not change defaults or remove tools.
Preserve actual sync callers too. Before editing, name the chosen mechanism and
its concrete call sites/cancellation/resource ownership in a short preflight.
Escalate if it requires broad framework changes or an ambiguous new contract.

If using a worker, context must propagate, cancellation must reach the child/SEC
work, and the worker must be joined before parent operation/output authority is
released. If using an async child path, preserve existing synchronous entrypoints
and cover real await/stop/resource release. Avoid cloning an entire runner merely
to await one call. Required leases and inherited auth are behavioral properties,
not tests that may be removed to make dispatch pass.

Also address M1 by adding an acquisition-entry counter to the existing release
fixture and asserting it remains unchanged through interrupted stored/pinned
reads. Keep the current transport/candidate/accounting/value assertions. It is
a small test-strengthening change, not evidence of another production defect.

## Focused Verification

- Real parent/child loop delivers complete expected SEC envelopes for all three
  tools to the child's next model turn. No error-shaped success. Include one
  exact decimal and document/cursor identity control as appropriate.
- Stored/pinned reads enter neither acquisition factory nor transport.
- Parent/child output/auth scope remains the captured selection, including
  foreign-credential rejection. No fallback/reselection/model default change.
- Parent cancellation while delegated SEC work is in flight stops/joins it
  before releasing parent protection. Keep direct calls and supported sync
  callers as positive controls. Add other immediate call-site controls if the
  chosen shared function affects them, without a full framework matrix clone.
- One named inverse for a new load-bearing ownership boundary, with immutable
  original/mutant artifacts, exact hashes and restored GREEN. No syntax/import
  failure may count as a behavioral RED or killed inverse.
- Run focused covering subagent/native dispatch/tool adapter/output/auth/trace/
  operation and release-workflow tests on final source. Do not run full backend,
  frontend, browser, census or another reviewer. Controller owns those gates.

Use the unchanged W/run_checks.py and offline_pytest.py with unique
task8-final-fix-* receipt names. Preserve every failed attempt and classify real
RED, fixture mistake, intermediate regression and inverse separately. Do not
weaken the runner, delete tests or suppress warnings for a green result.

## Boundaries And Handoff

No production DB/config/.env/token access, real provider/model/CLI/network calls,
package/runtime install, App restart, actual-store operation, master merge or
push. Generated stores and fake SDK messages only. No subagents. You alone own
product/test edits and index until handoff; controller edits disjoint docs and
evidence only. Do not stage controller pending docs/evidence.

Expected source area: Anthropic tool dispatch and shared subagent runner, plus
the immediate async caller only if the selected shared owner requires it. New
focused regression owner and the small release-workflow fixture change. Report
scope growth before editing unrelated drivers/model policy/storage/UI.

Self-review, commit exact owned files, then write full report at
W/task8-final-fix-report.md, including preflight, actual RED/GREEN/covering
commands/results, inverse proof/restore, source/test accounting, scope/limits and
explicit no-active-runner handoff. Return only status, commit, concise tests,
concerns and report path. W is this plan's .superpowers/sdd directory.

## Controller Ruling: Delegated Citation Retention

The preflight's observed loss of delegated SEC references conflicts with the
retained-citation contract. Include the proposed bounded observer extension in
this same fix wave: shared subagent completion sites and the two existing native
parent producers only. This additionally admits src/agents/anthropic_agent/agent.py
and src/agents/openai_agent/agent.py plus focused regression/trace tests.

Use invocation-local host-owned observation of admitted complete SEC results,
unchanged citation_event_fields, actual SEC names and collision-isolated child
call IDs. Return delegate answer JSON unchanged; do not admit citation claims
from arbitrary delegate output. Do not change citation/event schema, validation,
durable projection, storage, UI, routing, credentials or model policy.

OpenAI must reuse its existing queue/drain and active lifetime. Anthropic must
drain already-admitted child completions before successful delegate completion
or propagating failure/cancellation, but must not yield during GeneratorExit.
Both must stop late admission and join owned work before releasing protection.
No detached worker, global cross-run buffer or nested tracing framework.

Record RED before this extension. Prove actual native parent/child combinations
(Anthropic/OpenAI on both sides), complete retained-reference readback, isolation
between invocations, and admitted-completion-before-failure/cancel behavior.
Malformed SEC result retains a typed citation gap; forged delegate metadata and
foreign secrets do not gain new admission. Standalone synchronous returns stay
unchanged, OAuth parents remain without delegation, and unsupported OAuth child
selection remains fail-closed. Preserve the original I1/M1 tests and report.

Reason: successful delegated research must not lose its source references on
reload. Cost if wrong: trace collision, reference loss or lifetime regression;
actual retained records, failure/cancel and isolation owners are required.

## Controller Ruling: Preserve Live Sync Entry, Not Test-Only Wrappers

Current reference readback finds _run_anthropic_subagent and
_run_openai_subagent now are sync wrappers used only by tests. All product
dispatch reaches their _async counterparts. The user's physical-cleanup policy
does not justify keeping these private wrappers for hypothetical callers.
Preserve public dispatch_subagent and its genuine sync caller; remove test-only
private sync wrappers, using one async child implementation per provider.
Keep original private names for the async implementations if that reduces churn.
Update direct helper tests to execute the actual async owner, preserving each
assertion; tests/test_fable_5_1_runtime.py is explicit collateral (one direct
Anthropic helper call), in addition to already-owned test_subagent.py.

This is not deletion of the synchronous Research API, public dispatcher or its
positive controls. No extra compatibility facade. Cost if wrong: an unsupported
external private caller would need adaptation; all repository product callers
and Fable/child-runtime guards must continue to pass. Include these owners in
final covering tests and refresh the inverse source proof on final source.
