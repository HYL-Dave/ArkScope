from pathlib import Path

import src

# Scope source imports to this retained mutation fixture, with repository fallback.
src.__path__.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
