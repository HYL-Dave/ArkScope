# Review task3

Base: 2842c497dabfdb0b13c315e22b206128eba9f57d
Head: frozen uncommitted task snapshot.

## Commits Since Base

## Scope And Current File Hashes
```json
{
  "src/sec_research/__init__.py": "283db4d3a4f27a14b29fb8e6b1c60bac262252a801ceea21c7f6375ef574d07f",
  "src/sec_research/config.py": "67818a242046a94b97c61a6fc80e24627dc4eed9a4c13da77efc0b918a30646c",
  "src/sec_research/paths.py": "93fc1abd8addc3d7b924d1b6b67ab0a94a7203d061da4e7c8a4b7a57e3005eaa",
  "tests/test_sec_research_config.py": "8bcbbaf8c54b88f26e0165fcbb52b802c1f5e0645e3115e72ad9d8f5833cfea9",
  "tests/test_sec_research_paths.py": "0bdad74318b5849d89fe9f2810a295401299fc46bf13a266b8fa460f01afc408"
}
```

## Stat
```text
 src/sec_research/__init__.py      |   1 +
 src/sec_research/config.py        |  47 +++++++
 src/sec_research/paths.py         |  70 +++++++++
 tests/test_sec_research_config.py | 195 ++++++++++++++++++++++++++
 tests/test_sec_research_paths.py  | 288 ++++++++++++++++++++++++++++++++++++++
 5 files changed, 601 insertions(+)

```

## Patch
```diff
diff --git a/src/sec_research/__init__.py b/src/sec_research/__init__.py
new file mode 100644
index 00000000..807fb5e2
--- /dev/null
+++ b/src/sec_research/__init__.py
@@ -0,0 +1 @@
+"""SEC research foundation; tool and acquisition workflows are separate owners."""
diff --git a/src/sec_research/config.py b/src/sec_research/config.py
new file mode 100644
index 00000000..bf1daa29
--- /dev/null
+++ b/src/sec_research/config.py
@@ -0,0 +1,47 @@
+"""Typed SEC capture budget over the existing profile settings store."""
+
+from __future__ import annotations
+
+import re
+
+from src.profile_state import ProfileStateStore
+
+
+CAPTURE_BUDGET_KEY = "sec_research.capture_budget_bytes"
+DEFAULT_CAPTURE_BUDGET_BYTES = 100 * 1024**3
+MAX_CAPTURE_BUDGET_BYTES = 2**53 - 1
+_CANONICAL_POSITIVE_INTEGER = re.compile(r"[1-9][0-9]*")
+
+
+def _validate_capture_budget_bytes(value: int) -> int:
+    if type(value) is not int or not 1 <= value <= MAX_CAPTURE_BUDGET_BYTES:
+        raise ValueError(
+            f"{CAPTURE_BUDGET_KEY} must be a positive integer no larger than "
+            f"{MAX_CAPTURE_BUDGET_BYTES}"
+        )
+    return value
+
+
+def get_capture_budget_bytes(store: ProfileStateStore) -> int:
+    """Default only an absent key; never mask or repair persisted corruption."""
+    snapshot = store.get_settings_snapshot((CAPTURE_BUDGET_KEY,))
+    if CAPTURE_BUDGET_KEY not in snapshot:
+        return DEFAULT_CAPTURE_BUDGET_BYTES
+
+    value = snapshot[CAPTURE_BUDGET_KEY]
+    if (
+        not isinstance(value, str)
+        or len(value) > len(str(MAX_CAPTURE_BUDGET_BYTES))
+        or _CANONICAL_POSITIVE_INTEGER.fullmatch(value) is None
+    ):
+        raise ValueError(
+            f"{CAPTURE_BUDGET_KEY} must contain canonical decimal integer text"
+        )
+    return _validate_capture_budget_bytes(int(value))
+
+
+def set_capture_budget_bytes(store: ProfileStateStore, value: int) -> int:
+    """Persist only the validated budget; no scheduling or filesystem effects."""
+    validated = _validate_capture_budget_bytes(value)
+    store.set_setting(CAPTURE_BUDGET_KEY, str(validated))
+    return validated
diff --git a/src/sec_research/paths.py b/src/sec_research/paths.py
new file mode 100644
index 00000000..33623670
--- /dev/null
+++ b/src/sec_research/paths.py
@@ -0,0 +1,70 @@
+"""Market-store-bound capture roots and portable relative object keys."""
+
+from __future__ import annotations
+
+from dataclasses import dataclass
+from pathlib import Path, PurePosixPath, PureWindowsPath
+
+
+@dataclass(frozen=True)
+class SecResearchPaths:
+    market_db_path: Path
+
+    def __post_init__(self) -> None:
+        object.__setattr__(self, "market_db_path", Path(self.market_db_path).resolve())
+
+    @classmethod
+    def resolve(cls) -> SecResearchPaths:
+        from src.market_data_admin import resolve_market_db_path
+
+        return cls.from_market_db(resolve_market_db_path())
+
+    @classmethod
+    def from_market_db(cls, path: str | Path) -> SecResearchPaths:
+        return cls(market_db_path=Path(path))
+
+    @property
+    def capture_root(self) -> Path:
+        path = self.market_db_path
+        return path.parent / (path.name + ".sec-research")
+
+    def object_path(self, key: str) -> Path:
+        """Resolve a portable relative key without creating directories or files.
+
+        Containment is checked at resolution time; future file I/O must also
+        guard against concurrent filesystem changes.
+        """
+        if not isinstance(key, str) or not key:
+            raise ValueError("SEC object key must be a nonempty string")
+
+        relative = PurePosixPath(key)
+        windows = PureWindowsPath(key)
+        if (
+            relative.is_absolute()
+            or windows.drive
+            or windows.root
+            or not relative.parts
+            or relative.as_posix() != key
+            or ".." in relative.parts
+            or any(
+                char in '<>:"\\|?*' or ord(char) < 32 or ord(char) == 127
+                for char in key
+            )
+            or any(
+                part.endswith((".", " ")) or PureWindowsPath(part).is_reserved()
+                for part in relative.parts
+            )
+        ):
+            raise ValueError(
+                "SEC object key must be a portable relative path without traversal"
+            )
+
+        root = self.capture_root
+        try:
+            resolved = root.joinpath(*relative.parts).resolve()
+        except (OSError, RuntimeError) as exc:
+            raise ValueError("SEC object key cannot be resolved safely") from exc
+        # Keep the DB-derived root as the anchor, even if that root is a symlink.
+        if resolved == root or not resolved.is_relative_to(root):
+            raise ValueError("SEC object key escapes the capture root")
+        return resolved
diff --git a/tests/test_sec_research_config.py b/tests/test_sec_research_config.py
new file mode 100644
index 00000000..b83443c8
--- /dev/null
+++ b/tests/test_sec_research_config.py
@@ -0,0 +1,195 @@
+"""SEC capture-budget ownership and persistence contracts."""
+
+import sqlite3
+from pathlib import Path
+
+import pytest
+
+from src.profile_state import ProfileStateStore
+
+
+ROOT = Path(__file__).resolve().parents[1]
+KEY = "sec_research.capture_budget_bytes"
+
+
+@pytest.mark.parametrize("name", ["__init__.py", "config.py"])
+def test_sec_configuration_owner_exists(name):
+    assert (ROOT / "src" / "sec_research" / name).is_file()
+
+
+def _config():
+    assert (ROOT / "src" / "sec_research" / "config.py").is_file()
+    from src.sec_research import config
+
+    return config
+
+
+@pytest.fixture
+def profile(tmp_path):
+    return ProfileStateStore(tmp_path / "profile" / "state.db")
+
+
+def _settings_rows(profile):
+    with sqlite3.connect(profile.db_path) as conn:
+        return conn.execute(
+            "SELECT key, value, updated_at FROM profile_settings ORDER BY key"
+        ).fetchall()
+
+
+def test_budget_defaults_only_when_the_key_is_absent(profile):
+    config = _config()
+    assert config.get_capture_budget_bytes(profile) == 107374182400
+    assert profile.get_settings_snapshot([KEY]) == {}
+    assert _settings_rows(profile) == []
+    profile.set_setting(KEY, None)
+    before = _settings_rows(profile)
+    with pytest.raises(ValueError):
+        config.get_capture_budget_bytes(profile)
+    assert _settings_rows(profile) == before
+
+
+@pytest.mark.parametrize(
+    ("stored", "expected"),
+    [
+        ("1", 1),
+        ("107374182399", 107374182399),
+        ("107374182400", 107374182400),
+        ("214748364800", 214748364800),
+        ("9007199254740989", 9007199254740989),
+        ("9007199254740991", 9007199254740991),
+    ],
+    ids=["minimum", "below-default", "default", "above-default", "large-odd", "maximum"],
+)
+def test_budget_reads_exact_canonical_integers_without_writes(profile, stored, expected):
+    config = _config()
+    profile.set_setting(KEY, stored)
+    before = _settings_rows(profile)
+    result = config.get_capture_budget_bytes(profile)
+    assert type(result) is int
+    assert result == expected
+    assert _settings_rows(profile) == before
+
+
+@pytest.mark.parametrize(
+    "stored",
+    [
+        pytest.param("", id="empty"),
+        pytest.param("0", id="zero"),
+        pytest.param("-1", id="negative"),
+        pytest.param("+1", id="plus"),
+        pytest.param("01", id="leading-zero"),
+        pytest.param(" 1", id="leading-space"),
+        pytest.param("1 ", id="trailing-space"),
+        pytest.param("1\n", id="newline"),
+        pytest.param("1\x00", id="nul"),
+        pytest.param("1.0", id="whole-float"),
+        pytest.param("1.5", id="fraction"),
+        pytest.param("1e3", id="exponent"),
+        pytest.param("NaN", id="nan"),
+        pytest.param("Infinity", id="infinity"),
+        pytest.param("-inf", id="negative-infinity"),
+        pytest.param("true", id="true-text"),
+        pytest.param("false", id="false-text"),
+        pytest.param("NULL", id="null-text"),
+        pytest.param("1_024", id="underscore"),
+        pytest.param("0x400", id="hex"),
+        pytest.param("\u0661", id="unicode-digit"),
+        pytest.param("\uff11", id="fullwidth-digit"),
+        pytest.param("9007199254740992", id="overflow"),
+        pytest.param("9" * 5000, id="huge-overflow"),
+        pytest.param(b"1", id="blob"),
+    ],
+)
+def test_budget_rejects_corrupt_persisted_values_without_repair(profile, stored):
+    config = _config()
+    profile.set_setting(KEY, stored)
+    before = _settings_rows(profile)
+    with pytest.raises(ValueError):
+        config.get_capture_budget_bytes(profile)
+    assert _settings_rows(profile) == before
+
+
+@pytest.mark.parametrize(
+    "value",
+    [
+        pytest.param(None, id="null"),
+        pytest.param(True, id="bool-true"),
+        pytest.param(False, id="bool-false"),
+        pytest.param(0, id="zero"),
+        pytest.param(-1, id="negative"),
+        pytest.param(1.0, id="whole-float"),
+        pytest.param(1.5, id="fraction"),
+        pytest.param(107374182400.0, id="default-float"),
+        pytest.param(float("nan"), id="nan"),
+        pytest.param(float("inf"), id="infinity"),
+        pytest.param(float("-inf"), id="negative-infinity"),
+        pytest.param("1", id="numeric-text"),
+        pytest.param(b"1", id="bytes"),
+        pytest.param([], id="list"),
+        pytest.param({}, id="dict"),
+        pytest.param(9007199254740992, id="overflow"),
+        pytest.param(10**200, id="huge-overflow"),
+    ],
+)
+def test_budget_setter_rejects_invalid_values_before_writing(profile, value):
+    config = _config()
+    profile.set_setting(KEY, "4096")
+    before = _settings_rows(profile)
+    with pytest.raises(ValueError):
+        config.set_capture_budget_bytes(profile, value)
+    assert _settings_rows(profile) == before
+
+
+def test_rejected_budget_does_not_create_an_absent_setting(profile):
+    config = _config()
+    with pytest.raises(ValueError):
+        config.set_capture_budget_bytes(profile, True)
+    assert _settings_rows(profile) == []
+
+
+def test_budget_changes_persist_exact_text_and_leave_other_settings_untouched(profile):
+    config = _config()
+    profile.update_settings(
+        {
+            "security_lifecycle.automation.enabled": "false",
+            "security_lifecycle.automation.interval_minutes": "5",
+            "use_local_market": "true",
+            "default_watchlist_id": None,
+        }
+    )
+    with sqlite3.connect(profile.db_path) as conn:
+        conn.execute("UPDATE profile_settings SET updated_at = '2001-01-01T00:00:00Z'")
+        schema_before = conn.execute(
+            "SELECT type, name, sql FROM sqlite_master ORDER BY type, name"
+        ).fetchall()
+    unrelated_before = _settings_rows(profile)
+
+    for value, text in [
+        (107374182400, "107374182400"),
+        (214748364800, "214748364800"),
+        (9007199254740991, "9007199254740991"),
+        (9007199254740989, "9007199254740989"),
+        (1, "1"),
+    ]:
+        result = config.set_capture_budget_bytes(profile, value)
+        assert type(result) is int
+        assert result == value
+        assert profile.get_settings_snapshot([KEY]) == {KEY: text}
+        assert config.get_capture_budget_bytes(profile) == value
+        assert [row for row in _settings_rows(profile) if row[0] != KEY] == unrelated_before
+
+    with sqlite3.connect(profile.db_path) as conn:
+        assert conn.execute(
+            "SELECT type, name, sql FROM sqlite_master ORDER BY type, name"
+        ).fetchall() == schema_before
+    reopened = ProfileStateStore(profile.db_path)
+    assert config.get_capture_budget_bytes(reopened) == 1
+
+
+def test_budget_accessors_do_not_create_market_or_capture_files(profile, tmp_path, monkeypatch):
+    config = _config()
+    market = tmp_path / "uncreated" / "market.db"
+    monkeypatch.setenv("ARKSCOPE_MARKET_DB", str(market))
+    assert config.get_capture_budget_bytes(profile) == 107374182400
+    assert config.set_capture_budget_bytes(profile, 214748364800) == 214748364800
+    assert not market.parent.exists()
diff --git a/tests/test_sec_research_paths.py b/tests/test_sec_research_paths.py
new file mode 100644
index 00000000..00ff6b1f
--- /dev/null
+++ b/tests/test_sec_research_paths.py
@@ -0,0 +1,288 @@
+"""SEC capture-root authority and portable object-key contracts."""
+
+from pathlib import Path
+
+import pytest
+
+
+ROOT = Path(__file__).resolve().parents[1]
+
+
+def test_sec_paths_owner_exists():
+    assert (ROOT / "src" / "sec_research" / "paths.py").is_file()
+
+
+def _paths_type():
+    assert (ROOT / "src" / "sec_research" / "paths.py").is_file()
+    from src.sec_research.paths import SecResearchPaths
+
+    return SecResearchPaths
+
+
+def test_capture_root_keeps_the_resolved_database_filename_without_creating_files(tmp_path):
+    paths = _paths_type().from_market_db(tmp_path / "uncreated" / "market.snapshot.db")
+    assert paths.market_db_path == tmp_path / "uncreated" / "market.snapshot.db"
+    assert paths.capture_root == tmp_path / "uncreated" / "market.snapshot.db.sec-research"
+    assert paths.object_path("objects/body.txt") == (
+        tmp_path / "uncreated" / "market.snapshot.db.sec-research" / "objects" / "body.txt"
+    )
+    assert list(tmp_path.iterdir()) == []
+
+
+def test_two_market_databases_in_one_directory_have_distinct_capture_roots(tmp_path):
+    paths_type = _paths_type()
+    first = paths_type.from_market_db(tmp_path / "first.db")
+    second = paths_type.from_market_db(tmp_path / "second.db")
+    assert first.object_path("body") == tmp_path / "first.db.sec-research" / "body"
+    assert second.object_path("body") == tmp_path / "second.db.sec-research" / "body"
+    assert list(tmp_path.iterdir()) == []
+
+
+@pytest.mark.parametrize("factory", ["from_market_db", "constructor"])
+def test_relative_market_binding_survives_cwd_changes(tmp_path, monkeypatch, factory):
+    paths_type = _paths_type()
+    elsewhere = tmp_path / "elsewhere"
+    elsewhere.mkdir()
+    monkeypatch.chdir(tmp_path)
+    if factory == "from_market_db":
+        paths = paths_type.from_market_db("data/../data/market.db")
+    else:
+        paths = paths_type(market_db_path=Path("data/../data/market.db"))
+    monkeypatch.chdir(elsewhere)
+    assert paths.market_db_path == tmp_path / "data" / "market.db"
+    assert paths.object_path("body") == tmp_path / "data" / "market.db.sec-research" / "body"
+    assert not (tmp_path / "data").exists()
+
+
+def test_market_binding_cannot_be_reassigned(tmp_path):
+    from dataclasses import FrozenInstanceError
+
+    paths = _paths_type().from_market_db(tmp_path / "market.db")
+    with pytest.raises(FrozenInstanceError):
+        paths.market_db_path = tmp_path / "other.db"
+    assert paths.object_path("body") == tmp_path / "market.db.sec-research" / "body"
+
+
+def test_resolve_uses_market_environment_authority(tmp_path, monkeypatch):
+    paths_type = _paths_type()
+    monkeypatch.chdir(tmp_path)
+    monkeypatch.setenv("ARKSCOPE_MARKET_DB", "custom/../custom/prices.sqlite")
+    paths = paths_type.resolve()
+    monkeypatch.setenv("ARKSCOPE_MARKET_DB", str(tmp_path / "other.db"))
+    assert paths.market_db_path == tmp_path / "custom" / "prices.sqlite"
+    assert paths.object_path("body") == tmp_path / "custom" / "prices.sqlite.sec-research" / "body"
+    assert list(tmp_path.iterdir()) == []
+
+
+@pytest.mark.parametrize("env_value", [None, ""], ids=["absent", "empty"])
+def test_resolve_uses_existing_default_authority(tmp_path, monkeypatch, env_value):
+    paths_type = _paths_type()
+    from src import market_data_admin
+
+    if env_value is None:
+        monkeypatch.delenv("ARKSCOPE_MARKET_DB", raising=False)
+    else:
+        monkeypatch.setenv("ARKSCOPE_MARKET_DB", env_value)
+    monkeypatch.setattr(market_data_admin, "_PROJECT_ROOT", tmp_path / "application")
+    paths = paths_type.resolve()
+    assert paths.market_db_path == tmp_path / "application" / "data" / "market_data.db"
+    assert paths.capture_root == (
+        tmp_path / "application" / "data" / "market_data.db.sec-research"
+    )
+    assert list(tmp_path.iterdir()) == []
+
+
+def test_resolve_delegates_to_existing_market_path_resolver(tmp_path, monkeypatch):
+    paths_type = _paths_type()
+    from src import market_data_admin
+
+    monkeypatch.setattr(
+        market_data_admin, "resolve_market_db_path", lambda: str(tmp_path / "authority.db")
+    )
+    paths = paths_type.resolve()
+    assert paths.object_path("body") == tmp_path / "authority.db.sec-research" / "body"
+    assert list(tmp_path.iterdir()) == []
+
+
+def test_market_database_symlink_binds_the_target_store(tmp_path):
+    paths_type = _paths_type()
+    target = tmp_path / "real" / "market.db"
+    target.parent.mkdir()
+    target.write_bytes(b"path-only fixture, never opened as SQLite")
+    alias = tmp_path / "alias.db"
+    alias.symlink_to(target)
+    paths = paths_type.from_market_db(alias)
+    assert paths.market_db_path == target
+    assert paths.object_path("body") == tmp_path / "real" / "market.db.sec-research" / "body"
+    assert not paths.capture_root.exists()
+
+
+def test_relative_object_key_reopens_the_capture_after_relocation(tmp_path):
+    paths_type = _paths_type()
+    original = tmp_path / "original"
+    original.mkdir()
+    market = original / "market.db"
+    market.write_bytes(b"path-only database fixture")
+    root = original / "market.db.sec-research"
+    (root / "objects").mkdir(parents=True)
+    (root / "objects" / "abc.txt").write_bytes(b"retained capture")
+    old_paths = paths_type.from_market_db(market)
+    key = "objects/abc.txt"
+    assert old_paths.object_path(key).read_bytes() == b"retained capture"
+
+    moved = tmp_path / "relocated"
+    original.rename(moved)
+    new_paths = paths_type.from_market_db(moved / "market.db")
+    assert new_paths.object_path(key) == moved / "market.db.sec-research" / "objects" / "abc.txt"
+    assert new_paths.object_path(key).read_bytes() == b"retained capture"
+    assert not old_paths.object_path(key).exists()
+
+
+@pytest.mark.parametrize(
+    "key",
+    [
+        "objects/sha256/ab/abcdef0123.html",
+        "text/canonical-1_utf8.txt",
+        "objects/a..b",
+        "objects/%2e%2e.txt",
+        "objects/\u6587\u672c.txt",
+    ],
+    ids=["nested-hash", "canonical-text", "embedded-dots", "literal-percent", "unicode-name"],
+)
+def test_safe_relative_object_keys_are_resolved_without_writes(tmp_path, key):
+    paths = _paths_type().from_market_db(tmp_path / "market.db")
+    assert paths.object_path(key) == tmp_path / "market.db.sec-research" / key
+    assert list(tmp_path.iterdir()) == []
+
+
+@pytest.mark.parametrize(
+    "key",
+    [
+        pytest.param("", id="empty"),
+        pytest.param(".", id="dot"),
+        pytest.param("..", id="parent"),
+        pytest.param("../escape", id="parent-prefix"),
+        pytest.param("objects/../../escape", id="nested-traversal"),
+        pytest.param("objects/../body", id="contained-traversal"),
+        pytest.param("./body", id="dot-prefix"),
+        pytest.param("objects/./body", id="dot-component"),
+        pytest.param("objects//body", id="empty-component"),
+        pytest.param("objects/body/", id="trailing-separator"),
+        pytest.param("/outside/body", id="posix-absolute"),
+        pytest.param("//server/share/body", id="forward-unc"),
+        pytest.param("C:/outside/body", id="windows-forward-drive"),
+        pytest.param(r"C:\outside\body", id="windows-drive"),
+        pytest.param("C:body", id="windows-drive-relative"),
+        pytest.param("C:", id="windows-drive-only"),
+        pytest.param(r"\outside", id="windows-rooted"),
+        pytest.param(r"\\server\share\body", id="windows-unc"),
+        pytest.param(r"\\?\C:\outside", id="windows-extended-drive"),
+        pytest.param(r"\\?\UNC\server\share\body", id="windows-extended-unc"),
+        pytest.param(r"\\.\device", id="windows-device-path"),
+        pytest.param(r"objects\..\escape", id="windows-traversal"),
+        pytest.param(r"objects\body", id="windows-separator"),
+        pytest.param("objects/C:body", id="nested-drive-or-stream"),
+        pytest.param("objects/body:stream", id="alternate-stream"),
+        pytest.param("objects/body\x00", id="nul"),
+        pytest.param("objects/body\n", id="newline"),
+        pytest.param("objects/\x1fbody", id="control-character"),
+        pytest.param("objects/body\x7f", id="delete-character"),
+        pytest.param("objects/body.", id="trailing-dot"),
+        pytest.param("objects/body ", id="trailing-space"),
+        pytest.param("objects/CON", id="reserved-device"),
+        pytest.param("objects/nul.txt", id="reserved-device-extension"),
+        pytest.param("AUX/body", id="reserved-directory"),
+        pytest.param("objects/COM1", id="reserved-port"),
+        pytest.param("objects/a?b", id="question-mark"),
+        pytest.param("objects/a*b", id="asterisk"),
+        pytest.param("objects/a<b", id="left-angle"),
+        pytest.param("objects/a>b", id="right-angle"),
+        pytest.param('objects/a"b', id="double-quote"),
+        pytest.param("objects/a|b", id="pipe"),
+        pytest.param(None, id="null"),
+        pytest.param(1, id="integer"),
+        pytest.param(b"objects/body", id="bytes"),
+        pytest.param(Path("objects/body"), id="path-object"),
+    ],
+)
+def test_object_path_rejects_unsafe_or_malformed_keys(tmp_path, key):
+    paths = _paths_type().from_market_db(tmp_path / "market.db")
+    with pytest.raises(ValueError):
+        paths.object_path(key)
+    assert list(tmp_path.iterdir()) == []
+
+
+@pytest.mark.parametrize(
+    "kind", ["directory", "file", "dangling", "chain", "prefix-sibling", "capture-root"]
+)
+def test_object_path_rejects_symlink_escape(tmp_path, kind):
+    paths = _paths_type().from_market_db(tmp_path / "market.db")
+    root = tmp_path / "market.db.sec-research"
+    outside = tmp_path / ("market.db.sec-research-other" if kind == "prefix-sibling" else "outside")
+    outside.mkdir()
+    (outside / "body").write_bytes(b"outside sentinel")
+    if kind == "capture-root":
+        root.symlink_to(outside, target_is_directory=True)
+        key = "body"
+    else:
+        root.mkdir()
+        if kind == "file":
+            (root / "link").symlink_to(outside / "body")
+            key = "link"
+        elif kind == "dangling":
+            (root / "link").symlink_to(outside / "missing", target_is_directory=True)
+            key = "link/body"
+        elif kind == "chain":
+            (root / "link").symlink_to(root / "second", target_is_directory=True)
+            (root / "second").symlink_to(outside, target_is_directory=True)
+            key = "link/body"
+        else:
+            (root / "link").symlink_to(outside, target_is_directory=True)
+            key = "link/body"
+    with pytest.raises(ValueError):
+        paths.object_path(key)
+    assert (outside / "body").read_bytes() == b"outside sentinel"
+    assert not (outside / "missing").exists()
+
+
+def test_object_path_rejects_preexisting_capture_root_symlink(tmp_path):
+    paths_type = _paths_type()
+    outside = tmp_path / "outside"
+    outside.mkdir()
+    (outside / "body").write_bytes(b"outside sentinel")
+    root = tmp_path / "market.db.sec-research"
+    root.symlink_to(outside, target_is_directory=True)
+    paths = paths_type.from_market_db(tmp_path / "market.db")
+    assert paths.capture_root == root
+    with pytest.raises(ValueError):
+        paths.object_path("body")
+    assert (outside / "body").read_bytes() == b"outside sentinel"
+
+
+def test_object_path_allows_symlinks_that_stay_beneath_the_capture_root(tmp_path):
+    paths = _paths_type().from_market_db(tmp_path / "market.db")
+    root = tmp_path / "market.db.sec-research"
+    (root / "objects").mkdir(parents=True)
+    (root / "objects" / "body").write_bytes(b"inside capture")
+    (root / "alias").symlink_to("objects", target_is_directory=True)
+    assert paths.object_path("alias/body") == root / "objects" / "body"
+    assert paths.object_path("alias/body").read_bytes() == b"inside capture"
+
+
+def test_object_path_does_not_accept_a_symlink_to_the_root_as_an_object(tmp_path):
+    paths = _paths_type().from_market_db(tmp_path / "market.db")
+    root = tmp_path / "market.db.sec-research"
+    root.mkdir()
+    (root / "alias").symlink_to(".", target_is_directory=True)
+    with pytest.raises(ValueError):
+        paths.object_path("alias")
+
+
+def test_object_path_rejects_symlink_loops_as_invalid_keys(tmp_path):
+    paths = _paths_type().from_market_db(tmp_path / "market.db")
+    root = tmp_path / "market.db.sec-research"
+    root.mkdir()
+    (root / "first").symlink_to("second")
+    (root / "second").symlink_to("first")
+    with pytest.raises(ValueError):
+        paths.object_path("first/body")

```
