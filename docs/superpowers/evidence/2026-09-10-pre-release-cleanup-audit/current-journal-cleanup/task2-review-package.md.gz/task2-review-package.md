# Review task2

Base: 2842c497dabfdb0b13c315e22b206128eba9f57d
Head: frozen uncommitted task snapshot.

## Commits Since Base

## Scope And Current File Hashes
```json
{
  "src/sqlite_backup.py": "0c3ebdf4e8aae9c5aa58c4d603504eafcb3fb0d988c584505716ac3204abcaac",
  "src/lifecycle_investigation/migration.py": "38c59bbee553528ef5f6d096823fbb14e6cb03dfeaca02d685268119f1dbe1e6",
  "src/lifecycle_investigation/disposal.py": "8cf0c7394b7b89686aa3dea8334132329cea7001fefaa6748c8711dd3151ddef",
  "src/security_lifecycle_population.py": "454458eca84f21f148c76b847e709ebefed3f05c13d5df774a71e63ed4d6e3ee",
  "src/security_lifecycle_current.py": "ea25f82c1125b4d3563a7bf206610ca0215575f3370331c810d9c3e3ddbf5aaa",
  "src/lifecycle_web_schema.py": null,
  "src/lifecycle_web_migration.py": null,
  "tests/test_sqlite_backup.py": "6d3d1b724e1a493cdeef326339ddfa917cd26b65f9e79f5cb5ca84a6cad5f985",
  "tests/test_lifecycle_investigation_retirement.py": "dd9f21ea82d5d1cca7749e21904e050005efe40b42ecffc89e0456173322fd67",
  "tests/test_security_lifecycle_population.py": "cad6542d5aefb3d2f303ccc09d8bf6daf2ac4b91310009ea802ef2b5f85d28dd",
  "tests/test_security_lifecycle_current.py": "159d7ce61663903a2e41f81e9ae1c5453974900a9ba16af8903bca6724c5d590",
  "tests/test_lifecycle_web_migration.py": null
}
```

## Stat
```text
 src/lifecycle_investigation/disposal.py          |  19 +--
 src/lifecycle_investigation/migration.py         |   4 +-
 src/lifecycle_web_migration.py                   |  94 ------------
 src/lifecycle_web_schema.py                      | 143 ------------------
 src/security_lifecycle_current.py                |  14 +-
 src/security_lifecycle_population.py             |  35 +----
 src/sqlite_backup.py                             |  14 ++
 tests/test_lifecycle_investigation_retirement.py |  47 ++++--
 tests/test_lifecycle_web_migration.py            |  80 ----------
 tests/test_security_lifecycle_current.py         |   6 +-
 tests/test_security_lifecycle_population.py      |  30 ++++
 tests/test_sqlite_backup.py                      | 183 +++++++++++++++++++++++
 12 files changed, 279 insertions(+), 390 deletions(-)

```

## Patch
```diff
diff --git a/src/lifecycle_investigation/disposal.py b/src/lifecycle_investigation/disposal.py
index 7d04bff5..ddb6e390 100644
--- a/src/lifecycle_investigation/disposal.py
+++ b/src/lifecycle_investigation/disposal.py
@@ -1,42 +1,41 @@
 """Digest-bound, dependency-aware disposal. Each database has its own atomic receipt.
 
 Two WAL databases do not offer a crash-atomic shared commit. Stages are therefore
 explicit, independently resumable, and never reported as one completed operation.
 """
 
 from collections import defaultdict
 from contextlib import contextmanager
 from datetime import datetime, timezone
 from pathlib import Path
 import json
 import sqlite3
 
 from src.lifecycle_investigation.schema import verify_journal
-from src.lifecycle_web_migration import _backup
-from src.lifecycle_web_schema import TABLES as WEB_TABLES, TRIGGERS as WEB_TRIGGERS
 from src.lifecycle_journal_codec import canonical_json, digest_json
 from src.security_lifecycle_listing_migration import _quote_identifier as q, _sha_file
 from src.security_lifecycle_schema import PROFILE_TABLE_SQL, verify_profile_connection, verify_market_connection, _normalize_sql
+from src.sqlite_backup import backup_connection
 
 
-OWNED = (set(PROFILE_TABLE_SQL) | set(WEB_TABLES)) - {"security_lifecycle_provider_checks", "security_lifecycle_migration_receipts"}
+OWNED = set(PROFILE_TABLE_SQL) - {"security_lifecycle_provider_checks", "security_lifecycle_migration_receipts"}
 RECEIPT_SQL = """CREATE TABLE lifecycle_legacy_disposal_receipts (
     approval_sha256 TEXT PRIMARY KEY, stage TEXT NOT NULL CHECK(stage IN ('market','profile')),
     completed_at TEXT NOT NULL, receipt_json TEXT NOT NULL, receipt_sha256 TEXT NOT NULL)"""
 RECEIPT_TRIGGERS = {f"lifecycle_legacy_disposal_receipts_{op.lower()}": f"""CREATE TRIGGER lifecycle_legacy_disposal_receipts_{op.lower()}
     BEFORE {op} ON lifecycle_legacy_disposal_receipts BEGIN SELECT RAISE(ABORT,'disposal_receipt_immutable'); END""" for op in ("UPDATE", "DELETE")}
 
 
 def _receipt(conn, approval, stage):
     row = conn.execute("SELECT sql FROM sqlite_master WHERE name='lifecycle_legacy_disposal_receipts'").fetchone()
     if row is None:
         return None
     if _normalize_sql(row[0]) != _normalize_sql(RECEIPT_SQL):
         raise ValueError("disposal_receipt_invalid")
     for name, sql in RECEIPT_TRIGGERS.items():
         row = conn.execute("SELECT sql FROM sqlite_master WHERE name=?", (name,)).fetchone()
         if not row or _normalize_sql(row[0]) != _normalize_sql(sql):
             raise ValueError("disposal_receipt_invalid")
     row = conn.execute("SELECT stage,receipt_json,receipt_sha256 FROM lifecycle_legacy_disposal_receipts WHERE approval_sha256=?", (approval,)).fetchone()
     if row is None:
         return None
@@ -74,41 +73,41 @@ def foreign_keys(conn):
             edges.append((table, ordered[0][2], tuple((row[3], row[4]) for row in ordered)))
     return edges
 
 
 def closure(conn, case_id):
     row = conn.execute("SELECT rowid AS _rowid_,* FROM security_lifecycle_cases WHERE case_id=? AND source='sec_edgar'", (case_id,)).fetchone()
     if row is None:
         raise ValueError("disposal_changed")
     result, pending = defaultdict(dict), [("security_lifecycle_cases", dict(row))]
     edges = foreign_keys(conn)
     reason = None
     while pending:
         table, row = pending.pop()
         if row["_rowid_"] in result[table]:
             continue
         result[table][row["_rowid_"]] = row
         if row.get("case_id", case_id) != case_id:
             reason = "cross_case_dependency"
         if table == "security_lifecycle_assessments" and row.get("acceptance_authority") == "human":
             reason = "human_assessment"
-        if table in {"security_lifecycle_automation_runs", "security_lifecycle_investigation_runs", "lifecycle_web_runs"} and row.get("status") in {"running", "queued", "searching", "reading_sources", "analyzing", "cancelling", "remote_outcome_unknown"}:
+        if table in {"security_lifecycle_automation_runs", "security_lifecycle_investigation_runs"} and row.get("status") in {"running", "queued", "searching", "reading_sources", "analyzing", "cancelling", "remote_outcome_unknown"}:
             reason = "unfinished_execution"
         for child, parent, columns in edges:
             if parent != table:
                 continue
             if any(parent_col is None for _, parent_col in columns):
                 reason = "unreviewed_foreign_key"
                 continue
             predicate = " AND ".join(f"{q(child_col)}=?" for child_col, _ in columns)
             params = tuple(row[parent_col] for _, parent_col in columns)
             if child not in OWNED:
                 if conn.execute(f"SELECT 1 FROM {q(child)} WHERE {predicate} LIMIT 1", params).fetchone():
                     reason = "retained_external_dependency"
                 continue
             children = conn.execute(f"SELECT rowid AS _rowid_,* FROM {q(child)} WHERE {predicate}", params).fetchall()
             for item in children:
                 child_row = dict(item)
                 assessment = child_row.get("assessment_id")
                 if assessment:
                     owner = conn.execute("SELECT case_id FROM security_lifecycle_assessments WHERE assessment_id=?", (assessment,)).fetchone()
                     if owner and owner[0] != case_id:
@@ -217,60 +216,50 @@ def apply_disposal_stage(path, plan, *, stage, approval_sha256, backup_path, app
         exists = conn.execute("SELECT 1 FROM sqlite_master WHERE name='lifecycle_legacy_disposal_receipts'").fetchone()
         receipt = _receipt(conn, approval_sha256, stage)
         if receipt is not None:
             if stage == "profile":
                 reappeared = any(conn.execute("SELECT 1 FROM security_lifecycle_cases WHERE case_id=?", (identity,)).fetchone() for identity in plan["roots"])
             else:
                 reappeared = any(conn.execute("SELECT 1 FROM security_lifecycle_observations WHERE id=?", (identity,)).fetchone() for identity in plan["stages"]["market"]["observation_ids"])
             if reappeared:
                 raise ValueError("disposal_changed")
             return {**receipt, "status": "already_completed"}
         if stage == "profile":
             verify_journal(conn)
         expected = plan["stages"][stage]
         def observed():
             return profile_scope(conn, plan["roots"]) if stage == "profile" else market_scope(conn, expected["observation_ids"])
         if observed() != expected:
             raise ValueError("disposal_changed")
         backup = Path(backup_path).resolve()
         if backup == Path(path).resolve():
             raise ValueError("disposal_backup_path")
-        _backup(conn, backup)
+        backup_connection(conn, backup)
         conn.execute("BEGIN IMMEDIATE")
         try:
             if observed() != expected:
                 raise ValueError("disposal_changed")
             if not exists:
                 conn.execute(RECEIPT_SQL)
                 for sql in RECEIPT_TRIGGERS.values():
                     conn.execute(sql)
             if stage == "profile":
-                dropped = []
-                for name, sql in WEB_TRIGGERS.items():
-                    owner = conn.execute("SELECT tbl_name,sql FROM sqlite_master WHERE name=?", (name,)).fetchone()
-                    if owner and owner[0] in expected:
-                        if _normalize_sql(owner[1]) != _normalize_sql(sql):
-                            raise ValueError("disposal_changed")
-                        conn.execute(f"DROP TRIGGER {q(name)}")
-                        dropped.append(sql)
                 for table in _delete_order(conn, expected):
                     conn.executemany(f"DELETE FROM {q(table)} WHERE rowid=?", [(identity,) for identity in expected[table]["rowids"]])
-                for sql in dropped:
-                    conn.execute(sql)
                 verify_profile_connection(conn)
                 verify_journal(conn)
             else:
                 conn.executemany("DELETE FROM security_lifecycle_observation_kinds WHERE observation_id=?", [(i,) for i in expected["observation_ids"]])
                 conn.executemany("DELETE FROM security_lifecycle_observations WHERE id=?", [(i,) for i in expected["observation_ids"]])
                 verify_market_connection(conn)
             if conn.execute("PRAGMA foreign_key_check").fetchone():
                 raise ValueError("disposal_foreign_key")
             receipt = {"status": "completed", "stage": stage, "approval_sha256": approval_sha256,
                 "backup_sha256": _sha_file(backup),
                 "counts": {table: len(value["rowids"]) for table, value in expected.items()} if stage == "profile" else {"observations": len(expected["observation_ids"])}}
             conn.execute("INSERT INTO lifecycle_legacy_disposal_receipts VALUES(?,?,?,?,?)",
                 (approval_sha256, stage, datetime.now(timezone.utc).isoformat(), canonical_json(receipt), digest_json(receipt)))
             conn.commit()
             return receipt
         except BaseException:
             conn.rollback()
             raise
diff --git a/src/lifecycle_investigation/migration.py b/src/lifecycle_investigation/migration.py
index f07fe084..0e7666c4 100644
--- a/src/lifecycle_investigation/migration.py
+++ b/src/lifecycle_investigation/migration.py
@@ -1,33 +1,33 @@
 """Explicit backed-up journal cutover, with unchanged existing profile contents."""
 
 from contextlib import closing
 import hashlib
 from pathlib import Path
 import sqlite3
 
 from src.lifecycle_investigation.schema import installed, schema_digest, verify_journal, _install_on_connection
 from src.lifecycle_journal_codec import digest_json
-from src.lifecycle_web_migration import _backup
 from src.security_lifecycle_listing_migration import _encode_cell, _quote_identifier as q, _sha_file
 from src.security_lifecycle_provider_snapshot import instant
 from src.security_lifecycle_schema import verify_profile_connection, assert_lifecycle_writes_available
+from src.sqlite_backup import backup_connection
 
 
 def _snapshot(conn, names=None):
     schema = [tuple(row) for row in conn.execute("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name")
         if names is None or row[2] in names]
     rows = hashlib.sha256()
     for kind, name, _, _ in schema:
         if kind != "table":
             continue
         rows.update(_encode_cell(name))
         primary = sorted((row[5], row[1]) for row in conn.execute(f"PRAGMA table_info({q(name)})") if row[5])
         order = ",".join(q(column) for _, column in primary) or "rowid"
         for row in conn.execute(f"SELECT * FROM {q(name)} ORDER BY {order}"):
             rows.update(b"row:")
             for cell in row:
                 value = _encode_cell(cell)
                 rows.update(str(len(value)).encode() + b":" + value)
     return {"schema_sha256": digest_json(schema), "rows_sha256": rows.hexdigest()}
 
 
@@ -47,38 +47,38 @@ def preview_installation(path):
         conn.execute("PRAGMA query_only=ON")
         conn.execute("BEGIN")
         return _preview(conn)
 
 
 def apply_installation(path, *, backup_path, approval_sha256, at, app_stopped):
     if app_stopped is not True:
         raise ValueError("investigation_install_app_stop_required")
     instant(at)
     path, backup = Path(path).resolve(), Path(backup_path).resolve()
     if path == backup:
         raise ValueError("investigation_install_backup_path")
     with closing(sqlite3.connect(path.as_uri() + "?mode=rw", uri=True, timeout=10)) as conn:
         conn.execute("PRAGMA foreign_keys=ON")
         before = _preview(conn)
         if before["approval_sha256"] != approval_sha256:
             raise ValueError("investigation_install_changed")
         assert_lifecycle_writes_available(conn)
         if before["installed"]:
             return {"changed": False, **before}
-        _backup(conn, backup)
+        backup_connection(conn, backup)
         if preview_installation(backup) != before:
             raise ValueError("investigation_install_backup_changed")
         conn.execute("BEGIN IMMEDIATE")
         try:
             if _preview(conn) != before:
                 raise ValueError("investigation_install_changed")
             names = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
             old = _snapshot(conn, names)
             _install_on_connection(conn, at=at)
             if _snapshot(conn, names) != old:
                 raise ValueError("investigation_install_existing_data_changed")
             conn.commit()
         except BaseException:
             conn.rollback()
             raise
     return {"changed": True, "approval_sha256": approval_sha256, "target_schema_sha256": schema_digest(),
         "backup_sha256": _sha_file(backup), "installed_at": at}
diff --git a/src/lifecycle_web_migration.py b/src/lifecycle_web_migration.py
deleted file mode 100644
index b3108305..00000000
--- a/src/lifecycle_web_migration.py
+++ /dev/null
@@ -1,94 +0,0 @@
-"""Attended, backed-up Web journal installation; never a profile bootstrap."""
-
-import hashlib
-import json
-import os
-from pathlib import Path
-import re
-import sqlite3
-
-from src.lifecycle_web_schema import _install_on_connection, schema_digest, verify_web_journal
-from src.security_lifecycle_listing_migration import _encode_cell, _quote_identifier, _sha_file
-from src.security_lifecycle_provider_snapshot import instant
-from src.security_lifecycle_schema import assert_lifecycle_writes_available, verify_profile_connection
-
-
-def _snapshot(conn, *, exclude_web=False):
-    schema = [tuple(row) for row in conn.execute("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name")]
-    if exclude_web:
-        schema = [row for row in schema if not row[2].startswith("lifecycle_web_")]
-    schema_sha = hashlib.sha256(json.dumps(schema, ensure_ascii=True, separators=(",", ":")).encode()).hexdigest()
-    rows = hashlib.sha256()
-    for kind, name, _, _ in schema:
-        if kind != "table":
-            continue
-        rows.update(_encode_cell(name))
-        for row in conn.execute(f"SELECT * FROM {_quote_identifier(name)} ORDER BY rowid"):
-            rows.update(b"row:")
-            for cell in row:
-                value = _encode_cell(cell)
-                rows.update(str(len(value)).encode() + b":" + value)
-    return schema_sha, rows.hexdigest()
-
-
-def _preview(conn):
-    verify_profile_connection(conn)
-    if conn.execute("PRAGMA integrity_check").fetchall() != [("ok",)] or conn.execute("PRAGMA foreign_key_check").fetchone():
-        raise ValueError("web_installation_integrity")
-    installed = bool(conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name LIKE 'lifecycle_web_%'").fetchone())
-    if installed:
-        verify_web_journal(conn)
-    schema_sha, rows_sha = _snapshot(conn)
-    value = {"version": 1, "installed": installed, "schema_sha256": schema_sha, "rows_sha256": rows_sha, "target_schema_sha256": schema_digest()}
-    return {**value, "approval_sha256": hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()}
-
-
-def preview_web_installation(path):
-    with sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True) as conn:
-        conn.execute("PRAGMA query_only=ON")
-        conn.execute("BEGIN")
-        return _preview(conn)
-
-
-def _backup(conn, path):
-    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
-    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
-    os.close(fd)
-    with sqlite3.connect(path) as destination:
-        conn.backup(destination)
-
-
-def apply_web_installation(path, *, backup_path, approval_sha256, at, app_stopped):
-    if app_stopped is not True:
-        raise ValueError("web_installation_app_stop_required")
-    instant(at)
-    if not isinstance(approval_sha256, str) or not re.fullmatch("[0-9a-f]{64}", approval_sha256):
-        raise ValueError("web_installation_approval_invalid")
-    path, backup = Path(path).resolve(), Path(backup_path).resolve()
-    if path == backup:
-        raise ValueError("web_installation_backup_path")
-    with sqlite3.connect(path.as_uri() + "?mode=rw", uri=True, timeout=10) as conn:
-        conn.execute("PRAGMA foreign_keys=ON")
-        before = _preview(conn)
-        if before["approval_sha256"] != approval_sha256:
-            raise ValueError("web_installation_preview_changed")
-        assert_lifecycle_writes_available(conn)
-        if before["installed"]:
-            return {"changed": False, **before}
-        _backup(conn, backup)
-        if preview_web_installation(backup)["approval_sha256"] != approval_sha256:
-            raise ValueError("web_installation_backup_changed")
-        conn.execute("BEGIN IMMEDIATE")
-        try:
-            if _preview(conn)["approval_sha256"] != approval_sha256:
-                raise ValueError("web_installation_preview_changed")
-            _install_on_connection(conn, at=at)
-            if _snapshot(conn, exclude_web=True) != (before["schema_sha256"], before["rows_sha256"]):
-                raise ValueError("web_installation_existing_data_changed")
-            after = _preview(conn)
-            conn.commit()
-        except BaseException:
-            conn.rollback()
-            raise
-    return {"changed": True, **after, "previous_approval_sha256": approval_sha256,
-            "previous_rows_sha256": before["rows_sha256"], "backup_sha256": _sha_file(backup), "installed_at": at}
diff --git a/src/lifecycle_web_schema.py b/src/lifecycle_web_schema.py
deleted file mode 100644
index 96457595..00000000
--- a/src/lifecycle_web_schema.py
+++ /dev/null
@@ -1,143 +0,0 @@
-"""Explicit installation of the independent, model-authored Web journal."""
-
-import hashlib
-import sqlite3
-
-from src.security_lifecycle_schema import _normalize_sql, assert_lifecycle_writes_available, verify_profile_connection
-
-
-class WebJournalError(RuntimeError):
-    def __init__(self, code):
-        self.code = code
-        super().__init__(code)
-
-
-RUNNING = ("queued", "searching", "reading_sources", "analyzing")
-TERMINAL = ("succeeded", "failed", "cancelled", "remote_outcome_unknown")
-
-INVENTORY_FIELDS = {
-    "runs": ("run_id", "case_id", "header_sha256", "created_at", "lease_until", "status", "cancel_requested_at", "finished_at", "failure_code"),
-    "calls": ("run_id", "call_id", "terminal"),
-    "actions": ("run_id", "call_id", "item_id", "kind"),
-    "pages": ("run_id", "source_id", "page_sha256"),
-    "results": ("run_id", "result_sha256", "completed_at"),
-    "acceptances": ("assessment_id", "run_id", "packet_sha256", "actor", "confirmed_at"),
-}
-
-
-TABLES = {
-    "lifecycle_web_installation": """CREATE TABLE lifecycle_web_installation (
-        singleton INTEGER PRIMARY KEY CHECK(singleton=1), version INTEGER NOT NULL CHECK(version=1),
-        schema_sha256 TEXT NOT NULL, installed_at TEXT NOT NULL)""",
-    "lifecycle_web_runs": """CREATE TABLE lifecycle_web_runs (
-        run_id TEXT PRIMARY KEY, case_id TEXT NOT NULL REFERENCES security_lifecycle_cases(case_id),
-        request_key TEXT NOT NULL UNIQUE, header_json TEXT NOT NULL, header_sha256 TEXT NOT NULL CHECK(length(header_sha256)=64),
-        owner TEXT NOT NULL, created_at TEXT NOT NULL, lease_until TEXT NOT NULL,
-        status TEXT NOT NULL CHECK(status IN ('queued','searching','reading_sources','analyzing','succeeded','failed','cancelled','remote_outcome_unknown')),
-        cancel_requested_at TEXT, finished_at TEXT, failure_code TEXT,
-        CHECK((status IN ('queued','searching','reading_sources','analyzing') AND finished_at IS NULL AND failure_code IS NULL)
-           OR (status='succeeded' AND finished_at IS NOT NULL AND failure_code IS NULL)
-           OR (status IN ('failed','cancelled','remote_outcome_unknown') AND finished_at IS NOT NULL AND failure_code IS NOT NULL)))""",
-    "lifecycle_web_calls": """CREATE TABLE lifecycle_web_calls (
-        run_id TEXT NOT NULL REFERENCES lifecycle_web_runs(run_id), call_id TEXT NOT NULL CHECK(call_id IN ('search-1','analysis-1')),
-        remote_id TEXT, terminal TEXT CHECK(terminal IS NULL OR terminal IN ('completed','failed','cancelled','interrupted')),
-        PRIMARY KEY(run_id,call_id), UNIQUE(run_id,remote_id), CHECK(terminal IS NULL OR remote_id IS NOT NULL))""",
-    "lifecycle_web_actions": """CREATE TABLE lifecycle_web_actions (
-        run_id TEXT NOT NULL, call_id TEXT NOT NULL, item_id TEXT NOT NULL,
-        kind TEXT NOT NULL CHECK(kind IN ('search','open_page','find_in_page')), PRIMARY KEY(run_id,call_id,item_id),
-        FOREIGN KEY(run_id,call_id) REFERENCES lifecycle_web_calls(run_id,call_id))""",
-    "lifecycle_web_pages": """CREATE TABLE lifecycle_web_pages (
-        run_id TEXT NOT NULL REFERENCES lifecycle_web_runs(run_id), source_id TEXT NOT NULL,
-        page_json TEXT NOT NULL, page_sha256 TEXT NOT NULL CHECK(length(page_sha256)=64), PRIMARY KEY(run_id,source_id))""",
-    "lifecycle_web_results": """CREATE TABLE lifecycle_web_results (
-        run_id TEXT PRIMARY KEY REFERENCES lifecycle_web_runs(run_id), payload_json TEXT NOT NULL,
-        result_sha256 TEXT NOT NULL CHECK(length(result_sha256)=64), completed_at TEXT NOT NULL)""",
-    "lifecycle_web_acceptances": """CREATE TABLE lifecycle_web_acceptances (
-        assessment_id TEXT PRIMARY KEY REFERENCES security_lifecycle_assessments(assessment_id),
-        run_id TEXT NOT NULL UNIQUE REFERENCES lifecycle_web_results(run_id),
-        packet_json TEXT NOT NULL, packet_sha256 TEXT NOT NULL CHECK(length(packet_sha256)=64),
-        actor TEXT NOT NULL CHECK(actor='attended_user'), confirmed_at TEXT NOT NULL)""",
-}
-INDEXES = {"idx_lifecycle_web_active_case": """CREATE UNIQUE INDEX idx_lifecycle_web_active_case
-    ON lifecycle_web_runs(case_id) WHERE status IN ('queued','searching','reading_sources','analyzing')"""}
-TRIGGERS = {
-    f"{name}_{operation.lower()}_immutable": f"""CREATE TRIGGER {name}_{operation.lower()}_immutable BEFORE {operation} ON {name}
-    BEGIN SELECT RAISE(ABORT,'web_immutable_record'); END"""
-    for name in ("lifecycle_web_installation", "lifecycle_web_pages", "lifecycle_web_results", "lifecycle_web_acceptances", "lifecycle_web_actions")
-    for operation in ("UPDATE", "DELETE")
-}
-TRIGGERS["lifecycle_web_runs_identity_immutable"] = """CREATE TRIGGER lifecycle_web_runs_identity_immutable
-    BEFORE UPDATE OF run_id,case_id,request_key,header_json,header_sha256,owner,created_at ON lifecycle_web_runs
-    BEGIN SELECT RAISE(ABORT,'web_immutable_record'); END"""
-TRIGGERS["lifecycle_web_runs_delete_immutable"] = """CREATE TRIGGER lifecycle_web_runs_delete_immutable BEFORE DELETE ON lifecycle_web_runs
-    BEGIN SELECT RAISE(ABORT,'web_immutable_record'); END"""
-TRIGGERS["lifecycle_web_calls_terminal_immutable"] = """CREATE TRIGGER lifecycle_web_calls_terminal_immutable BEFORE UPDATE ON lifecycle_web_calls
-    WHEN OLD.run_id<>NEW.run_id OR OLD.call_id<>NEW.call_id
-      OR (OLD.remote_id IS NOT NULL AND (NEW.remote_id IS NULL OR OLD.remote_id<>NEW.remote_id))
-      OR (OLD.terminal IS NOT NULL AND (NEW.terminal IS NULL OR OLD.terminal<>NEW.terminal))
-    BEGIN SELECT RAISE(ABORT,'web_immutable_record'); END"""
-TRIGGERS["lifecycle_web_calls_delete_immutable"] = """CREATE TRIGGER lifecycle_web_calls_delete_immutable BEFORE DELETE ON lifecycle_web_calls
-    BEGIN SELECT RAISE(ABORT,'web_immutable_record'); END"""
-
-
-def schema_digest():
-    return hashlib.sha256("\n".join(f"{name}:{_normalize_sql(sql)}" for name, sql in sorted({**TABLES, **INDEXES, **TRIGGERS}.items())).encode()).hexdigest()
-
-
-def verify_web_journal(conn):
-    for kind, expected, pattern in (("table", TABLES, "lifecycle_web_%"), ("index", INDEXES, "idx_lifecycle_web_%"),
-                                     ("trigger", TRIGGERS, "lifecycle_web_%")):
-        actual = dict(conn.execute("SELECT name,sql FROM sqlite_master WHERE type=? AND name LIKE ? AND sql IS NOT NULL", (kind, pattern)))
-        if kind == "table" and not actual:
-            raise WebJournalError("web_journal_not_installed")
-        if {name: _normalize_sql(sql) for name, sql in actual.items()} != {name: _normalize_sql(sql) for name, sql in expected.items()}:
-            raise WebJournalError("web_journal_schema_mismatch")
-    row = conn.execute("SELECT version,schema_sha256 FROM lifecycle_web_installation WHERE singleton=1").fetchone()
-    if row is None or tuple(row) != (1, schema_digest()):
-        raise WebJournalError("web_journal_schema_mismatch")
-
-
-def read_web_inventory(conn):
-    """Internal retention metadata; no full pages, model prose or credentials."""
-    installed = bool(conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name LIKE 'lifecycle_web_%'").fetchone())
-    result = {"installed": installed, **{key: [] for key in INVENTORY_FIELDS}}
-    if installed:
-        verify_web_journal(conn)
-        for key, fields in INVENTORY_FIELDS.items():
-            result[key] = [dict(zip(fields, row)) for row in conn.execute(
-                f"SELECT {','.join(fields)} FROM lifecycle_web_{key} ORDER BY rowid")]
-    return result
-
-
-def install_web_journal(conn, *, at):
-    from src.security_lifecycle_provider_snapshot import instant
-    instant(at)
-    if conn.in_transaction:
-        raise WebJournalError("web_installation_transaction_open")
-    conn.execute("PRAGMA foreign_keys=ON")
-    verify_profile_connection(conn)
-    assert_lifecycle_writes_available(conn)
-    if conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name LIKE 'lifecycle_web_%'").fetchone():
-        verify_web_journal(conn)
-        return
-    conn.execute("BEGIN IMMEDIATE")
-    try:
-        _install_on_connection(conn, at=at)
-        conn.commit()
-    except BaseException:
-        conn.rollback()
-        raise
-
-
-def _install_on_connection(conn, *, at):
-    from src.security_lifecycle_provider_snapshot import instant
-    instant(at)
-    if not conn.in_transaction:
-        raise WebJournalError("web_installation_transaction_required")
-    verify_profile_connection(conn)
-    assert_lifecycle_writes_available(conn)
-    for statement in (*TABLES.values(), *INDEXES.values(), *TRIGGERS.values()):
-        conn.execute(statement)
-    conn.execute("INSERT INTO lifecycle_web_installation VALUES (1,1,?,?)", (schema_digest(), at))
-    verify_web_journal(conn)
-    verify_profile_connection(conn)
diff --git a/src/security_lifecycle_current.py b/src/security_lifecycle_current.py
index a68959a3..dd8c0ff3 100644
--- a/src/security_lifecycle_current.py
+++ b/src/security_lifecycle_current.py
@@ -256,78 +256,70 @@ def _project(snapshot, manifest, sources, conn):
             "listing": {"state": review["listing_state"], "basis": review["listing_basis"], "ended_on": review["listing_end_date"]},
             "continuation": {"state": review["continuation_state"], "successor_ticker": review["successor_ticker"],
                              "candidate_tickers": list(review["candidate_tickers"])},
             "observed_at": observed_at, "next_check_at": next_check,
             "diagnostics": diagnostics, "next_action": action, "source_checks": _source_checks(check),
             "source_notices": [{"form": case["observation"]["filing_form"], "filed_on": case["observation"]["filing_date"],
                                 "text": case["observation"]["description"] or None, "url": _source_url(case["observation"]["evidence_url"])}
                                for case in members if case["source"] == "sec_edgar" and case.get("observation")],
         })
     active = {ticker for ticker, row in latest.items() if classify_provider_listing(
         ticker=ticker, evidence=row["evidence"], today=instant(snapshot["at"]).date(), provider_codes=row["blockers"]).listing_state == "active"}
     tracked_count = len(sources) if sources is not None else None
     active_count = len(active.intersection(sources)) if sources is not None else None
     return {"version": 1, "as_of": snapshot["at"], "source_context": "unavailable" if sources is None else "available",
             "coverage": {"tracked": tracked_count, "confirmed_active": active_count,
                          "unconfirmed": tracked_count - active_count if tracked_count is not None else None},
             "counts": {"attention": sum(row["bucket"] == "attention" for row in items), "history": sum(row["bucket"] == "history" for row in items)},
             "items": sorted(items, key=lambda row: (row["ticker"], row["review_id"]))}
 
 
-def _read(service, *, at, web_review_id=None):
+def _read(service, *, at):
     at = at if at is not None else datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
     paths = (Path(service.market_db_path), Path(service.profile_db_path))
     try:
         identities = [(path.stat().st_dev, path.stat().st_ino) for path in paths]
         with ExitStack() as stack:
             connections = []
             for path in paths:
                 conn = sqlite3.connect(f"{path.resolve().as_uri()}?mode=ro", uri=True)
                 stack.callback(conn.close)
                 conn.execute("PRAGMA query_only=ON")
                 connections.append(conn)
             versions = [conn.execute("PRAGMA data_version").fetchone()[0] for conn in connections]
             sources = _sources(service.sources_by_ticker())
             snapshot = read_population_snapshot(*paths, at=at)
             manifest = build_population_manifest(snapshot)
             result = _project(snapshot, manifest, sources, connections[1])
-            if web_review_id is not None:
-                from src.lifecycle_web_projection import latest_web_runs
-                from src.lifecycle_web_schema import WebJournalError
-                review = next((row for row in result["items"] if row["review_id"] == web_review_id), None)
-                try:
-                    result["web_runs"] = latest_web_runs(connections[1], review["case_ids"] if review else [], at=at)
-                except WebJournalError:
-                    raise LifecyclePopulationUnavailable("current_web_journal_unavailable") from None
             if (sources != _sources(service.sources_by_ticker())
                     or versions != [conn.execute("PRAGMA data_version").fetchone()[0] for conn in connections]
                     or identities != [(path.stat().st_dev, path.stat().st_ino) for path in paths]):
                 raise LifecyclePopulationUnavailable("current_snapshot_changed")
             return result
     except (OSError, sqlite3.Error):
         raise LifecyclePopulationUnavailable("current_store_unavailable") from None
     except (KeyError, TypeError, ValueError):
         raise LifecyclePopulationUnavailable("current_material_invalid") from None
 
 
 def list_current_reviews(service, *, at=None, view="attention", ticker=None, case_id=None, limit=50, offset=0):
     if view not in {"attention", "history"} or type(limit) is not int or not 1 <= limit <= 200 or type(offset) is not int or offset < 0:
         raise ValueError("current_review_filter")
     if ticker is not None and not isinstance(ticker, str):
         raise ValueError("ticker")
     if case_id is not None and (not isinstance(case_id, str) or not case_id.strip()):
         raise ValueError("case_id")
     result = _read(service, at=at)
     prefix = (ticker or "").strip().upper()
     # Existing case links resolve across both views, independently of the
     # operator's current page. The normal list keeps its selected view/filter.
     rows = [row for row in result["items"] if (case_id in row["case_ids"] if case_id is not None
             else row["bucket"] == view and row["ticker"].startswith(prefix))]
     return {**result, "items": rows[offset:offset + limit], "page": {"offset": offset, "limit": limit, "total": len(rows)}}
 
 
 def get_current_review(service, review_id, *, at=None):
-    result = _read(service, at=at, web_review_id=review_id)
+    result = _read(service, at=at)
     row = next((row for row in result["items"] if row["review_id"] == review_id), None)
     if row is None:
         raise KeyError("current_review_not_found")
-    return {"version": 1, "as_of": result["as_of"], "item": row, "web_runs": result["web_runs"]}
+    return {"version": 1, "as_of": result["as_of"], "item": row}
diff --git a/src/security_lifecycle_population.py b/src/security_lifecycle_population.py
index 2f01b411..ad370fac 100644
--- a/src/security_lifecycle_population.py
+++ b/src/security_lifecycle_population.py
@@ -1,36 +1,35 @@
 """Read-only, digest-bound accounting before lifecycle population changes.
 
 This manifest is an internal dry-run artifact, not action authority or a public
 case DTO. Reading it never approves actions, deletes history, or contacts sources.
 """
 
 from __future__ import annotations
 
 from contextlib import ExitStack
 from datetime import date, timedelta
 import hashlib
 import json
 from pathlib import Path
 import sqlite3
 
-from src.lifecycle_web_schema import INVENTORY_FIELDS, TERMINAL as WEB_TERMINAL, WebJournalError, read_web_inventory
 from src.security_lifecycle import read_market_observations
 from src.security_lifecycle_investigation import (
     LifecycleStoreUnavailable, case_id_for, compose_security_lifecycle_audit, observation_fingerprint,
 )
 from src.security_lifecycle_provider_authority import classify_provider_listing, evidence_dict, validate_provider_material
 from src.security_lifecycle_provider_snapshot import canonical_json, decode_snapshot, instant
 from src.security_lifecycle_schema import (
     LifecycleSchemaMismatch, MARKET_TABLE_SQL, PROFILE_TABLE_SQL,
     verify_market_connection, verify_profile_connection,
 )
 from src.ticker_identity_schema import (
     IDENTITY_TABLE_SQL, TickerIdentitySchemaMismatch, identity_schema_present,
     verify_ticker_identity_connection,
 )
 
 
 POLICY_VERSION = "lifecycle_population_v1"
 _PREFIX = "security_lifecycle_"
 
 
@@ -56,41 +55,40 @@ def _rows(conn, tables):
 
 
 def _schema(conn, tables):
     names = sorted(tables)
     placeholders = ",".join("?" for _ in names)
     return [dict(row) for row in conn.execute(
         f"SELECT type,name,tbl_name,sql FROM sqlite_master WHERE tbl_name IN ({placeholders}) ORDER BY type,name",
         names,
     )]
 
 
 def _capture(market, profile, market_conn, profile_conn):
     identity_tables = {}
     if identity_schema_present(profile_conn):
         verify_ticker_identity_connection(profile_conn)
         identity_tables = _rows(profile_conn, IDENTITY_TABLE_SQL)
     return {
         "market_observations": read_market_observations(str(market), limit=None),
         "profile_tables": _rows(profile_conn, PROFILE_TABLE_SQL),
         "identity_tables": identity_tables,
-        "web_journal_inventory": read_web_inventory(profile_conn),
         "composed_cases": compose_security_lifecycle_audit(str(market), str(profile))["cases"],
         "schemas": {
             "market": _schema(market_conn, MARKET_TABLE_SQL),
             "profile": _schema(profile_conn, (*PROFILE_TABLE_SQL, *identity_tables)),
         },
     }
 
 
 def read_population_snapshot(market_db_path, profile_db_path, *, at: str) -> dict:
     """Capture stable read bounds without holding a transaction across stores.
 
     Monitors remain in autocommit: a transaction would pin their data_version.
     Any committed concurrent change invalidates the capture, including WAL writes.
     Writers are not paused, and a failed capture is never retried implicitly.
     """
     try:
         canonical_at = instant(at).isoformat(timespec="seconds").replace("+00:00", "Z")
     except (ValueError, TypeError):
         raise LifecyclePopulationUnavailable("population_time_invalid") from None
     paths = (Path(market_db_path), Path(profile_db_path))
@@ -98,41 +96,41 @@ def read_population_snapshot(market_db_path, profile_db_path, *, at: str) -> dic
         if not all(path.is_file() for path in paths):
             raise LifecyclePopulationUnavailable("population_store_unavailable")
         identities = tuple(_identity(path) for path in paths)
         if identities[0] == identities[1]:
             raise LifecyclePopulationUnavailable("population_store_identity_invalid")
         with ExitStack() as stack:
             connections = []
             for path in paths:
                 conn = sqlite3.connect(f"{path.resolve().as_uri()}?mode=ro", uri=True)
                 stack.callback(conn.close)
                 conn.row_factory = sqlite3.Row
                 conn.execute("PRAGMA query_only=ON")
                 connections.append(conn)
             versions = tuple(conn.execute("PRAGMA data_version").fetchone()[0] for conn in connections)
             verify_market_connection(connections[0])
             verify_profile_connection(connections[1])
             material = _capture(*paths, *connections)
             after = tuple(conn.execute("PRAGMA data_version").fetchone()[0] for conn in connections)
             if versions != after or identities != tuple(_identity(path) for path in paths):
                 raise LifecyclePopulationUnavailable("population_snapshot_changed")
-    except (LifecycleSchemaMismatch, TickerIdentitySchemaMismatch, WebJournalError):
+    except (LifecycleSchemaMismatch, TickerIdentitySchemaMismatch):
         raise LifecyclePopulationUnavailable("population_schema_invalid") from None
     except (OSError, sqlite3.Error, LifecycleStoreUnavailable):
         raise LifecyclePopulationUnavailable("population_store_unavailable") from None
     except (TypeError, ValueError, KeyError):
         raise LifecyclePopulationUnavailable("population_material_invalid") from None
     unsigned = {"version": 1, "at": canonical_at, "material": material}
     return {**unsigned, "sha256": _digest(unsigned)}
 
 
 def _key(row):
     return row["source"], row["source_ref"], row["ticker"]
 
 
 def _case_id(row):
     return case_id_for(*_key(row))
 
 
 def _reconcile(observations, cases, *, source):
     observed = {_key(row) for row in observations if row["source"] == source}
     persisted = {_key(row) for row in cases if row["source"] == source}
@@ -449,64 +447,41 @@ def _dispositions(reviews, transitions, latest, *, today):
             review["bucket"] = "current"
             review["reason"] = ("action_needs_review" if current["status"] == "needs_review" else
                                 "action_scheduled" if date.fromisoformat(current["execute_on"]) > today else "action_pending")
         elif applied:
             _retain_applied_listing(review, latest, today=today)
             if review["listing_state"] == "active":
                 review.update(bucket="current", reason="listing_reappeared_after_action")
             elif review["listing_state"] == "unresolved":
                 review.update(bucket="current", reason="listing_recheck_required")
             elif current["kind"] == "terminal_delisting":
                 if review["continuation_state"] == "not_observed":
                     review.update(bucket="history", reason="removal_applied")
                 else:
                     review.update(bucket="current", reason="continuation_followup_pending")
             elif review["continuation_state"] == "confirmed" and review["successor_ticker"] == current["successor_ticker"]:
                 review.update(bucket="history", reason="symbol_change_applied")
             else:
                 review.update(bucket="current", reason="continuation_followup_pending")
 
 
-def _web_retention(value, *, tables, assessments):
-    if value is None:
-        return {"installed": False, **{key: [] for key in INVENTORY_FIELDS}}
-    if (not isinstance(value, dict) or set(value) != {"installed", *INVENTORY_FIELDS} or type(value["installed"]) is not bool
-            or any(not isinstance(value[key], list) or any(not isinstance(row, dict) or set(row) != set(fields) for row in value[key])
-                   for key, fields in INVENTORY_FIELDS.items()) or (not value["installed"] and any(value[key] for key in INVENTORY_FIELDS))):
-        raise LifecyclePopulationUnavailable("population_web_dependency_invalid")
-    runs = {row["run_id"]: row for row in value["runs"]}
-    cases = {row["case_id"] for row in tables[_PREFIX + "cases"]}
-    results = {row["run_id"] for row in value["results"]}
-    calls = {(row["run_id"], row["call_id"]) for row in value["calls"]}
-    if (len(runs) != len(value["runs"]) or any(row["case_id"] not in cases for row in runs.values())
-            or any(row["run_id"] not in runs for key in INVENTORY_FIELDS if key != "runs" for row in value[key])
-            or any((row["run_id"], row["call_id"]) not in calls for row in value["actions"])
-            or any((row["status"] == "succeeded" and row["run_id"] not in results)
-                   or (row["run_id"] in results and row["status"] not in WEB_TERMINAL) for row in runs.values())
-            or any(row["assessment_id"] not in assessments or row["run_id"] not in results
-                   or runs[row["run_id"]]["status"] != "succeeded"
-                   or assessments[row["assessment_id"]]["case_id"] != runs[row["run_id"]]["case_id"] for row in value["acceptances"])):
-        raise LifecyclePopulationUnavailable("population_web_dependency_invalid")
-    return value
-
-
-def _retention(tables, identity_tables, web_inventory=None):
+def _retention(tables, identity_tables):
     def rows(name):
         return tables[_PREFIX + name]
     assessments = {row["assessment_id"]: row for row in rows("assessments")}
     evidence = {row["evidence_id"]: row for row in rows("evidence")}
     dependencies = []
     fact_dependencies, translation_dependencies = [], []
     referenced = set()
     for row in rows("assessment_evidence"):
         assessment = assessments.get(row["assessment_id"])
         if assessment is None:
             raise LifecyclePopulationUnavailable("population_dependency_invalid")
         evidence_id = row["evidence_id"]
         if evidence_id is not None:
             target = evidence.get(evidence_id)
             if target is None or target["case_id"] != assessment["case_id"] or target["content_sha256"] != row["cited_content_sha256"]:
                 raise LifecyclePopulationUnavailable("population_dependency_invalid")
             referenced.add(evidence_id)
         dependencies.append({
             "assessment_id": row["assessment_id"], "case_id": assessment["case_id"],
             "reference_kind": row["reference_kind"], "evidence_id": evidence_id,
@@ -517,60 +492,58 @@ def _retention(tables, identity_tables, web_inventory=None):
         if target is None or target["case_id"] != row["case_id"] or target["automation_run_id"] != row["automation_run_id"]:
             raise LifecyclePopulationUnavailable("population_dependency_invalid")
         referenced.add(row["evidence_id"])
         fact_dependencies.append({key: row[key] for key in ("fact_id", "case_id", "evidence_id", "automation_run_id")})
     for row in rows("evidence_translations"):
         target = evidence.get(row["evidence_id"])
         if target is None or target["content_sha256"] != row["evidence_content_sha256"]:
             raise LifecyclePopulationUnavailable("population_dependency_invalid")
         referenced.add(row["evidence_id"])
         translation_dependencies.append({"evidence_id": row["evidence_id"], "content_sha256": row["evidence_content_sha256"], "locale": row["locale"]})
     transitions = _transition_inventory(tables, identity_tables, assessments)
     return {
         "assessment_ids": sorted(assessments), "evidence_ids": sorted(evidence),
         "referenced_evidence_ids": sorted(referenced),
         "unreferenced_evidence_ids": sorted(set(evidence) - referenced),
         "assessment_dependencies": dependencies,
         "fact_dependencies": fact_dependencies, "translation_dependencies": translation_dependencies,
         "proposal_ids": sorted(row["proposal_id"] for row in rows("action_proposals")),
         "transition_ids": sorted(row["transition_id"] for row in transitions),
         "transitions": transitions,
-        "web_journal": _web_retention(web_inventory, tables=tables, assessments=assessments),
         "table_counts": {name: len(value) for name, value in sorted({**tables, **identity_tables}.items())},
         "deletion_candidates": [],
     }
 
 
 def build_population_manifest(snapshot: dict) -> dict:
     """Pure classification of a sealed local capture; never an execution plan."""
     try:
         if (set(snapshot) != {"version", "at", "material", "sha256"}
                 or type(snapshot["version"]) is not int or snapshot["version"] != 1):
             raise LifecyclePopulationUnavailable("population_snapshot_invalid")
         unsigned = {key: snapshot[key] for key in ("version", "at", "material")}
         if snapshot["sha256"] != _digest(unsigned):
             raise LifecyclePopulationUnavailable("population_snapshot_digest")
         material = snapshot["material"]
-        if (not isinstance(material, dict) or set(material) - {"web_journal_inventory"} != {
+        if (not isinstance(material, dict) or set(material) != {
                 "market_observations", "profile_tables", "identity_tables", "composed_cases", "schemas"}
                 or not isinstance(material["schemas"], dict)
-                or ("web_journal_inventory" in material and not isinstance(material["web_journal_inventory"], dict))
                 or set(material["schemas"]) != {"market", "profile"}
                 or any(not isinstance(material[key], list) or any(not isinstance(row, dict) for row in material[key])
                        for key in ("market_observations", "composed_cases"))):
             raise LifecyclePopulationUnavailable("population_material_invalid")
         for key, expected in (("profile_tables", set(PROFILE_TABLE_SQL)), ("identity_tables", set(IDENTITY_TABLE_SQL))):
             rows = material[key]
             if (not isinstance(rows, dict) or (set(rows) != expected and not (key == "identity_tables" and not rows))
                     or any(not isinstance(value, list) or any(not isinstance(row, dict) for row in value) for value in rows.values())):
                 raise LifecyclePopulationUnavailable("population_material_invalid")
         return _build(snapshot)
     except (KeyError, ValueError, TypeError):
         raise LifecyclePopulationUnavailable("population_material_invalid") from None
 
 
 def _build(snapshot):
     material = snapshot["material"]
     tables = material["profile_tables"]
     observations = material["market_observations"]
     cases = tables[_PREFIX + "cases"]
     composed = {row["case_id"]: row for row in material["composed_cases"]}
@@ -586,41 +559,41 @@ def _build(snapshot):
     expected = {_case_id(row) for row in (*observations, *projected)} | {row["case_id"] for row in cases}
     if set(composed) != expected:
         raise LifecyclePopulationUnavailable("population_composition_incomplete")
     sec_diff = _reconcile(observations, cases, source="sec_edgar")
     provider_diff = _reconcile(projected, cases, source="listing_authority")
     provider_diff = {
         "virtual": provider_diff["observation_only"], "persisted": provider_diff["matched"],
         "case_only": provider_diff["case_only"],
     }
     today = instant(snapshot["at"]).date()
     reviews = {case_id: _review(row, _provider_for_case(row, latest), today=today) for case_id, row in composed.items()}
     for ticker, row in sorted(latest.items()):
         case_id = _case_id(row["observation"])
         if case_id in reviews:
             continue
         candidate = _review({"case_id": case_id, **row["observation"], "source_presence": "present"}, row, today=today)
         # Even always-active checks can join an existing, identity-bound review.
         reviews[case_id] = candidate
     review_rows, reviews, coverage = _consolidate(reviews, composed, latest, tables, today=today)
     check_views, coverage = _historical_provider_reviews(history, latest, review_rows, reviews, coverage, today=today)
-    retention = _retention(tables, material["identity_tables"], material.get("web_journal_inventory"))
+    retention = _retention(tables, material["identity_tables"])
     _bind_transition_reviews(retention["transitions"], review_rows, reviews, check_views, composed, history, latest)
     _dispositions(review_rows, retention["transitions"], latest, today=today)
     mappings = []
     for population, rows in (("market_observation", observations), ("profile_case", cases)):
         for row in rows:
             case_id = _case_id(row)
             review = reviews[case_id]
             mappings.append({
                 "population": population, "input_id": str(row["id"]) if population == "market_observation" else case_id,
                 "case_id": case_id, "review_id": review["review_id"],
                 "destination": review["bucket"], "reason": review["reason"],
             })
     for row in history:
         case_id = _case_id(row["observation"])
         review = check_views[row["check_id"]]
         superseded = row["check_id"] != latest[row["ticker"]]["check_id"]
         mappings.append({
             "population": "provider_check", "input_id": row["check_id"], "case_id": case_id,
             "review_id": review["review_id"] if review else None,
             "destination": "history" if superseded else (review["bucket"] if review else "coverage"),
diff --git a/src/sqlite_backup.py b/src/sqlite_backup.py
new file mode 100644
index 00000000..d04a3165
--- /dev/null
+++ b/src/sqlite_backup.py
@@ -0,0 +1,14 @@
+"""WAL-safe SQLite backups to a new, private destination."""
+
+from contextlib import closing
+import os
+from pathlib import Path
+import sqlite3
+
+
+def backup_connection(conn: sqlite3.Connection, path: Path) -> None:
+    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
+    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
+    os.close(fd)
+    with closing(sqlite3.connect(path)) as destination:
+        conn.backup(destination)
diff --git a/tests/test_lifecycle_investigation_retirement.py b/tests/test_lifecycle_investigation_retirement.py
index dd53915e..26cacb3c 100644
--- a/tests/test_lifecycle_investigation_retirement.py
+++ b/tests/test_lifecycle_investigation_retirement.py
@@ -31,40 +31,60 @@ def test_retirement_disposal_is_scoped_and_preserves_other_data(tmp_path):
 
 
 def test_disposal_stops_for_new_dependency_and_never_requires_quiescing_unrelated_sa(tmp_path):
     from src.lifecycle_investigation.disposal import preview_disposal, apply_disposal_stage
     from src.lifecycle_investigation.schema import install_journal
     market, profile = stores(tmp_path)
     event = observe(market, ticker="OLD", ref="old")
     case = persist(profile, event)
     with sqlite3.connect(profile) as conn:
         install_journal(conn, at="2026-09-08T00:00:00Z")
     plan = preview_disposal(market, profile)
     with sqlite3.connect(profile) as conn:
         conn.execute("CREATE TABLE new_dependency(case_id TEXT REFERENCES security_lifecycle_cases(case_id))")
         conn.execute("INSERT INTO new_dependency VALUES (?)", (case,))
     with pytest.raises(ValueError, match="disposal_changed"):
         apply_disposal_stage(profile, plan, stage="profile", approval_sha256=plan["approval_sha256"],
             backup_path=tmp_path / "backup", app_stopped=True)
     assert preview_disposal(market, profile)["counts"]["retained_cases"] == 1
 
 
+def test_unrelated_child_reference_retains_case_and_market_observation(tmp_path):
+    from src.lifecycle_investigation.disposal import preview_disposal
+
+    market, profile = stores(tmp_path)
+    event = observe(market, ticker="OLD", ref="retained")
+    case = persist(profile, event)
+    with sqlite3.connect(profile) as conn:
+        conn.execute("CREATE TABLE independent_receipt(case_id TEXT REFERENCES security_lifecycle_cases(case_id), payload TEXT)")
+        conn.execute("INSERT INTO independent_receipt VALUES (?, 'retained')", (case,))
+    plan = preview_disposal(market, profile)
+    assert plan["roots"] == []
+    assert plan["stages"]["profile"] == {}
+    assert plan["stages"]["market"]["observation_ids"] == []
+    assert plan["counts"]["retained_cases"] == 1
+    assert plan["retained"] == [{"case_id": case, "source": "sec_edgar", "source_ref": "retained", "ticker": "OLD", "reason": "retained_external_dependency"}]
+    with sqlite3.connect(profile) as conn:
+        assert conn.execute("SELECT * FROM independent_receipt").fetchall() == [(case, "retained")]
+        assert not conn.execute("PRAGMA foreign_key_check").fetchall()
+
+
 @pytest.mark.parametrize("journal_installed", (False, True))
 def test_current_composition_excludes_unretained_sec_without_a_cutover(tmp_path, journal_installed):
     from src.lifecycle_investigation.schema import install_journal
     from src.security_lifecycle_investigation import compose_security_lifecycle
     from src.security_lifecycle_provider_store import ProviderCheckStore
     market, profile = stores(tmp_path)
     event = observe(market, ticker="OLD", ref="old")
     persist(profile, event)
     observe(market, ticker="UNSAVED", ref="unsaved")
     persist(profile, {"source": "sec_edgar", "source_ref": "missing", "ticker": "MISSING"})
     ProviderCheckStore(profile).record(ticker="LISTED", at="2026-09-08T00:00:00Z", evidence=(), diagnostics={})
     if journal_installed:
         with sqlite3.connect(profile) as conn:
             install_journal(conn, at="2026-09-08T00:00:00Z")
     cases = compose_security_lifecycle(str(market), str(profile))["cases"]
     assert [(case["source"], case["ticker"]) for case in cases] == [("listing_authority", "LISTED")]
 
 
 @pytest.mark.parametrize("journal_installed", (False, True))
 def test_retained_sec_action_history_is_readable_but_not_background_intake(tmp_path, monkeypatch, journal_installed):
@@ -141,49 +161,52 @@ def test_disposal_deletes_draft_dependencies_but_retains_human_acceptance(tmp_pa
         case = persist(profile, event)
         with sqlite3.connect(profile) as conn:
             store = SecurityLifecycleInvestigationStore(conn)
             fingerprint = observation_fingerprint(event)
             assessment = store.create_assessment(case_id=case, relevance="direct_tracked_security", confidence="high", author="human",
                 conclusion="Preserve an accepted user assessment.", impact_summary="No change.", outcomes=("no_tracked_security_change",),
                 citations=({"reference_kind": "observation", "cited_content_sha256": fingerprint},),
                 observation_fingerprint_sha256=fingerprint, at="2026-09-08T00:00:00Z")
             if ticker == "HUMAN":
                 store.accept_assessment(assessment, observation_fingerprint_sha256=fingerprint, acceptance_authority="human", at="2026-09-08T00:00:00Z")
     with sqlite3.connect(profile) as conn:
         install_journal(conn, at="2026-09-08T00:00:00Z")
     plan = preview_disposal(market, profile)
     assert plan["counts"]["discard_cases"] == 1
     apply_disposal_stage(profile, plan, stage="profile", approval_sha256=plan["approval_sha256"], backup_path=tmp_path / "backup", app_stopped=True)
     with sqlite3.connect(profile) as conn:
         assert conn.execute("SELECT ticker FROM security_lifecycle_cases").fetchall() == [("HUMAN",)]
         assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_assessments").fetchone()[0] == 1
 
 
-def test_v1_web_dependencies_are_deleted_atomically_and_their_guards_restored(tmp_path, monkeypatch):
+def test_disposal_rolls_back_shared_evidence_when_receipt_publication_fails(tmp_path, monkeypatch):
     from src.lifecycle_investigation import disposal
-    from src.lifecycle_investigation.schema import install_journal
-    from src.lifecycle_web_schema import verify_web_journal
-    from tests.test_lifecycle_web_store import setup_store, completed
-    market, _ = stores(tmp_path)
-    profile, store = setup_store(tmp_path)
-    identity = completed(store)
-    observe(market, ticker="OLD", ref="source-1")
+    from src.lifecycle_investigation.schema import install_journal, verify_journal
+    from tests.test_security_lifecycle_population import bind_listing
+
+    market, profile = stores(tmp_path)
+    case_id = bind_listing(profile, observe(market, ticker="OLD", ref="source-1"), ())
     with sqlite3.connect(profile) as conn:
         install_journal(conn, at="2026-09-08T00:00:00Z")
     plan = disposal.preview_disposal(market, profile)
     assert plan["counts"]["discard_cases"] == 1
+    assert len(plan["stages"]["profile"]["security_lifecycle_automation_facts"]["rowids"]) == 3
     real_hash = disposal._sha_file
     monkeypatch.setattr(disposal, "_sha_file", lambda path: (_ for _ in ()).throw(OSError("receipt publication failed")))
     with pytest.raises(OSError, match="receipt publication failed"):
         disposal.apply_disposal_stage(profile, plan, stage="profile", approval_sha256=plan["approval_sha256"],
             backup_path=tmp_path / "failed-backup", app_stopped=True)
-    assert store.read(identity)["status"] == "succeeded"
+    assert disposal.preview_disposal(market, profile) == plan
+    with disposal.connect(tmp_path / "failed-backup") as conn:
+        assert disposal.profile_scope(conn, [case_id]) == plan["stages"]["profile"]
     with sqlite3.connect(profile) as conn:
-        verify_web_journal(conn)
+        verify_journal(conn)
         assert not conn.execute("SELECT 1 FROM sqlite_master WHERE name='lifecycle_legacy_disposal_receipts'").fetchall()
     monkeypatch.setattr(disposal, "_sha_file", real_hash)
     disposal.apply_disposal_stage(profile, plan, stage="profile", approval_sha256=plan["approval_sha256"],
         backup_path=tmp_path / "successful-backup", app_stopped=True)
     with sqlite3.connect(profile) as conn:
-        verify_web_journal(conn)
-        assert conn.execute("SELECT COUNT(*) FROM lifecycle_web_runs").fetchone()[0] == 0
+        verify_journal(conn)
+        assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_cases").fetchone()[0] == 0
+        assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_evidence").fetchone()[0] == 0
+        assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_automation_facts").fetchone()[0] == 0
         assert not conn.execute("PRAGMA foreign_key_check").fetchall()
diff --git a/tests/test_lifecycle_web_migration.py b/tests/test_lifecycle_web_migration.py
deleted file mode 100644
index ef9ce639..00000000
--- a/tests/test_lifecycle_web_migration.py
+++ /dev/null
@@ -1,80 +0,0 @@
-import sqlite3
-import stat
-
-import pytest
-
-from tests.test_lifecycle_web_store import AT, setup_store
-
-
-def test_web_installation_has_digest_bound_backup_and_keeps_all_existing_rows(tmp_path):
-    from src.lifecycle_web_migration import preview_web_installation, apply_web_installation
-    from src.lifecycle_web_schema import verify_web_journal
-    path, _ = setup_store(tmp_path, install=False)
-    with sqlite3.connect(path) as conn:
-        conn.execute("CREATE TABLE unrelated_payload(id INTEGER PRIMARY KEY, raw BLOB)")
-        conn.execute("INSERT INTO unrelated_payload VALUES (1,?)", (b"opaque-private-fixture",))
-    before = preview_web_installation(path)
-    backup = tmp_path / "backup.db"
-    result = apply_web_installation(path, backup_path=backup, approval_sha256=before["approval_sha256"], at=AT, app_stopped=True)
-    assert result["changed"] and result["previous_rows_sha256"] == before["rows_sha256"]
-    assert stat.S_IMODE(backup.stat().st_mode) == 0o600
-    assert preview_web_installation(backup) == before
-    assert "opaque-private" not in str(result) and len(result["backup_sha256"]) == 64
-    with sqlite3.connect(path) as conn:
-        verify_web_journal(conn)
-        assert conn.execute("SELECT raw FROM unrelated_payload").fetchone()[0] == b"opaque-private-fixture"
-    current = preview_web_installation(path)
-    assert apply_web_installation(path, backup_path=tmp_path / "unused.db", approval_sha256=current["approval_sha256"], at=AT, app_stopped=True)["changed"] is False
-    assert not (tmp_path / "unused.db").exists()
-
-
-def test_web_installation_requires_stopped_app_before_opening_any_store(tmp_path):
-    from src.lifecycle_web_migration import apply_web_installation
-    with pytest.raises(ValueError, match="web_installation_app_stop_required"):
-        apply_web_installation(tmp_path / "missing.db", backup_path=tmp_path / "backup.db", approval_sha256="a" * 64, at=AT, app_stopped=False)
-    assert not tuple(tmp_path.iterdir())
-
-
-@pytest.mark.parametrize("change", ["before_backup", "after_backup", "backup_exists"])
-def test_web_installation_rejects_changed_approval_and_never_overwrites_a_backup(tmp_path, monkeypatch, change):
-    from src import lifecycle_web_migration as module
-    path, _ = setup_store(tmp_path, install=False)
-    before = module.preview_web_installation(path)
-    backup = tmp_path / "backup.db"
-    def mutate():
-        with sqlite3.connect(path) as conn:
-            conn.execute("UPDATE security_lifecycle_cases SET updated_at='changed'")
-    if change == "before_backup":
-        mutate()
-    elif change == "backup_exists":
-        backup.write_bytes(b"must-retain")
-    else:
-        original = module._backup
-        def changed(*args, **kwargs):
-            result = original(*args, **kwargs)
-            mutate()
-            return result
-        monkeypatch.setattr(module, "_backup", changed)
-    with pytest.raises((ValueError, FileExistsError)):
-        module.apply_web_installation(path, backup_path=backup, approval_sha256=before["approval_sha256"], at=AT, app_stopped=True)
-    if change == "backup_exists":
-        assert backup.read_bytes() == b"must-retain"
-    with sqlite3.connect(path) as conn:
-        assert not conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name LIKE 'lifecycle_web_%'").fetchone()
-
-
-def test_web_installation_rolls_back_all_new_schema_on_failure_and_preserves_backup(tmp_path, monkeypatch):
-    from src import lifecycle_web_migration as module
-    from src import lifecycle_web_schema as schema
-    path, _ = setup_store(tmp_path, install=False)
-    before = module.preview_web_installation(path)
-    backup = tmp_path / "backup.db"
-    original = schema.verify_web_journal
-    def fail(conn):
-        original(conn)
-        raise ValueError("synthetic_postflight_failure")
-    monkeypatch.setattr(schema, "verify_web_journal", fail)
-    with pytest.raises(ValueError, match="synthetic_postflight_failure"):
-        module.apply_web_installation(path, backup_path=backup, approval_sha256=before["approval_sha256"], at=AT, app_stopped=True)
-    assert module.preview_web_installation(path) == before
-    assert module.preview_web_installation(backup) == before
diff --git a/tests/test_security_lifecycle_current.py b/tests/test_security_lifecycle_current.py
index c2ea346b..515e6286 100644
--- a/tests/test_security_lifecycle_current.py
+++ b/tests/test_security_lifecycle_current.py
@@ -60,41 +60,41 @@ def test_current_reviews_account_for_unpersisted_missing_and_recovered_cases(tmp
     assert by_ticker["GONE"]["next_action"]["kind"] == "recheck"
     assert by_ticker["OLD"]["finding"] == "old_listing_inactive"
     assert by_ticker["OLD"]["next_action"]["kind"] == "recheck"  # No persisted assessment yet.
     assert by_ticker["OLD"]["collection"] == {"state": "tracking", "sources": ["manual_lists"]}
     assert by_ticker["NEW"]["issuer_name"] == "Synthetic issuer"
     history = service.list_current_reviews(at=later, view="history")
     assert [row["ticker"] for row in history["items"]] == ["RECOVER"]
     assert history["items"][0]["finding"] == "active"
     assert history["items"][0]["next_action"]["kind"] == "none"
 
 
 def test_current_review_and_list_share_one_closed_projection(tmp_path):
     c = context(tmp_path)
     service = reader(c["market"], c["profile"], c["sources"])
     row = service.list_current_reviews(at=NOW)["items"][0]
     assert set(row) == {"review_id", "case_ids", "ticker", "issuer_name", "bucket", "finding", "reason", "collection",
                         "listing", "continuation", "observed_at", "next_check_at", "diagnostics", "next_action", "source_checks", "source_notices"}
     assert row["next_action"]["kind"] == "review_removal"
     assert row["next_action"]["assessment_id"] == c["assessment_id"]
     assert row["next_action"]["state"] == "not_prepared"
-    assert service.get_current_review(row["review_id"], at=NOW) == {"version": 1, "as_of": NOW, "item": row, "web_runs": []}
+    assert service.get_current_review(row["review_id"], at=NOW) == {"version": 1, "as_of": NOW, "item": row}
     text = json.dumps(row)
     for private in ("snapshot_sha256", "source_locator", "_ordinal", "canonical_payload", "decision_provenance", "BBG", "source_ref"):
         assert private not in text
     assert {check["provider"] for check in row["source_checks"]} == {"massive", "eodhd", "nasdaq"}
     assert sorted((check["check"], check["status"]) for check in row["source_checks"] if check["provider"] == "massive") == [
         ("delisting", "inactive"), ("otc", "not_found"), ("stocks", "not_found")]
 
 
 def test_applied_removal_keeps_unresolved_continuation_in_attention(tmp_path):
     c = context(tmp_path)
     receipt = confirm(c, prepare(c))
     result = current(c)
     assert result["counts"] == {"attention": 1, "history": 0}
     row = result["items"][0]
     assert row["reason"] == "continuation_followup_pending"
     assert row["collection"] == {"state": "not_tracking", "sources": []}
     assert row["next_action"]["state"] == "applied"
     assert row["next_action"]["current_effects_match"] is True
     assert row["next_action"]["transition_id"] == receipt["transition_id"]
     assert row["next_action"]["kind"] == "recheck"
@@ -310,41 +310,43 @@ def test_always_active_coverage_expires_instead_of_staying_green(tmp_path):
     market, profile = stores(tmp_path)
     ProviderCheckStore(profile).record(ticker="LIVE", at=NOW, evidence=(active("LIVE"),), diagnostics={})
     result = reader(market, profile, lambda: {"LIVE": ("manual_lists",)}).list_current_reviews(at="2026-09-15T01:00:00Z")
     assert result["coverage"] == {"tracked": 1, "confirmed_active": 0, "unconfirmed": 1}
     assert result["items"][0]["finding"] == "unresolved"
 
 
 def test_research_reads_exactly_the_same_current_projection_and_no_mutation_tool(tmp_path, monkeypatch):
     from src.tools import security_lifecycle_tools as tools
     from src.tools.registry import create_default_registry
     c = context(tmp_path)
     service = reader(c["market"], c["profile"], c["sources"])
     original_list, original_get = service.list_current_reviews, service.get_current_review
     expected = original_list(at=NOW)
     monkeypatch.setattr(service, "list_current_reviews", lambda **kwargs: original_list(at=NOW, **kwargs))
     monkeypatch.setattr(service, "get_current_review", lambda review_id: original_get(review_id, at=NOW))
     monkeypatch.setattr(tools, "SecurityLifecycleReadService", lambda **kwargs: service)
     payload = tools.list_security_lifecycle_reviews()
     assert payload == {"status": "ok", **expected}
     review_id = payload["items"][0]["review_id"]
-    assert tools.get_security_lifecycle_review(review_id) == {"status": "ok", **original_get(review_id, at=NOW)}
+    detail = tools.get_security_lifecycle_review(review_id)
+    assert detail == {"status": "ok", "version": 1, "as_of": NOW, "item": payload["items"][0]}
+    assert original_get(review_id, at=NOW) == {key: value for key, value in detail.items() if key != "status"}
     registry = create_default_registry()
     assert registry.get("list_security_lifecycle_cases") is None
     assert registry.get("get_security_lifecycle_case") is None
     assert registry.get("confirm_security_lifecycle_review") is None
 
 
 def test_current_source_checks_keep_both_nasdaq_directories_identifiable(tmp_path):
     row = current(context(tmp_path))["items"][0]
     assert {check["directory"] for check in row["source_checks"] if check["provider"] == "nasdaq"} == {
         "nasdaq_listed", "other_listed"}
     assert all(check["directory"] is None for check in row["source_checks"] if check["provider"] != "nasdaq")
 
 
 def test_current_action_keeps_the_receipt_kind_for_an_honest_resume_prompt(tmp_path, monkeypatch):
     from tests.test_security_lifecycle_review import stage_approval
     c = context(tmp_path)
     stage_approval(c, monkeypatch)
     row = current(c)["items"][0]
     assert row["next_action"]["kind"] == "resume"
     assert row["next_action"]["transition_kind"] == "terminal_delisting"
diff --git a/tests/test_security_lifecycle_population.py b/tests/test_security_lifecycle_population.py
index e1284ed1..541d7838 100644
--- a/tests/test_security_lifecycle_population.py
+++ b/tests/test_security_lifecycle_population.py
@@ -56,40 +56,70 @@ def persist(profile, observation):
 
 
 def active(ticker, *, figi=FIGI, venue="XNYS", security_type="CS", at=NOW):
     return _evidence(replace(record("massive_reference", "active", ticker=ticker, figi=figi),
                              primary_exchange=venue, security_type=security_type, issuer_cik="0000000001", retrieved_at=at))
 
 
 def terminal(ticker):
     return tuple(_evidence(replace(row, ticker=ticker)) for row in terminal_records())
 
 
 def manifest(market, profile, *, at=NOW):
     from src.security_lifecycle_population import read_population_manifest
     return read_population_manifest(market, profile, at=at)
 
 
 def review_for(result, case_id):
     return next(row for row in result["reviews"] if case_id in row["case_ids"])
 
 
+@pytest.mark.parametrize("journal_installed", (False, True))
+def test_population_material_contains_only_current_reference_owners(tmp_path, journal_installed):
+    from src.lifecycle_investigation.schema import install_journal
+    from src.security_lifecycle_population import build_population_manifest, read_population_snapshot
+
+    market, profile = stores(tmp_path)
+    persist(profile, sec(market, "OLD", "retained"))
+    if journal_installed:
+        with sqlite3.connect(profile) as conn:
+            install_journal(conn, at=NOW)
+    snapshot = read_population_snapshot(market, profile, at=NOW)
+    assert set(snapshot["material"]) == {"market_observations", "profile_tables", "identity_tables", "composed_cases", "schemas"}
+    retention = build_population_manifest(snapshot)["retention"]
+    assert "web_journal" not in retention
+    assert retention["table_counts"]["security_lifecycle_cases"] == 1
+
+
+@pytest.mark.parametrize("field", ("web_journal_inventory", "unreviewed_retention"))
+def test_population_manifest_rejects_unexpected_material_even_when_sealed(tmp_path, field):
+    from src.security_lifecycle_population import LifecyclePopulationUnavailable, build_population_manifest, read_population_snapshot
+
+    market, profile = stores(tmp_path)
+    snapshot = read_population_snapshot(market, profile, at=NOW)
+    snapshot["material"][field] = {"installed": False, "runs": [], "calls": [], "actions": [], "pages": [], "results": [], "acceptances": []}
+    unsigned = {key: snapshot[key] for key in ("version", "at", "material")}
+    snapshot["sha256"] = hashlib.sha256(json.dumps(unsigned, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False).encode()).hexdigest()
+    with pytest.raises(LifecyclePopulationUnavailable, match="population_material_invalid"):
+        build_population_manifest(snapshot)
+
+
 @pytest.mark.parametrize("journal_installed", (False, True))
 def test_population_manifest_accounts_for_all_three_input_populations(tmp_path, journal_installed):
     from src.lifecycle_investigation.schema import install_journal
 
     market, profile = stores(tmp_path)
     matched = persist(profile, sec(market, "MIX", "matched"))
     observation_only = sec(market, "NEW", "not-persisted")
     missing = persist(profile, {"source": "sec_edgar", "source_ref": "gone", "ticker": "GONE"})
     checks = ProviderCheckStore(profile)
     checks.record(ticker="RECOVER", at=NOW, evidence=(), diagnostics={})
     later = "2026-09-05T01:01:00Z"
     checks.record(ticker="RECOVER", at=later, evidence=(active("RECOVER", at=later),), diagnostics={})
     checks.record(ticker="LIVE", at=NOW, evidence=(active("LIVE"),), diagnostics={})
     checks.record(ticker="MIX", at=NOW, evidence=terminal("MIX"), diagnostics={})
     if journal_installed:
         with sqlite3.connect(profile) as conn:
             install_journal(conn, at=NOW)
     result = manifest(market, profile, at=later)
     provider_id = case_id_for("listing_authority", "listing:MIX", "MIX")
     recovered_id = case_id_for("listing_authority", "listing:RECOVER", "RECOVER")
diff --git a/tests/test_sqlite_backup.py b/tests/test_sqlite_backup.py
new file mode 100644
index 00000000..639d9e4e
--- /dev/null
+++ b/tests/test_sqlite_backup.py
@@ -0,0 +1,183 @@
+"""Shared SQLite backup safety and its current installation consumer."""
+
+from contextlib import closing
+import hashlib
+from importlib import import_module
+from pathlib import Path
+import sqlite3
+import stat
+
+import pytest
+
+
+ROOT = Path(__file__).resolve().parents[1]
+AT = "2026-09-08T00:00:00Z"
+
+
+def backup_owner():
+    assert (ROOT / "src/sqlite_backup.py").is_file(), "shared SQLite backup owner is missing"
+    return import_module("src.sqlite_backup")
+
+
+@pytest.mark.parametrize("name", ("lifecycle_web_schema.py", "lifecycle_web_migration.py"))
+def test_current_journal_has_no_obsolete_schema_owner(name):
+    assert not (ROOT / "src" / name).exists()
+
+
+def test_backup_captures_committed_wal_rows_without_changing_the_source(tmp_path):
+    backup_connection = backup_owner().backup_connection
+    source = tmp_path / "source.db"
+    backup = tmp_path / "private" / "backup.db"
+    with closing(sqlite3.connect(source)) as conn:
+        assert conn.execute("PRAGMA journal_mode=WAL").fetchone() == ("wal",)
+        conn.execute("PRAGMA wal_autocheckpoint=0")
+        conn.execute("CREATE TABLE retained(id INTEGER PRIMARY KEY, payload BLOB)")
+        conn.commit()
+        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
+        conn.execute("INSERT INTO retained VALUES (1,?)", (b"committed-in-wal",))
+        conn.commit()
+        assert Path(str(source) + "-wal").stat().st_size > 0
+        with closing(sqlite3.connect(source.as_uri() + "?immutable=1", uri=True)) as main_only:
+            assert main_only.execute("SELECT * FROM retained").fetchall() == []
+        assert backup_connection(conn, backup) is None
+        assert conn.execute("SELECT * FROM retained").fetchall() == [(1, b"committed-in-wal")]
+        with closing(sqlite3.connect(backup)) as restored:
+            assert restored.execute("PRAGMA integrity_check").fetchall() == [("ok",)]
+            assert restored.execute("SELECT * FROM retained").fetchall() == [(1, b"committed-in-wal")]
+    assert stat.S_IMODE(backup.stat().st_mode) == 0o600
+
+
+def test_backup_never_overwrites_an_existing_destination(tmp_path):
+    backup_connection = backup_owner().backup_connection
+    existing = tmp_path / "backup.db"
+    existing.write_bytes(b"owned-backup")
+    with closing(sqlite3.connect(":memory:")) as conn:
+        with pytest.raises(FileExistsError):
+            backup_connection(conn, existing)
+    assert existing.read_bytes() == b"owned-backup"
+
+
+def test_backup_rejects_a_dangling_destination_symlink(tmp_path):
+    backup_connection = backup_owner().backup_connection
+    target = tmp_path / "must-not-create.db"
+    backup = tmp_path / "backup.db"
+    backup.symlink_to(target)
+    with closing(sqlite3.connect(":memory:")) as conn:
+        with pytest.raises(FileExistsError):
+            backup_connection(conn, backup)
+    assert backup.is_symlink() and not target.exists()
+
+
+@pytest.mark.parametrize("failure", (False, True))
+def test_backup_explicitly_closes_destination_on_success_and_failure(tmp_path, monkeypatch, failure):
+    module = backup_owner()
+    real_connect = sqlite3.connect
+    destinations = []
+
+    class FailingBackup(sqlite3.Connection):
+        def backup(self, destination, **kwargs):
+            raise OSError("synthetic backup failure")
+
+    def connect(*args, **kwargs):
+        destination = real_connect(*args, **kwargs)
+        destinations.append(destination)
+        return destination
+
+    with closing(real_connect(":memory:", factory=FailingBackup if failure else sqlite3.Connection)) as conn:
+        monkeypatch.setattr(module.sqlite3, "connect", connect)
+        if failure:
+            with pytest.raises(OSError, match="synthetic backup failure"):
+                module.backup_connection(conn, tmp_path / "backup.db")
+        else:
+            module.backup_connection(conn, tmp_path / "backup.db")
+        assert conn.execute("SELECT 1").fetchone() == (1,)
+    assert len(destinations) == 1
+    with pytest.raises(sqlite3.ProgrammingError, match="closed database"):
+        destinations[0].execute("SELECT 1")
+
+
+def test_current_installation_backup_preserves_unrelated_rows_and_is_idempotent(tmp_path):
+    from src.lifecycle_investigation.migration import apply_installation, preview_installation
+    from src.lifecycle_investigation.schema import verify_journal
+    from tests.test_security_lifecycle_population import persist, stores
+
+    _, profile = stores(tmp_path)
+    case_id = persist(profile, {"source": "sec_edgar", "source_ref": "retained", "ticker": "OLD"})
+    with closing(sqlite3.connect(profile)) as conn:
+        conn.execute("CREATE TABLE unrelated_payload(id INTEGER PRIMARY KEY, raw BLOB)")
+        conn.execute("INSERT INTO unrelated_payload VALUES (1,?)", (b"opaque-private-fixture",))
+        conn.commit()
+    before = preview_installation(profile)
+    backup = tmp_path / "backup.db"
+    result = apply_installation(profile, backup_path=backup, approval_sha256=before["approval_sha256"], at=AT, app_stopped=True)
+    assert result["changed"] is True
+    assert result["backup_sha256"] == hashlib.sha256(backup.read_bytes()).hexdigest()
+    assert stat.S_IMODE(backup.stat().st_mode) == 0o600
+    assert preview_installation(backup) == before
+    assert "opaque-private" not in str(result)
+    with closing(sqlite3.connect(profile)) as conn:
+        verify_journal(conn)
+        assert conn.execute("SELECT raw FROM unrelated_payload").fetchall() == [(b"opaque-private-fixture",)]
+        assert conn.execute("SELECT case_id FROM security_lifecycle_cases").fetchall() == [(case_id,)]
+    current = preview_installation(profile)
+    assert apply_installation(profile, backup_path=tmp_path / "unused.db", approval_sha256=current["approval_sha256"], at=AT, app_stopped=True)["changed"] is False
+    assert not (tmp_path / "unused.db").exists()
+
+
+def test_current_installation_requires_stopped_app_before_opening_any_store(tmp_path):
+    from src.lifecycle_investigation.migration import apply_installation
+
+    with pytest.raises(ValueError, match="investigation_install_app_stop_required"):
+        apply_installation(tmp_path / "missing.db", backup_path=tmp_path / "backup.db", approval_sha256="a" * 64, at=AT, app_stopped=False)
+    assert not tuple(tmp_path.iterdir())
+
+
+@pytest.mark.parametrize("change", ("after_backup", "backup_exists"))
+def test_current_installation_rejects_backup_races_and_existing_destinations(tmp_path, monkeypatch, change):
+    from src.lifecycle_investigation import migration
+    from tests.test_security_lifecycle_population import stores
+
+    _, profile = stores(tmp_path)
+    before = migration.preview_installation(profile)
+    backup = tmp_path / "backup.db"
+    if change == "backup_exists":
+        backup.write_bytes(b"must-retain")
+        expected = FileExistsError
+    else:
+        original = migration.preview_installation
+
+        def changed(path):
+            result = original(path)
+            with closing(sqlite3.connect(profile)) as conn:
+                conn.execute("CREATE TABLE independent_data(value TEXT)")
+                conn.commit()
+            return result
+
+        monkeypatch.setattr(migration, "preview_installation", changed)
+        expected = ValueError
+    with pytest.raises(expected):
+        migration.apply_installation(profile, backup_path=backup, approval_sha256=before["approval_sha256"], at=AT, app_stopped=True)
+    if change == "backup_exists":
+        assert backup.read_bytes() == b"must-retain"
+    with closing(sqlite3.connect(profile)) as conn:
+        assert not conn.execute("SELECT 1 FROM sqlite_master WHERE name='lifecycle_investigation_jobs'").fetchone()
+
+
+def test_current_installation_rolls_back_schema_on_postflight_failure(tmp_path, monkeypatch):
+    from src.lifecycle_investigation import migration, schema
+    from tests.test_security_lifecycle_population import stores
+
+    _, profile = stores(tmp_path)
+    before = migration.preview_installation(profile)
+    backup = tmp_path / "backup.db"
+    original = schema.verify_journal
+
+    def fail(conn):
+        original(conn)
+        raise ValueError("synthetic_postflight_failure")
+
+    monkeypatch.setattr(schema, "verify_journal", fail)
+    with pytest.raises(ValueError, match="synthetic_postflight_failure"):
+        migration.apply_installation(profile, backup_path=backup, approval_sha256=before["approval_sha256"], at=AT, app_stopped=True)
+    assert migration.preview_installation(profile) == before
+    assert migration.preview_installation(backup) == before

```
