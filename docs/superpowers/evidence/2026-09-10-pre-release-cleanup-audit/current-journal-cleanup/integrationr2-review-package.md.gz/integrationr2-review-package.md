# Review integrationr2

Base: 2842c497dabfdb0b13c315e22b206128eba9f57d
Head: frozen uncommitted task snapshot.

## Commits Since Base

## Scope And Current File Hashes
```json
{
  "src/api/routes/lifecycle_investigation.py": "3487f7232cca98aff916f6bebcc6d86d072e2b192f73d4210fb2884141e6fb07",
  "src/lifecycle_investigation/adoption.py": "c0ec3b181be6b7f1919ca856ba1aa1d9139887e07384e082db01699bf2768e2b",
  "src/lifecycle_investigation/agent.py": "aede2a37bdc99b8377f9f2ef9a49f53862f04a4d2d15fb00067c0f94ad3edf2b",
  "src/lifecycle_investigation/disposal.py": "d55cd056293761452c47762d1511c70cd535c9911d149ef54d8e1fd9b80a8865",
  "src/lifecycle_investigation/migration.py": "38c59bbee553528ef5f6d096823fbb14e6cb03dfeaca02d685268119f1dbe1e6",
  "src/lifecycle_investigation/review.py": "b0987f181aa6649cff93a034af1c49801e93a8f2d0f94d9a147f8f34247f40ce",
  "src/lifecycle_investigation/schema.py": "734a851e720b36df14b9bc3d3ff2d025c657baf00d46ca58084c6494d0fd72d6",
  "src/lifecycle_investigation/store.py": "a725a4e1ae8614f07587d9b350c52e13618b4c07939448e96c6dfb47844aea7b",
  "src/lifecycle_web_migration.py": null,
  "src/lifecycle_web_projection.py": null,
  "src/lifecycle_web_schema.py": null,
  "src/lifecycle_web_store.py": null,
  "src/sec_research/__init__.py": "283db4d3a4f27a14b29fb8e6b1c60bac262252a801ceea21c7f6375ef574d07f",
  "src/sec_research/config.py": "67818a242046a94b97c61a6fc80e24627dc4eed9a4c13da77efc0b918a30646c",
  "src/sec_research/paths.py": "93fc1abd8addc3d7b924d1b6b67ab0a94a7203d061da4e7c8a4b7a57e3005eaa",
  "src/security_lifecycle_current.py": "ea25f82c1125b4d3563a7bf206610ca0215575f3370331c810d9c3e3ddbf5aaa",
  "src/security_lifecycle_population.py": "454458eca84f21f148c76b847e709ebefed3f05c13d5df774a71e63ed4d6e3ee",
  "src/security_lifecycle_review.py": "041a3da556456dc9d01ac2faa65a5ae3bb4e67c76a741cedf95f5db755357b2d",
  "src/security_lifecycle_web_contract.py": "711a19dace4336c04e13a7782dd99b64265750bbe6496c3bf13f856ad0f5fc29",
  "src/sqlite_backup.py": "0c3ebdf4e8aae9c5aa58c4d603504eafcb3fb0d988c584505716ac3204abcaac",
  "src/ticker_identity_history.py": "79814d22c1553cbd91a29b91c3ed46403ed5caa77068263c61c4d2d882a6d7fb",
  "src/ticker_identity_transition.py": "4b9094e19ca32fb5949a397a071c996a9fbb3eaf96c989798a02b450ab45dcd7",
  "tests/test_current_investigation_ownership.py": "15a15ee3b6ed288531eaee6f033c6e17f428036e299caedff52c74e38b58e5e6",
  "tests/test_lifecycle_investigation_adoption_safety.py": "20e044017aab959beb53bf5d3e2d831ffd761ec6808c43fab49d616b91e94e37",
  "tests/test_lifecycle_investigation_attended_concurrency.py": "3a7def792546d0be41b3811db607b3ec612290b5d3ea4ff665371b0ee553ad34",
  "tests/test_lifecycle_investigation_gaps.py": "47116db1486dc5f4f97c62ae687df8bd99034711dda5f69bdb14e1480eb348bf",
  "tests/test_lifecycle_investigation_retirement.py": "6a6d281e5ba1e741143a09f4c05d295c6676ee33a7af651486468300c2167418",
  "tests/test_lifecycle_investigation_review.py": "a1fb710f5363905c36a4f8b35664c40a8eda264a4feffdec4c259639f6c06bd1",
  "tests/test_lifecycle_investigation_routes.py": "0292e1c3c58c729d310088d97e9971b9d0b4ffa308b106c1f41a51e511522808",
  "tests/test_lifecycle_investigation_source_journal.py": "b0492a127b8f9af09a1cc02da8b1d181780d26d26ef9a351eb755bb4359a967c",
  "tests/test_lifecycle_investigation_store.py": "5243d9a58774c794fbcf1c3b596c2e486eedd0c617827741d5bb8de5ab26b480",
  "tests/test_lifecycle_investigation_usage_journal.py": "5682cf529498e1ea529e96cb69a61c5e409043344a8b3c0040002e09b52eca70",
  "tests/test_lifecycle_journal_codec.py": "2feeeac857ba7a774cc6abf7da3763f5133d54100bfdcec51f173962af271c25",
  "tests/test_lifecycle_source_capacity.py": "e1460b33a1e40c7c1ffa85a7743bee19ad1f728a05dfacd6fef9aa1cbb7bf130",
  "tests/test_lifecycle_source_context.py": "b07912e7e2de9858f08bbd2de294805b2734565c691c37ec1e93b86149f74842",
  "tests/test_lifecycle_source_progress.py": "d9566875680e0a1ce50679379080bf11d836f2ef09aa6a153ef037a502d1017c",
  "tests/test_lifecycle_source_read_report.py": "24bb07a4d94a6b0a5e81752b0986e1abe7ea909f74f6110699f37ab05cf88013",
  "tests/test_lifecycle_web_attended_concurrency.py": null,
  "tests/test_lifecycle_web_gaps.py": null,
  "tests/test_lifecycle_web_migration.py": null,
  "tests/test_lifecycle_web_read.py": null,
  "tests/test_lifecycle_web_review.py": null,
  "tests/test_lifecycle_web_store.py": null,
  "tests/test_lifecycle_web_usage_journal.py": null,
  "tests/test_sec_research_config.py": "8bcbbaf8c54b88f26e0165fcbb52b802c1f5e0645e3115e72ad9d8f5833cfea9",
  "tests/test_sec_research_paths.py": "0bdad74318b5849d89fe9f2810a295401299fc46bf13a266b8fa460f01afc408",
  "tests/test_security_lifecycle_current.py": "159d7ce61663903a2e41f81e9ae1c5453974900a9ba16af8903bca6724c5d590",
  "tests/test_security_lifecycle_population.py": "cad6542d5aefb3d2f303ccc09d8bf6daf2ac4b91310009ea802ef2b5f85d28dd",
  "tests/test_sqlite_backup.py": "6d3d1b724e1a493cdeef326339ddfa917cd26b65f9e79f5cb5ca84a6cad5f985",
  "tests/test_ticker_identity_history.py": "ad8a61926c3a895807032b3cdd11596d6c5642bfcab3cc114a18fb624b3e9e0c"
}
```

## Stat
```text
 src/api/routes/lifecycle_investigation.py          |   2 +-
 src/lifecycle_investigation/adoption.py            |  18 +-
 src/lifecycle_investigation/agent.py               |  11 +-
 src/lifecycle_investigation/disposal.py            |  25 +-
 src/lifecycle_investigation/migration.py           |   4 +-
 src/lifecycle_investigation/review.py              | 215 +++++++++
 src/lifecycle_investigation/schema.py              |   2 +-
 src/lifecycle_investigation/store.py               |  99 +++-
 src/lifecycle_web_migration.py                     |  94 ----
 src/lifecycle_web_projection.py                    |  65 ---
 src/lifecycle_web_schema.py                        | 143 ------
 src/lifecycle_web_store.py                         | 505 ---------------------
 src/sec_research/__init__.py                       |   1 +
 src/sec_research/config.py                         |  47 ++
 src/sec_research/paths.py                          |  70 +++
 src/security_lifecycle_current.py                  |  14 +-
 src/security_lifecycle_population.py               |  35 +-
 src/security_lifecycle_review.py                   |   8 +-
 src/security_lifecycle_web_contract.py             |   5 +
 src/sqlite_backup.py                               |  14 +
 src/ticker_identity_history.py                     |  76 +---
 src/ticker_identity_transition.py                  |   8 +-
 tests/test_current_investigation_ownership.py      | 157 +++++++
 ...test_lifecycle_investigation_adoption_safety.py | 172 +++++++
 ...lifecycle_investigation_attended_concurrency.py | 295 ++++++++++++
 tests/test_lifecycle_investigation_gaps.py         | 223 +++++++++
 tests/test_lifecycle_investigation_retirement.py   | 176 ++++++-
 tests/test_lifecycle_investigation_review.py       |  53 ++-
 tests/test_lifecycle_investigation_routes.py       |   2 +-
 .../test_lifecycle_investigation_source_journal.py |  96 ++++
 tests/test_lifecycle_investigation_store.py        |  66 ++-
 .../test_lifecycle_investigation_usage_journal.py  | 101 +++++
 tests/test_lifecycle_journal_codec.py              |  10 +-
 tests/test_lifecycle_source_capacity.py            | 113 -----
 tests/test_lifecycle_source_context.py             |  47 --
 tests/test_lifecycle_source_progress.py            | 225 ++++-----
 tests/test_lifecycle_source_read_report.py         | 114 ++---
 tests/test_lifecycle_web_attended_concurrency.py   | 334 --------------
 tests/test_lifecycle_web_gaps.py                   | 233 ----------
 tests/test_lifecycle_web_migration.py              |  80 ----
 tests/test_lifecycle_web_read.py                   | 103 -----
 tests/test_lifecycle_web_review.py                 | 243 ----------
 tests/test_lifecycle_web_store.py                  | 182 --------
 tests/test_lifecycle_web_usage_journal.py          | 141 ------
 tests/test_sec_research_config.py                  | 195 ++++++++
 tests/test_sec_research_paths.py                   | 288 ++++++++++++
 tests/test_security_lifecycle_current.py           |   6 +-
 tests/test_security_lifecycle_population.py        |  30 ++
 tests/test_sqlite_backup.py                        | 183 ++++++++
 tests/test_ticker_identity_history.py              |  93 ++--
 50 files changed, 2699 insertions(+), 2723 deletions(-)

```

## Patch
```diff
diff --git a/src/api/routes/lifecycle_investigation.py b/src/api/routes/lifecycle_investigation.py
index 73f08fd9..696e0b40 100644
--- a/src/api/routes/lifecycle_investigation.py
+++ b/src/api/routes/lifecycle_investigation.py
@@ -1,38 +1,38 @@
 """Target-first investigations. Reads neither dispatch providers nor install journals."""
 
 from functools import lru_cache
 from typing import Literal
 
 from fastapi import APIRouter, Depends, HTTPException
 from pydantic import BaseModel, ConfigDict, Field, StrictBool, field_validator
 
 from src.api.dependencies import get_ticker_identity_service
 from src.api.permissions import require_db_write, require_profile_state_write
 from src.api.routes.ticker_identity import _canonical_date
 from src.lifecycle_investigation.controller import InvestigationController
 from src.lifecycle_investigation.news import LocalNews
 from src.lifecycle_investigation.provider_review import provider_decision, prepare_provider_review
 from src.lifecycle_investigation.runtime import InvestigationRuntime, RuntimeStore
 from src.lifecycle_investigation.store import InvestigationStore, safe_code
 from src.lifecycle_investigation.target import TargetPreflight, Target, provider_observations
-from src.lifecycle_web_review import prepare, confirm
+from src.lifecycle_investigation.review import prepare, confirm
 from src.security_lifecycle_review import project_packet, now
 from src.security_lifecycle_provider_scan import run_provider_scan
 from src.ticker_identity_service import TickerIdentityConflict
 from src.ticker_identity_transition import TransitionOptions
 
 router = APIRouter(prefix="/security-lifecycle/investigations", tags=["security-lifecycle"])
 
 
 def dispatch_permission():
     require_db_write("lifecycle_investigation", {"scope": "selected_target"})
 
 
 @lru_cache(maxsize=1)
 def get_controller():
     from src.api.dependencies import _local_state_db_path, get_credential_store, get_oauth_token_store, get_oauth_observation_store
     from src.auth_drivers.lifecycle_web_models import resolve_web_credential
     from src.auth_drivers.chatgpt_oauth_login import refresh_if_needed
     from src.market_data_admin import resolve_market_db_path
     from src.sa_capture_store import resolve_sa_db_path
 
diff --git a/src/lifecycle_investigation/adoption.py b/src/lifecycle_investigation/adoption.py
index cc7a818c..b3f75caf 100644
--- a/src/lifecycle_investigation/adoption.py
+++ b/src/lifecycle_investigation/adoption.py
@@ -3,122 +3,124 @@
 Only confirmation creates a source anchor. No legacy case or fabricated filing
 is needed to investigate, read a finding, or preview the effects.
 """
 
 from dataclasses import asdict, dataclass
 from pathlib import Path
 import sqlite3
 from types import SimpleNamespace
 
 from src.lifecycle_investigation.findings import Finding, validate_finding
 from src.lifecycle_investigation.schema import verify_journal
 from src.lifecycle_investigation.store import InvestigationStore
 from src.lifecycle_investigation.target import Target, target_snapshot
 from src.lifecycle_journal_codec import digest_json
 from src.security_lifecycle_investigation import SecurityLifecycleInvestigationStore, case_id_for
 from src.security_lifecycle_review import _FINDING_FIELDS, _proposal_vetoes, now, packet_digest
 from src.security_lifecycle_web_contract import ExecutionSelection
 from src.ticker_identity_transition import build_transition_effects, _execution_date
 
 
-def is_target_run(run_id):
-    return isinstance(run_id, str) and run_id.startswith("li_")
-
-
 def binding_on_connection(conn, run_id):
     conn.row_factory = sqlite3.Row
     verify_journal(conn)
     row, _ = InvestigationStore.row(conn, run_id)
     saved = conn.execute("SELECT payload_sha256 FROM lifecycle_investigation_results WHERE run_id=?", (run_id,)).fetchone()
     sources = tuple(tuple(item) for item in conn.execute("SELECT source_id,payload_sha256 FROM lifecycle_investigation_sources WHERE run_id=? ORDER BY source_id", (run_id,)))
-    return (row["header_sha256"], row["status"], None if saved is None else saved[0], sources,
+    steps = tuple(tuple(item) for item in conn.execute("SELECT ordinal,kind,payload_sha256 FROM lifecycle_investigation_steps WHERE run_id=? ORDER BY ordinal", (run_id,)))
+    calls = tuple(tuple(item) for item in conn.execute("SELECT call_id,remote_id,terminal FROM lifecycle_investigation_calls WHERE run_id=? ORDER BY call_id", (run_id,)))
+    return (row["header_sha256"], row["status"], None if saved is None else saved[0], sources, steps, calls,
             conn.execute("PRAGMA schema_version").fetchone()[0])
 
 
 def as_adoption(row):
     result = row["result"]
     if row["status"] != "succeeded" or not result or result.get("validated") is None:
         raise ValueError("web_finding_not_complete")
     target = Target.model_validate(row["binding"]["target"])
     requests = [step["payload"] for step in row["steps"] if step["kind"] == "model_request"]
     outputs = [step["payload"] for step in row["steps"] if step["kind"] == "model_result"]
     if not requests or not outputs:
         raise ValueError("investigation_integrity")
+    supplied = requests[-1].get("supplied_passages")
+    if type(supplied) is not list or any(type(item) is not str for item in supplied):
+        raise ValueError("investigation_integrity")
     last = outputs[-1]
     actual = last["output"]
     if (last.get("output_error") is not None or type(actual) is not dict or actual.get("action") != "conclude"
             or Finding.model_validate(actual.get("finding")).model_dump() != result["validated"]["finding"]
             or last["call_id"] != requests[-1]["call_id"]
             or not any(call["call_id"] == last["call_id"] and call["remote_id"] == last["remote_id"] and call["terminal"] == "completed" for call in row["calls"])):
         raise ValueError("investigation_integrity")
-    checked = validate_finding(target, result["validated"]["finding"], row["sources"], set(requests[-1]["supplied_passages"]))
+    checked = validate_finding(target, result["validated"]["finding"], row["sources"], set(supplied))
     if checked != result["validated"]:
         raise ValueError("investigation_integrity")
     source = {"source": "lifecycle_investigation", "source_ref": row["run_id"], "ticker": target.ticker}
     observation_sha = digest_json({**source, "target": target.model_dump()})
     case = {"case_id": case_id_for(**source), **source}
     return {**row, "case_id": case["case_id"], "target_case": case,
         "observation_sha256": observation_sha, "request": target, "selection": ExecutionSelection(**row["binding"]["selection"]),
         "finding": SimpleNamespace(finding=Finding.model_validate(checked["finding"]), action=checked["action"],
             block_reasons=tuple(checked["block_reasons"]), passages=checked["passages"]),
         "pages": {key: SimpleNamespace(retrieved_at=value["retrieved_at"]) for key, value in row["sources"].items()},
         "source_gaps": [{"url": gap["url"], "reason": gap["reason"]} for gap in result["gaps"]]}
 
 
 @dataclass(frozen=True)
 class ValidatedInvestigationRead:
     path: Path
     run_id: str
     binding: tuple
     material: dict
 
     def on_connection(self, conn, run_id):
         database = next((row[2] for row in conn.execute("PRAGMA database_list") if row[1] == "main"), None)
         if (not conn.in_transaction or run_id != self.run_id or not database or Path(database).resolve() != self.path
                 or binding_on_connection(conn, run_id) != self.binding):
             raise ValueError("investigation_integrity")
         return self.material
 
 
 def validated_read(path, run_id):
     store = InvestigationStore(path)
     with store.connection() as conn:
         binding = binding_on_connection(conn, run_id)
-        row = InvestigationStore.read_on_connection(conn, run_id)
+        capture = store.capture_on_connection(conn, run_id)
     # Large source parsing is outside the mutable profile transaction.
+    row = store.decode_capture(capture)
     read = ValidatedInvestigationRead(store.path, run_id, binding, as_adoption(row))
     with store.connection() as conn:
         read.on_connection(conn, run_id)
     return read
 
 
 def read_on_connection(conn, run_id, *, validated=None):
     if validated is not None:
         if type(validated) is not ValidatedInvestigationRead:
             raise ValueError("investigation_integrity")
         return validated.on_connection(conn, run_id)
     verify_journal(conn)
     return as_adoption(InvestigationStore.read_on_connection(conn, run_id))
 
 
 def prepare_on_connection(service, conn, *, run_id, options, web_read=None):
-    from src.lifecycle_web_review import assessment_id_for, acceptance_for, _adoption_values, _provider_veto, _freshness
+    from src.lifecycle_investigation.review import assessment_id_for, acceptance_for, _adoption_values, _provider_veto, _freshness
     run = read_on_connection(conn, run_id, validated=web_read)
     case = run["target_case"]
     store = SecurityLifecycleInvestigationStore(conn)
     at = now(service)
     blockers = list(run["finding"].block_reasons) + list(_freshness(run, at))
     sources = service._read_service.sources_by_ticker()
     active = None if sources is None else tuple(sources.get(case["ticker"], ()))
     # The source's identity is immutable; a changed current stable identifier is a conflict, not a new alias.
     try:
         current = target_snapshot(service, case["ticker"], conn=conn)
         for field in ("issuer_cik", "composite_figi", "security_class", "venue"):
             old, new = getattr(run["request"], field), getattr(current, field)
             if old is not None and new is not None and old != new:
                 blockers.append("web_security_identity_conflict")
         if current.identity_status == "conflicting":
             blockers.append("web_security_identity_conflict")
     except ValueError as exc:
         blockers.append(str(exc))
     if run["finding"].action is None:
         blockers.append("web_finding_not_actionable")
diff --git a/src/lifecycle_investigation/agent.py b/src/lifecycle_investigation/agent.py
index 1f01a7c2..64afd44b 100644
--- a/src/lifecycle_investigation/agent.py
+++ b/src/lifecycle_investigation/agent.py
@@ -184,45 +184,46 @@ async def run_agent(target, credential, control, *, runtime, effort, news, provi
     counts = dict(http_requests=0, source_reads=0, local_queries=0, retained_source_bytes=0)
     replies, repeats = [], Counter()
     last_feedback, last_validated = None, None
 
     def check():
         if control.stop_state != "running":
             raise WebModelError("stop_requested")
         if monotonic() >= deadline:
             raise ValueError("investigation_budget_exhausted")
 
     def record(kind, value):
         check()
         on_step(kind, value)
 
     def gap(reason, *, url=None, corpus=None):
         item = {"reason": reason, "url": url, "corpus": corpus}
         if item not in gaps:
             gaps.append(item)
 
     def stats():
+        submissions = control.recorded_model_requests
         totals = {}
         for field in ("input_tokens", "output_tokens"):
             values = [reply.usage[field] for reply in replies]
-            totals[field] = (sum(values) if len(values) == control.model_requests and all(value is not None for value in values) else None)
-        return {**counts, "model_submissions": control.model_requests,
+            totals[field] = (sum(values) if len(values) == submissions and all(value is not None for value in values) else None)
+        return {**counts, "model_submissions": submissions,
             "web_actions": sum(control.observed_web_actions.values()), "sources": len(sources),
             "elapsed_seconds": round(monotonic() - started, 3), **totals}
 
     def result(status, reason=None):
         return {"version": 2, "status": status, "stop_reason": reason, "validated": last_validated,
             "gaps": gaps, "stats": stats(), "supplied_passages": sorted(supplied)}
 
     def include_passages(identity, *, query=None, offset=0):
         context = select_passages(identity, sources[identity], ticker=target.ticker,
             issuer_name=target.issuer_name, query=query, offset=offset)
         selected = [item["passage_id"] for item in context["passages"]]
         old = contexts.get(identity, {}).get("passages", [])
         context["passages"] = list({item["passage_id"]: item for item in [*old, *context["passages"]]}.values())
         context["input_coverage"] = "full_text" if len(context["passages"]) == context["total_passages"] else "selected_passages"
         contexts[identity] = context
         supplied.update(selected)
         return {"source_id": identity, "selected_passage_ids": selected,
             **{key: value for key, value in context.items() if key != "passages"}}
 
     def add_source(source, *, query=None):
@@ -267,44 +268,46 @@ async def run_agent(target, credential, control, *, runtime, effort, news, provi
         value = news.read(candidate)
         return add_source(value)
 
     async def submit(phase, prompt, schema, *, search_limit=None):
         check()
         if control.model_requests >= runtime.model_submissions:
             raise ValueError("investigation_budget_exhausted")
         identity = f"step-{control.model_requests + 1}"
         call = ModelCall(credential.selection, identity, phase, prompt, schema, effort,
             runtime.api_output_tokens if credential.selection.auth_mode == "api_key" else None,
             search_limit or 1, min(runtime.model_timeout_seconds, max(0.01, deadline - monotonic())), retain_rejected_output=True)
         record("model_request", {"call_id": identity, "phase": phase, "prompt_sha256": digest_json(prompt),
             "supplied_passages": sorted(supplied), "remaining_seconds": max(0, deadline - monotonic())})
         reply = await model(call, credential, control)
         if control.terminal_statuses.get(identity) != "completed":
             raise WebModelError("model_result_incomplete")
         if reply.remote_id != getattr(control, "_calls")[identity].remote_id:
             raise WebModelError("execution_identity_changed")
         if reply.usage_observation is not None:
             validate_usage_observation(reply.usage_observation)
-        replies.append(reply)
-        record("model_result", {"call_id": identity, "phase": phase, "remote_id": reply.remote_id,
+        # Record completed work even after stop/deadline; this dispatches no new work.
+        on_step("model_result", {"call_id": identity, "phase": phase, "remote_id": reply.remote_id,
             "usage": reply.usage, "usage_observation": reply.usage_observation, "output_error": reply.output_error,
             "output": reply.output})
+        replies.append(reply)
+        check()
         if sum(control.observed_web_actions.values()) > runtime.web_actions:
             raise ValueError("investigation_budget_exhausted")
         return reply
 
     async def read_url(url, *, query=None):
         check()
         url = canonical_source_url(url)
         if url not in admitted_urls:
             return {"code": "source_url_not_observed"}
         prior = next((key for key, source in sources.items() if source["url"] == url), None)
         if prior:
             if query:
                 include_passages(prior, query=query)
             return {"source_id": prior, "code": "source_already_read"}
         if counts["source_reads"] >= runtime.source_reads or counts["http_requests"] >= runtime.http_requests:
             raise ValueError("investigation_budget_exhausted")
         counts["source_reads"] += 1
         reader = reader_factory(SourceReadLimits(runtime.http_requests - counts["http_requests"], 3,
             32 * 1024 * 1024, min(180, max(0.01, deadline - monotonic())), 128 * 1024 * 1024))
         pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="lifecycle-investigation-source")
diff --git a/src/lifecycle_investigation/disposal.py b/src/lifecycle_investigation/disposal.py
index 7d04bff5..893edb79 100644
--- a/src/lifecycle_investigation/disposal.py
+++ b/src/lifecycle_investigation/disposal.py
@@ -1,42 +1,41 @@
 """Digest-bound, dependency-aware disposal. Each database has its own atomic receipt.
 
 Two WAL databases do not offer a crash-atomic shared commit. Stages are therefore
 explicit, independently resumable, and never reported as one completed operation.
 """
 
 from collections import defaultdict
 from contextlib import contextmanager
 from datetime import datetime, timezone
 from pathlib import Path
 import json
 import sqlite3
 
 from src.lifecycle_investigation.schema import verify_journal
-from src.lifecycle_web_migration import _backup
-from src.lifecycle_web_schema import TABLES as WEB_TABLES, TRIGGERS as WEB_TRIGGERS
 from src.lifecycle_journal_codec import canonical_json, digest_json
 from src.security_lifecycle_listing_migration import _quote_identifier as q, _sha_file
 from src.security_lifecycle_schema import PROFILE_TABLE_SQL, verify_profile_connection, verify_market_connection, _normalize_sql
+from src.sqlite_backup import backup_connection
 
 
-OWNED = (set(PROFILE_TABLE_SQL) | set(WEB_TABLES)) - {"security_lifecycle_provider_checks", "security_lifecycle_migration_receipts"}
+OWNED = set(PROFILE_TABLE_SQL) - {"security_lifecycle_provider_checks", "security_lifecycle_migration_receipts"}
 RECEIPT_SQL = """CREATE TABLE lifecycle_legacy_disposal_receipts (
     approval_sha256 TEXT PRIMARY KEY, stage TEXT NOT NULL CHECK(stage IN ('market','profile')),
     completed_at TEXT NOT NULL, receipt_json TEXT NOT NULL, receipt_sha256 TEXT NOT NULL)"""
 RECEIPT_TRIGGERS = {f"lifecycle_legacy_disposal_receipts_{op.lower()}": f"""CREATE TRIGGER lifecycle_legacy_disposal_receipts_{op.lower()}
     BEFORE {op} ON lifecycle_legacy_disposal_receipts BEGIN SELECT RAISE(ABORT,'disposal_receipt_immutable'); END""" for op in ("UPDATE", "DELETE")}
 
 
 def _receipt(conn, approval, stage):
     row = conn.execute("SELECT sql FROM sqlite_master WHERE name='lifecycle_legacy_disposal_receipts'").fetchone()
     if row is None:
         return None
     if _normalize_sql(row[0]) != _normalize_sql(RECEIPT_SQL):
         raise ValueError("disposal_receipt_invalid")
     for name, sql in RECEIPT_TRIGGERS.items():
         row = conn.execute("SELECT sql FROM sqlite_master WHERE name=?", (name,)).fetchone()
         if not row or _normalize_sql(row[0]) != _normalize_sql(sql):
             raise ValueError("disposal_receipt_invalid")
     row = conn.execute("SELECT stage,receipt_json,receipt_sha256 FROM lifecycle_legacy_disposal_receipts WHERE approval_sha256=?", (approval,)).fetchone()
     if row is None:
         return None
@@ -54,61 +53,65 @@ def _receipt(conn, approval, stage):
 def connect(path, mode="ro"):
     conn = sqlite3.connect(Path(path).resolve().as_uri() + f"?mode={mode}", uri=True, timeout=10)
     conn.row_factory = sqlite3.Row
     conn.execute("PRAGMA foreign_keys=ON")
     if mode == "ro":
         conn.execute("PRAGMA query_only=ON")
     try:
         yield conn
     finally:
         conn.close()
 
 
 def foreign_keys(conn):
     edges = []
     for (table,) in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"):
         groups = defaultdict(list)
         for row in conn.execute(f"PRAGMA foreign_key_list({q(table)})"):
             groups[row[0]].append(row)
         for group in groups.values():
             ordered = sorted(group, key=lambda row: row[1])
-            edges.append((table, ordered[0][2], tuple((row[3], row[4]) for row in ordered)))
+            # PRAGMA preserves declared spelling; ownership uses SQLite identities.
+            target = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=? COLLATE NOCASE",
+                (ordered[0][2],)).fetchone()
+            parent = target[0] if target is not None else ordered[0][2]
+            edges.append((table, parent, tuple((row[3], row[4]) for row in ordered)))
     return edges
 
 
 def closure(conn, case_id):
     row = conn.execute("SELECT rowid AS _rowid_,* FROM security_lifecycle_cases WHERE case_id=? AND source='sec_edgar'", (case_id,)).fetchone()
     if row is None:
         raise ValueError("disposal_changed")
     result, pending = defaultdict(dict), [("security_lifecycle_cases", dict(row))]
     edges = foreign_keys(conn)
     reason = None
     while pending:
         table, row = pending.pop()
         if row["_rowid_"] in result[table]:
             continue
         result[table][row["_rowid_"]] = row
         if row.get("case_id", case_id) != case_id:
             reason = "cross_case_dependency"
         if table == "security_lifecycle_assessments" and row.get("acceptance_authority") == "human":
             reason = "human_assessment"
-        if table in {"security_lifecycle_automation_runs", "security_lifecycle_investigation_runs", "lifecycle_web_runs"} and row.get("status") in {"running", "queued", "searching", "reading_sources", "analyzing", "cancelling", "remote_outcome_unknown"}:
+        if table in {"security_lifecycle_automation_runs", "security_lifecycle_investigation_runs"} and row.get("status") in {"running", "queued", "searching", "reading_sources", "analyzing", "cancelling", "remote_outcome_unknown"}:
             reason = "unfinished_execution"
         for child, parent, columns in edges:
             if parent != table:
                 continue
             if any(parent_col is None for _, parent_col in columns):
                 reason = "unreviewed_foreign_key"
                 continue
             predicate = " AND ".join(f"{q(child_col)}=?" for child_col, _ in columns)
             params = tuple(row[parent_col] for _, parent_col in columns)
             if child not in OWNED:
                 if conn.execute(f"SELECT 1 FROM {q(child)} WHERE {predicate} LIMIT 1", params).fetchone():
                     reason = "retained_external_dependency"
                 continue
             children = conn.execute(f"SELECT rowid AS _rowid_,* FROM {q(child)} WHERE {predicate}", params).fetchall()
             for item in children:
                 child_row = dict(item)
                 assessment = child_row.get("assessment_id")
                 if assessment:
                     owner = conn.execute("SELECT case_id FROM security_lifecycle_assessments WHERE assessment_id=?", (assessment,)).fetchone()
                     if owner and owner[0] != case_id:
@@ -217,60 +220,50 @@ def apply_disposal_stage(path, plan, *, stage, approval_sha256, backup_path, app
         exists = conn.execute("SELECT 1 FROM sqlite_master WHERE name='lifecycle_legacy_disposal_receipts'").fetchone()
         receipt = _receipt(conn, approval_sha256, stage)
         if receipt is not None:
             if stage == "profile":
                 reappeared = any(conn.execute("SELECT 1 FROM security_lifecycle_cases WHERE case_id=?", (identity,)).fetchone() for identity in plan["roots"])
             else:
                 reappeared = any(conn.execute("SELECT 1 FROM security_lifecycle_observations WHERE id=?", (identity,)).fetchone() for identity in plan["stages"]["market"]["observation_ids"])
             if reappeared:
                 raise ValueError("disposal_changed")
             return {**receipt, "status": "already_completed"}
         if stage == "profile":
             verify_journal(conn)
         expected = plan["stages"][stage]
         def observed():
             return profile_scope(conn, plan["roots"]) if stage == "profile" else market_scope(conn, expected["observation_ids"])
         if observed() != expected:
             raise ValueError("disposal_changed")
         backup = Path(backup_path).resolve()
         if backup == Path(path).resolve():
             raise ValueError("disposal_backup_path")
-        _backup(conn, backup)
+        backup_connection(conn, backup)
         conn.execute("BEGIN IMMEDIATE")
         try:
             if observed() != expected:
                 raise ValueError("disposal_changed")
             if not exists:
                 conn.execute(RECEIPT_SQL)
                 for sql in RECEIPT_TRIGGERS.values():
                     conn.execute(sql)
             if stage == "profile":
-                dropped = []
-                for name, sql in WEB_TRIGGERS.items():
-                    owner = conn.execute("SELECT tbl_name,sql FROM sqlite_master WHERE name=?", (name,)).fetchone()
-                    if owner and owner[0] in expected:
-                        if _normalize_sql(owner[1]) != _normalize_sql(sql):
-                            raise ValueError("disposal_changed")
-                        conn.execute(f"DROP TRIGGER {q(name)}")
-                        dropped.append(sql)
                 for table in _delete_order(conn, expected):
                     conn.executemany(f"DELETE FROM {q(table)} WHERE rowid=?", [(identity,) for identity in expected[table]["rowids"]])
-                for sql in dropped:
-                    conn.execute(sql)
                 verify_profile_connection(conn)
                 verify_journal(conn)
             else:
                 conn.executemany("DELETE FROM security_lifecycle_observation_kinds WHERE observation_id=?", [(i,) for i in expected["observation_ids"]])
                 conn.executemany("DELETE FROM security_lifecycle_observations WHERE id=?", [(i,) for i in expected["observation_ids"]])
                 verify_market_connection(conn)
             if conn.execute("PRAGMA foreign_key_check").fetchone():
                 raise ValueError("disposal_foreign_key")
             receipt = {"status": "completed", "stage": stage, "approval_sha256": approval_sha256,
                 "backup_sha256": _sha_file(backup),
                 "counts": {table: len(value["rowids"]) for table, value in expected.items()} if stage == "profile" else {"observations": len(expected["observation_ids"])}}
             conn.execute("INSERT INTO lifecycle_legacy_disposal_receipts VALUES(?,?,?,?,?)",
                 (approval_sha256, stage, datetime.now(timezone.utc).isoformat(), canonical_json(receipt), digest_json(receipt)))
             conn.commit()
             return receipt
         except BaseException:
             conn.rollback()
             raise
diff --git a/src/lifecycle_investigation/migration.py b/src/lifecycle_investigation/migration.py
index f07fe084..0e7666c4 100644
--- a/src/lifecycle_investigation/migration.py
+++ b/src/lifecycle_investigation/migration.py
@@ -1,33 +1,33 @@
 """Explicit backed-up journal cutover, with unchanged existing profile contents."""
 
 from contextlib import closing
 import hashlib
 from pathlib import Path
 import sqlite3
 
 from src.lifecycle_investigation.schema import installed, schema_digest, verify_journal, _install_on_connection
 from src.lifecycle_journal_codec import digest_json
-from src.lifecycle_web_migration import _backup
 from src.security_lifecycle_listing_migration import _encode_cell, _quote_identifier as q, _sha_file
 from src.security_lifecycle_provider_snapshot import instant
 from src.security_lifecycle_schema import verify_profile_connection, assert_lifecycle_writes_available
+from src.sqlite_backup import backup_connection
 
 
 def _snapshot(conn, names=None):
     schema = [tuple(row) for row in conn.execute("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name")
         if names is None or row[2] in names]
     rows = hashlib.sha256()
     for kind, name, _, _ in schema:
         if kind != "table":
             continue
         rows.update(_encode_cell(name))
         primary = sorted((row[5], row[1]) for row in conn.execute(f"PRAGMA table_info({q(name)})") if row[5])
         order = ",".join(q(column) for _, column in primary) or "rowid"
         for row in conn.execute(f"SELECT * FROM {q(name)} ORDER BY {order}"):
             rows.update(b"row:")
             for cell in row:
                 value = _encode_cell(cell)
                 rows.update(str(len(value)).encode() + b":" + value)
     return {"schema_sha256": digest_json(schema), "rows_sha256": rows.hexdigest()}
 
 
@@ -47,38 +47,38 @@ def preview_installation(path):
         conn.execute("PRAGMA query_only=ON")
         conn.execute("BEGIN")
         return _preview(conn)
 
 
 def apply_installation(path, *, backup_path, approval_sha256, at, app_stopped):
     if app_stopped is not True:
         raise ValueError("investigation_install_app_stop_required")
     instant(at)
     path, backup = Path(path).resolve(), Path(backup_path).resolve()
     if path == backup:
         raise ValueError("investigation_install_backup_path")
     with closing(sqlite3.connect(path.as_uri() + "?mode=rw", uri=True, timeout=10)) as conn:
         conn.execute("PRAGMA foreign_keys=ON")
         before = _preview(conn)
         if before["approval_sha256"] != approval_sha256:
             raise ValueError("investigation_install_changed")
         assert_lifecycle_writes_available(conn)
         if before["installed"]:
             return {"changed": False, **before}
-        _backup(conn, backup)
+        backup_connection(conn, backup)
         if preview_installation(backup) != before:
             raise ValueError("investigation_install_backup_changed")
         conn.execute("BEGIN IMMEDIATE")
         try:
             if _preview(conn) != before:
                 raise ValueError("investigation_install_changed")
             names = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
             old = _snapshot(conn, names)
             _install_on_connection(conn, at=at)
             if _snapshot(conn, names) != old:
                 raise ValueError("investigation_install_existing_data_changed")
             conn.commit()
         except BaseException:
             conn.rollback()
             raise
     return {"changed": True, "approval_sha256": approval_sha256, "target_schema_sha256": schema_digest(),
         "backup_sha256": _sha_file(backup), "installed_at": at}
diff --git a/src/lifecycle_investigation/review.py b/src/lifecycle_investigation/review.py
new file mode 100644
index 00000000..fd777501
--- /dev/null
+++ b/src/lifecycle_investigation/review.py
@@ -0,0 +1,215 @@
+"""Human adoption of a model-authored finding through the governed writer.
+
+Preparing a packet never invents an accepted assessment. The eventual human
+decision and the immutable model/source journal have different authorship.
+"""
+
+from datetime import timedelta
+import hashlib
+import json
+import sqlite3
+
+from src.lifecycle_investigation.adoption import prepare_on_connection, read_on_connection, validated_read
+from src.lifecycle_investigation.schema import verify_journal
+from src.lifecycle_investigation.store import JournalError
+from src.lifecycle_journal_codec import canonical_json
+from src.security_lifecycle_investigation import SecurityLifecycleInvestigationStore
+from src.security_lifecycle_provider_authority import evidence_dict, validate_provider_material
+from src.security_lifecycle_provider_snapshot import instant
+from src.security_lifecycle_provider_store import ProviderCheckStore
+from src.security_lifecycle_review import (
+    _FINDING_FIELDS, _matching_transition, approved_preview, execute, now, packet_digest,
+)
+from src.ticker_identity_transition import _sha256
+
+
+def assessment_id_for(run_id):
+    return "sla_web_" + hashlib.sha256(run_id.encode()).hexdigest()[:32]
+
+
+def acceptance_for(conn, assessment_id):
+    if not conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='lifecycle_investigation_acceptances'").fetchone():
+        return None
+    row = conn.execute("SELECT * FROM lifecycle_investigation_acceptances WHERE assessment_id=?", (assessment_id,)).fetchone()
+    if row is None:
+        return None
+    verify_journal(conn)
+    value = dict(row)
+    packet = json.loads(value["packet_json"])
+    if (packet_digest(packet) != value["packet_sha256"] or packet.get("packet_sha256") != value["packet_sha256"]
+            or packet.get("assessment_id") != assessment_id or packet.get("lane") != "investigation"
+            or packet.get("web", {}).get("run_id") != value["run_id"] or value["actor"] != "attended_user"):
+        raise ValueError("web_acceptance_invalid")
+    return {**value, "packet": packet}
+
+
+def _adoption_values(run, *, evidence_sha256, revision):
+    finding = run["finding"].finding
+    kind = run["finding"].action
+    values = {key: None for key in _FINDING_FIELDS}
+    values.update(conclusion="Attended adoption of the cited Web investigation.", impact_summary=finding.summary,
+                  relevance="direct_tracked_security", confidence="high", outcomes=[
+                      "listing_ended" if kind == "terminal_delisting" else "symbol_changed" if kind == "symbol_continuation" else "undetermined"],
+                  successor_ticker=finding.successor_ticker, effective_date=finding.effective_date)
+    values.update(assessment_id=assessment_id_for(run["run_id"]), case_id=run["case_id"], revision=revision, author="human",
+                  observation_fingerprint_sha256=run["observation_sha256"], evidence_set_sha256=evidence_sha256)
+    return values
+
+
+def _provider_veto(conn, run, *, at):
+    """A failed lookup is not a veto; positive contrary identity/trading is."""
+    check = ProviderCheckStore.latest_for_connection(conn, run["request"].ticker)
+    if check is None:
+        return (), None
+    rows, blockers = [], set()
+    request, finding = run["request"], run["finding"].finding
+    for raw in check["evidence"]:
+        item = evidence_dict(raw)
+        validate_provider_material(item)
+        if item["kind"] != "listing_directory_snapshot":
+            continue
+        locator = item["source_locator"]
+        if locator.get("snapshot_complete") is True:
+            rows.append((locator, instant(item["retrieved_at"])))
+    source = [(row, observed) for row, observed in rows if row.get("candidate_ticker") == request.ticker]
+    for field in ("issuer_cik", "composite_figi"):
+        known = {row[field] for row, _ in source if row.get(field)}
+        expected = getattr(request, field)
+        if len(known) > 1 or (expected is not None and known and known != {expected}):
+            blockers.add("web_security_identity_conflict")
+    if finding.timing == "completed":
+        for row, observed in source:
+            if (row.get("listing_status") == "active" and instant(at) - timedelta(days=3) <= observed <= instant(at)
+                    and (finding.effective_date is None or observed.date().isoformat() >= finding.effective_date)):
+                blockers.add("web_active_listing_conflict")
+    if finding.event_kind == "symbol_continuation":
+        old_ids = {row["composite_figi"] for row, _ in source if row.get("composite_figi")}
+        new_ids = {row["composite_figi"] for row, _ in rows if row.get("candidate_ticker") == finding.successor_ticker and row.get("composite_figi")}
+        if old_ids and new_ids and (len(old_ids | new_ids) != 1):
+            blockers.add("web_security_identity_conflict")
+    return tuple(sorted(blockers)), check["digest"]
+
+
+def _freshness(run, at):
+    when = instant(at)
+    times = [instant(run["finished_at"]), *(instant(page.retrieved_at) for page in run["pages"].values())]
+    return () if times and all(when - timedelta(days=3) <= observed <= when for observed in times) else ("web_finding_stale",)
+
+
+def prepare(service, run_id, *, options):
+    web_read = validated_read(service.profile_db_path, run_id)
+    with service._profile_connection(write=False) as conn:
+        conn.execute("BEGIN")
+        return prepare_on_connection(service, conn, run_id=run_id, options=options, web_read=web_read)[0]
+
+
+def validated_adoption_read(service, *, assessment_id, conn=None):
+    if conn is None:
+        with service._profile_connection(write=False) as owned:
+            return validated_adoption_read(service, assessment_id=assessment_id, conn=owned)
+    if conn.in_transaction:
+        raise RuntimeError("caller_transaction_open")
+    conn.row_factory = sqlite3.Row
+    accepted = acceptance_for(conn, assessment_id)
+    return (None if accepted is None else
+            validated_read(service.profile_db_path, accepted["run_id"]))
+
+
+def investigation_transition_guard(conn, *, assessment, observation_sha256, transition_kind, successor_ticker, at,
+                         automation=False, confirmation=None, require_confirmation=False, web_read=None):
+    """None means the ordinary lane. An investigation adoption cannot fall through."""
+    identity = assessment["assessment_id"]
+    accepted = acceptance_for(conn, identity)
+    if accepted is None:
+        return ("web_acceptance_required",) if identity.startswith("sla_web_") else None
+    packet = accepted["packet"]
+    run = read_on_connection(conn, accepted["run_id"], validated=web_read)
+    expected = packet["assessment_material"]
+    blockers = []
+    if require_confirmation and not isinstance(confirmation, dict):
+        blockers.append("web_acceptance_required")
+    if (automation or assessment.get("acceptance_authority") != "human" or assessment.get("status") != "accepted"
+            or any(assessment.get(key) != value for key, value in expected.items())
+            or packet["ready"] is not True or packet["block_reasons"] or packet["action"] != transition_kind
+            or packet["finding"]["successor_ticker"] != successor_ticker
+            or packet.get("source_gaps", []) != run["source_gaps"]
+            or packet["observation_fingerprint_sha256"] != observation_sha256
+            or identity != assessment_id_for(run["run_id"]) or run["finding"].action != transition_kind
+            or run["result_sha256"] != packet["web"]["result_sha256"] or run["header_sha256"] != packet["web"]["header_sha256"]):
+        blockers.append("web_acceptance_invalid")
+    if confirmation is not None and (confirmation.get("packet_sha256") != accepted["packet_sha256"]
+                                      or confirmation.get("actor") != "attended_user"):
+        blockers.append("web_acceptance_invalid")
+    current = SecurityLifecycleInvestigationStore(conn)
+    if current._evidence_set_sha256(run["case_id"]) != packet["evidence_set_sha256"]:
+        blockers.append("web_evidence_changed")
+    latest = conn.execute("SELECT assessment_id FROM security_lifecycle_assessments WHERE case_id=? ORDER BY revision DESC LIMIT 1", (run["case_id"],)).fetchone()
+    if latest[0] != identity:
+        blockers.append("assessment_superseded")
+    vetoes, provider_digest = _provider_veto(conn, run, at=at)
+    blockers.extend(vetoes)
+    if provider_digest != packet["provider_check_sha256"]:
+        blockers.append("web_observation_changed")
+    blockers.extend(_freshness(run, at))
+    return tuple(sorted(set(blockers)))
+
+
+def confirm(service, run_id, *, packet_sha256, action, options, before_write, acknowledge_source_gaps=False):
+    from src.ticker_identity_service import TickerIdentityConflict
+
+    _sha256("review_digest", packet_sha256)
+    if action not in {"terminal_delisting", "symbol_continuation"}:
+        raise ValueError("review_action")
+    before_write()
+    web_read = validated_read(service.profile_db_path, run_id)
+    before_write()
+    with service._profile_connection(write=True) as conn:
+        conn.row_factory = sqlite3.Row
+        conn.execute("BEGIN IMMEDIATE")
+        try:
+            run = read_on_connection(conn, run_id, validated=web_read)
+            if run.get("source_gaps") and acknowledge_source_gaps is not True:
+                raise JournalError("web_source_gaps_not_acknowledged")
+            store = service._store(conn)
+            identity = assessment_id_for(run_id)
+            existing = _matching_transition(store, case_id=run["case_id"], assessment_id=identity, action=action,
+                                            packet_sha256=packet_sha256, options=options)
+            if existing is not None:
+                transition_id = existing["transition_id"]
+                conn.rollback()
+            else:
+                packet, case, _ = prepare_on_connection(service, conn, run_id=run_id, options=options, web_read=web_read)
+                if packet["packet_sha256"] != packet_sha256 or packet["action"] != action:
+                    raise TickerIdentityConflict("review_changed")
+                if not packet["ready"]:
+                    raise ValueError("web_review_ineligible")
+                if acceptance_for(conn, identity) is not None:
+                    raise ValueError("web_acceptance_already_recorded")
+                at = now(service)
+                values = packet["assessment_material"]
+                investigation = SecurityLifecycleInvestigationStore(conn, id_factory=lambda prefix, ordinal: identity if prefix == "sla" else f"{prefix}_{hashlib.sha256(f'{run_id}:{prefix}:{ordinal}'.encode()).hexdigest()[:32]}")
+                before_write()
+                # A real attended-source anchor, inside this same rollback boundary.
+                investigation._upsert_case_row(case["case_id"], (case["source"], case["source_ref"], case["ticker"]), at=at)
+                investigation.create_assessment(
+                    **{key: values[key] for key in (*_FINDING_FIELDS, "case_id", "author", "observation_fingerprint_sha256")},
+                    citations=[{"reference_kind": "observation", "cited_content_sha256": packet["observation_fingerprint_sha256"]}],
+                    at=at, _caller_transaction=True,
+                )
+                assessment = investigation.accept_assessment(identity, observation_fingerprint_sha256=packet["observation_fingerprint_sha256"],
+                    acceptance_authority="human", at=at, _caller_transaction=True)
+                conn.execute("INSERT INTO lifecycle_investigation_acceptances VALUES (?,?,?,?,?,?)",
+                             (identity, run_id, canonical_json(packet), packet_sha256, "attended_user", at))
+                investigation.generate_action_proposals(case_id=case["case_id"], observation_fingerprint_sha256=packet["observation_fingerprint_sha256"],
+                    sources_by_ticker={case["ticker"]: packet["active_sources"]}, at=at, _caller_transaction=True)
+                confirmation = {"version": 1, "packet_sha256": packet_sha256, "actor": "attended_user", "action": action, "confirmed_at": at, "packet": packet}
+                preview = approved_preview(conn, packet=packet, case=case, assessment=assessment, confirmation=confirmation, at=at, web_read=web_read)
+                transition = store._approve(preview=preview, approved_preview_sha256=preview["preview_sha256"], automation=False,
+                    _caller_transaction=True, web_read=web_read)
+                transition_id = transition["transition_id"]
+                before_write()
+                conn.commit()
+        except BaseException:
+            conn.rollback()
+            raise
+    return execute(service, transition_id, before_write=before_write, web_read=web_read)
diff --git a/src/lifecycle_investigation/schema.py b/src/lifecycle_investigation/schema.py
index 2e944370..1fda4fa2 100644
--- a/src/lifecycle_investigation/schema.py
+++ b/src/lifecycle_investigation/schema.py
@@ -1,21 +1,21 @@
-"""Explicit v2 installation; legacy v1 journals are neither rewritten nor dropped."""
+"""Current investigation journal; initialization never rewrites populated stores."""
 
 import hashlib
 
 from src.security_lifecycle_provider_snapshot import instant
 from src.security_lifecycle_schema import _normalize_sql, assert_lifecycle_writes_available, verify_profile_connection
 
 
 TABLES = {
     "lifecycle_investigation_installation": """CREATE TABLE lifecycle_investigation_installation (
         singleton INTEGER PRIMARY KEY CHECK(singleton=1), version INTEGER NOT NULL CHECK(version=2),
         schema_sha256 TEXT NOT NULL, installed_at TEXT NOT NULL)""",
     "lifecycle_investigation_jobs": """CREATE TABLE lifecycle_investigation_jobs (
         run_id TEXT PRIMARY KEY, ticker TEXT NOT NULL, request_key TEXT NOT NULL UNIQUE,
         header_json TEXT NOT NULL, header_sha256 TEXT NOT NULL CHECK(length(header_sha256)=64),
         owner TEXT NOT NULL, created_at TEXT NOT NULL, lease_until TEXT NOT NULL,
         status TEXT NOT NULL CHECK(status IN ('running','succeeded','incomplete','failed','cancelled','remote_outcome_unknown')),
         phase TEXT NOT NULL, cancel_requested_at TEXT, finished_at TEXT, failure_code TEXT,
         CHECK((status='running' AND finished_at IS NULL) OR (status<>'running' AND finished_at IS NOT NULL)))""",
     "lifecycle_investigation_calls": """CREATE TABLE lifecycle_investigation_calls (
         run_id TEXT NOT NULL REFERENCES lifecycle_investigation_jobs(run_id),
diff --git a/src/lifecycle_investigation/store.py b/src/lifecycle_investigation/store.py
index 08e30a83..d94d6488 100644
--- a/src/lifecycle_investigation/store.py
+++ b/src/lifecycle_investigation/store.py
@@ -1,77 +1,130 @@
 """Append-only steps and sources, durable ownership, and truthful interruption."""
 
 from contextlib import contextmanager
 from datetime import datetime, timedelta, timezone
 from pathlib import Path
 import re
 import sqlite3
 import json
 from uuid import uuid4
 
 from src.auth_drivers.lifecycle_web_models import WebModelError
+from src.auth_drivers.lifecycle_web_usage import token_totals, validate_usage_observation
 from src.lifecycle_investigation.runtime import InvestigationRuntime
 from src.lifecycle_investigation.schema import verify_journal
 from src.lifecycle_journal_codec import canonical_json, digest_json
-from src.lifecycle_public_sources import SourceReadError
-from src.lifecycle_web_store import WebJournalError
+from src.lifecycle_public_sources import SourceReadError, canonical_source_url, validate_source_read_report
 from src.model_routing import ModelRouteUnavailable
 from src.security_lifecycle_provider_snapshot import instant
 from src.security_lifecycle_schema import assert_lifecycle_writes_available
 from src.security_lifecycle_web_contract import ExecutionSelection, RunControl, WebContractError, validate_selection
 
 
+class JournalError(RuntimeError):
+    def __init__(self, code):
+        self.code = code
+        super().__init__(code)
+
+
 def safe_code(exc):
     known = {"target_not_tracked", "tracking_state_unavailable", "selected_credential_unavailable",
         "investigation_not_installed", "investigation_schema_mismatch", "investigation_runtime_version",
         "investigation_runtime_schema_mismatch", "investigation_preflight_changed", "investigation_running",
         "investigation_request_changed", "investigation_owner_changed", "investigation_not_running",
         "investigation_recording_unavailable", "investigation_integrity", "investigation_worker_busy",
         "investigation_budget_exhausted", "investigation_no_progress", "investigation_not_actionable",
         "investigation_source_gaps_not_acknowledged", "local_news_unavailable", "local_candidate_changed",
         "local_candidate_unknown", "local_body_unavailable", "local_query_invalid", "review_changed",
         "provider_review_ineligible", "provider_review_unavailable", "provider_snapshot_changed"}
     value = str(exc)
     if value in known:
         return value
-    if isinstance(exc, (WebModelError, WebJournalError, WebContractError, SourceReadError, ModelRouteUnavailable)):
+    if isinstance(exc, (WebModelError, JournalError, WebContractError, SourceReadError, ModelRouteUnavailable)):
         if value and len(value) <= 100 and all(character in "abcdefghijklmnopqrstuvwxyz_" for character in value):
             return value
     return "web_execution_failed"
 
 
 def _id(value):
     if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,180}", value):
         raise ValueError("investigation_integrity")
     return value
 
 
 def _decoded(raw, digest):
     try:
         value = json.loads(raw)
         if digest_json(value) != digest:
             raise ValueError()
         return value
     except (ValueError, TypeError):
         raise ValueError("investigation_integrity") from None
 
 
+def _validate_observations(row):
+    """A valid digest alone does not bind reported usage to completed calls."""
+    try:
+        calls = {call["call_id"]: call for call in row["calls"]}
+        usages = {}
+        for step in row["steps"]:
+            payload = step["payload"]
+            if step["kind"] == "model_result":
+                identity = payload["call_id"]
+                if (identity in usages or identity not in calls or calls[identity]["terminal"] != "completed"
+                        or payload["remote_id"] != calls[identity]["remote_id"]):
+                    raise ValueError()
+                usages[identity] = token_totals(payload["usage"])
+                if payload["usage_observation"] is not None:
+                    observation = validate_usage_observation(payload["usage_observation"])
+                    if any(observation["values"][key] != value for key, value in usages[identity].items()):
+                        raise ValueError()
+            elif step["kind"] == "source_read":
+                if (set(payload) != {"url", "http_requests", "observations"}
+                        or canonical_source_url(payload["url"]) != payload["url"]):
+                    raise ValueError()
+                validate_source_read_report({"requests": payload["http_requests"], "observations": payload["observations"]},
+                    max_requests=row["binding"]["runtime"]["http_requests"])
+        result = row["result"]
+        if result is None:
+            return
+        stats = result["stats"]
+        if type(stats["model_submissions"]) is not int or stats["model_submissions"] != len(calls):
+            raise ValueError()
+        totals = token_totals({key: stats[key] for key in ("input_tokens", "output_tokens")})
+        for key, total in totals.items():
+            values = [usage[key] for usage in usages.values()]
+            expected = sum(values) if len(values) == len(calls) and all(value is not None for value in values) else None
+            if total != expected:
+                raise ValueError()
+        if type(result["gaps"]) is not list:
+            raise ValueError()
+        for gap in result["gaps"]:
+            if (type(gap) is not dict or set(gap) != {"url", "reason", "corpus"}
+                    or type(gap["reason"]) is not str or re.fullmatch(r"[a-z_]{1,100}", gap["reason"]) is None
+                    or gap["corpus"] not in (None, "news", "sa_market_news")
+                    or (gap["url"] is not None and canonical_source_url(gap["url"]) != gap["url"])):
+                raise ValueError()
+    except (KeyError, TypeError, ValueError, WebModelError):
+        raise ValueError("investigation_integrity") from None
+
+
 class InvestigationStore:
     def __init__(self, path, *, clock=None):
         self.path = Path(path).resolve()
         self.clock = clock or (lambda: datetime.now(timezone.utc).isoformat())
 
     def _now(self):
         return instant(self.clock()).isoformat()
 
     @contextmanager
     def connection(self, *, write=False):
         conn = None
         try:
             conn = sqlite3.connect(self.path.as_uri() + ("?mode=rw" if write else "?mode=ro"), uri=True, timeout=10)
             conn.row_factory = sqlite3.Row
             conn.execute("PRAGMA foreign_keys=ON")
             verify_journal(conn)
             if write:
                 assert_lifecycle_writes_available(conn)
             conn.execute("BEGIN IMMEDIATE" if write else "BEGIN")
             yield conn
@@ -206,73 +259,97 @@ class InvestigationStore:
             raise ValueError("investigation_integrity") from None
 
     def cancel(self, run_id):
         with self.connection(write=True) as conn:
             self.row(conn, run_id)
             conn.execute("UPDATE lifecycle_investigation_jobs SET cancel_requested_at=COALESCE(cancel_requested_at,?) WHERE run_id=? AND status='running'",
                 (self._now(), run_id))
 
     request_cancel = cancel
 
     def recover(self):
         with self.connection(write=True) as conn:
             rows = conn.execute("SELECT run_id FROM lifecycle_investigation_jobs WHERE status='running' AND lease_until<=?", (self._now(),)).fetchall()
             for row in rows:
                 pending = conn.execute("SELECT 1 FROM lifecycle_investigation_calls WHERE run_id=? AND terminal IS NULL", (row[0],)).fetchone()
                 status = "remote_outcome_unknown" if pending else "failed"
                 conn.execute("UPDATE lifecycle_investigation_jobs SET status=?,finished_at=?,failure_code=? WHERE run_id=?",
                     (status, self._now(), "remote_outcome_unknown" if pending else "worker_interrupted", row[0]))
 
     @classmethod
-    def read_on_connection(cls, conn, run_id, *, include_sources=True):
+    def capture_on_connection(cls, conn, run_id, *, include_sources=True):
         row, binding = cls.row(conn, run_id)
+        return {
+            "row": row, "binding": binding,
+            "steps": conn.execute("SELECT * FROM lifecycle_investigation_steps WHERE run_id=? ORDER BY ordinal", (run_id,)).fetchall(),
+            "saved": conn.execute("SELECT * FROM lifecycle_investigation_results WHERE run_id=?", (run_id,)).fetchone(),
+            "sources": conn.execute("SELECT * FROM lifecycle_investigation_sources WHERE run_id=? ORDER BY rowid", (run_id,)).fetchall() if include_sources else [],
+            "adopted": conn.execute("SELECT 1 FROM lifecycle_investigation_acceptances WHERE run_id=?", (run_id,)).fetchone() is not None,
+            "calls": [dict(item) for item in conn.execute("SELECT call_id,remote_id,terminal FROM lifecycle_investigation_calls WHERE run_id=? ORDER BY rowid", (run_id,))],
+        }
+
+    @staticmethod
+    def decode_capture(capture):
         steps = [{"ordinal": item["ordinal"], "kind": item["kind"], "at": item["created_at"],
                   "payload": _decoded(item["payload_json"], item["payload_sha256"])}
-            for item in conn.execute("SELECT * FROM lifecycle_investigation_steps WHERE run_id=? ORDER BY ordinal", (run_id,))]
-        saved = conn.execute("SELECT * FROM lifecycle_investigation_results WHERE run_id=?", (run_id,)).fetchone()
+            for item in capture["steps"]]
+        saved = capture["saved"]
         sources = {item["source_id"]: _decoded(item["payload_json"], item["payload_sha256"])
-            for item in conn.execute("SELECT * FROM lifecycle_investigation_sources WHERE run_id=? ORDER BY rowid", (run_id,))} if include_sources else {}
-        adopted = conn.execute("SELECT 1 FROM lifecycle_investigation_acceptances WHERE run_id=?", (run_id,)).fetchone() is not None
-        return {**row, "binding": binding, "steps": steps, "sources": sources, "adopted": adopted,
-            "calls": [dict(item) for item in conn.execute("SELECT call_id,remote_id,terminal FROM lifecycle_investigation_calls WHERE run_id=? ORDER BY rowid", (run_id,))],
+            for item in capture["sources"]}
+        row = {**capture["row"], "binding": capture["binding"], "steps": steps, "sources": sources, "adopted": capture["adopted"],
+            "calls": capture["calls"],
             "result": None if saved is None else _decoded(saved["payload_json"], saved["payload_sha256"]),
             "result_sha256": None if saved is None else saved["payload_sha256"]}
+        _validate_observations(row)
+        return row
+
+    @classmethod
+    def read_on_connection(cls, conn, run_id, *, include_sources=True):
+        return cls.decode_capture(cls.capture_on_connection(conn, run_id, include_sources=include_sources))
 
     def read(self, run_id, *, include_sources=True):
         with self.connection() as conn:
-            return self.read_on_connection(conn, run_id, include_sources=include_sources)
+            capture = self.capture_on_connection(conn, run_id, include_sources=include_sources)
+        # Owned reads release their snapshot before decoding large source bodies.
+        return self.decode_capture(capture)
 
     def latest(self, ticker):
         with self.connection() as conn:
             row = conn.execute("SELECT run_id FROM lifecycle_investigation_jobs WHERE ticker=? ORDER BY rowid DESC LIMIT 1", (ticker,)).fetchone()
         return None if row is None else self.read(row[0], include_sources=False)
 
     def control(self, run_id, *, owner):
         row = self.read(run_id, include_sources=False)
         return InvestigationControl(self, run_id, owner, ExecutionSelection(**row["binding"]["selection"]), row["binding"]["runtime"])
 
 
 class InvestigationControl(RunControl):
     def __init__(self, store, run_id, owner, selection, runtime):
         super().__init__(selection=selection, max_model_requests=runtime["model_submissions"])
         self.store, self.run_id, self.owner, self.web_limit = store, run_id, owner, runtime["web_actions"]
 
+    @property
+    def recorded_model_requests(self):
+        with self.store.connection() as conn:
+            self.store.row(conn, self.run_id)
+            return conn.execute("SELECT COUNT(*) FROM lifecycle_investigation_calls WHERE run_id=?", (self.run_id,)).fetchone()[0]
+
     def _record(self, method, **kwargs):
         try:
             method(self.run_id, owner=self.owner, **kwargs)
         except BaseException:
             self.request_stop()
             raise
 
     def reserve_model_request(self, call_id):
         super().reserve_model_request(call_id)
         self._record(self.store.reserve_call, call_id=call_id)
 
     def bind_remote_id(self, call_id, remote_id):
         super().bind_remote_id(call_id, remote_id)
         self._record(self.store.bind_call, call_id=call_id, remote_id=remote_id)
 
     def observe_terminal(self, call_id, *, response_id, status, selection):
         super().observe_terminal(call_id, response_id=response_id, status=status, selection=selection)
         self._record(self.store.bind_call, call_id=call_id, remote_id=response_id, terminal=status)
 
     def observe_web_action(self, call_id, item_id, kind):
diff --git a/src/lifecycle_web_migration.py b/src/lifecycle_web_migration.py
deleted file mode 100644
index b3108305..00000000
--- a/src/lifecycle_web_migration.py
+++ /dev/null
@@ -1,94 +0,0 @@
-"""Attended, backed-up Web journal installation; never a profile bootstrap."""
-
-import hashlib
-import json
-import os
-from pathlib import Path
-import re
-import sqlite3
-
-from src.lifecycle_web_schema import _install_on_connection, schema_digest, verify_web_journal
-from src.security_lifecycle_listing_migration import _encode_cell, _quote_identifier, _sha_file
-from src.security_lifecycle_provider_snapshot import instant
-from src.security_lifecycle_schema import assert_lifecycle_writes_available, verify_profile_connection
-
-
-def _snapshot(conn, *, exclude_web=False):
-    schema = [tuple(row) for row in conn.execute("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name")]
-    if exclude_web:
-        schema = [row for row in schema if not row[2].startswith("lifecycle_web_")]
-    schema_sha = hashlib.sha256(json.dumps(schema, ensure_ascii=True, separators=(",", ":")).encode()).hexdigest()
-    rows = hashlib.sha256()
-    for kind, name, _, _ in schema:
-        if kind != "table":
-            continue
-        rows.update(_encode_cell(name))
-        for row in conn.execute(f"SELECT * FROM {_quote_identifier(name)} ORDER BY rowid"):
-            rows.update(b"row:")
-            for cell in row:
-                value = _encode_cell(cell)
-                rows.update(str(len(value)).encode() + b":" + value)
-    return schema_sha, rows.hexdigest()
-
-
-def _preview(conn):
-    verify_profile_connection(conn)
-    if conn.execute("PRAGMA integrity_check").fetchall() != [("ok",)] or conn.execute("PRAGMA foreign_key_check").fetchone():
-        raise ValueError("web_installation_integrity")
-    installed = bool(conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name LIKE 'lifecycle_web_%'").fetchone())
-    if installed:
-        verify_web_journal(conn)
-    schema_sha, rows_sha = _snapshot(conn)
-    value = {"version": 1, "installed": installed, "schema_sha256": schema_sha, "rows_sha256": rows_sha, "target_schema_sha256": schema_digest()}
-    return {**value, "approval_sha256": hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()}
-
-
-def preview_web_installation(path):
-    with sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True) as conn:
-        conn.execute("PRAGMA query_only=ON")
-        conn.execute("BEGIN")
-        return _preview(conn)
-
-
-def _backup(conn, path):
-    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
-    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
-    os.close(fd)
-    with sqlite3.connect(path) as destination:
-        conn.backup(destination)
-
-
-def apply_web_installation(path, *, backup_path, approval_sha256, at, app_stopped):
-    if app_stopped is not True:
-        raise ValueError("web_installation_app_stop_required")
-    instant(at)
-    if not isinstance(approval_sha256, str) or not re.fullmatch("[0-9a-f]{64}", approval_sha256):
-        raise ValueError("web_installation_approval_invalid")
-    path, backup = Path(path).resolve(), Path(backup_path).resolve()
-    if path == backup:
-        raise ValueError("web_installation_backup_path")
-    with sqlite3.connect(path.as_uri() + "?mode=rw", uri=True, timeout=10) as conn:
-        conn.execute("PRAGMA foreign_keys=ON")
-        before = _preview(conn)
-        if before["approval_sha256"] != approval_sha256:
-            raise ValueError("web_installation_preview_changed")
-        assert_lifecycle_writes_available(conn)
-        if before["installed"]:
-            return {"changed": False, **before}
-        _backup(conn, backup)
-        if preview_web_installation(backup)["approval_sha256"] != approval_sha256:
-            raise ValueError("web_installation_backup_changed")
-        conn.execute("BEGIN IMMEDIATE")
-        try:
-            if _preview(conn)["approval_sha256"] != approval_sha256:
-                raise ValueError("web_installation_preview_changed")
-            _install_on_connection(conn, at=at)
-            if _snapshot(conn, exclude_web=True) != (before["schema_sha256"], before["rows_sha256"]):
-                raise ValueError("web_installation_existing_data_changed")
-            after = _preview(conn)
-            conn.commit()
-        except BaseException:
-            conn.rollback()
-            raise
-    return {"changed": True, **after, "previous_approval_sha256": approval_sha256,
-            "previous_rows_sha256": before["rows_sha256"], "backup_sha256": _sha_file(backup), "installed_at": at}
diff --git a/src/lifecycle_web_projection.py b/src/lifecycle_web_projection.py
deleted file mode 100644
index 34ccd8ff..00000000
--- a/src/lifecycle_web_projection.py
+++ /dev/null
@@ -1,65 +0,0 @@
-"""Closed, provider-free Web readbacks shared by the UI and Research tools."""
-
-import sqlite3
-
-from src.lifecycle_web_schema import RUNNING, verify_web_journal
-from src.lifecycle_web_store import LifecycleWebStore
-from src.lifecycle_source_context import parse_source_context
-from src.security_lifecycle_provider_snapshot import instant
-
-
-def project_web_run(row, *, at):
-    """No local credential, worker, remote identifier or full page in the DTO."""
-    status, failure = row["status"], row["failure_code"]
-    if status in RUNNING and instant(row["lease_until"]) <= instant(at):
-        status = "remote_outcome_unknown" if any(call["terminal"] is None for call in row["calls"].values()) else "failed"
-        failure = "web_execution_interrupted"
-    elif status in RUNNING and row["cancel_requested_at"] is not None:
-        status = "cancelling"
-    validated = row["finding"]
-    reading = None
-    if "source_context" in row:
-        contexts = parse_source_context(row["source_context"], row["pages"])
-        reading = {"sources": len(contexts),
-                   "selected_sources": sum(value.ranges != ((0, value.source_bytes),) for value in contexts.values()),
-                   "retained_text_bytes": sum(value.source_bytes for value in contexts.values()),
-                   "model_text_bytes": sum(end - start for value in contexts.values() for start, end in value.ranges)}
-    finding = None
-    if validated is not None:
-        value = validated.finding
-        finding = {key: getattr(value, key) for key in (
-            "source_ticker", "issuer_name", "security_class", "venue", "event_kind", "timing", "summary",
-            "successor_ticker", "effective_date", "announcement_date", "contradictions", "unresolved_conditions")}
-        finding.update(action=validated.action, block_reasons=list(validated.block_reasons),
-                       unique_passage_count=validated.unique_passage_count,
-                       independent_source_count=validated.independent_source_count,
-                       citations=[{"url": passage.source_url, "quote": passage.excerpt, "retrieved_at": passage.retrieved_at}
-                                  for passage in validated.passages])
-    return {
-        "version": 1, "run_id": row["run_id"], "case_id": row["case_id"], "ticker": row["request"].ticker,
-        "status": status, "phase": row["status"] if row["status"] in RUNNING else None,
-        "created_at": row["created_at"], "finished_at": row["finished_at"], "failure_code": failure,
-        "cancel_requested_at": row["cancel_requested_at"],
-        "execution": {key: getattr(row["selection"], key) for key in ("provider", "auth_mode", "model")},
-        "model_submissions": len(row["calls"]), "source_requests": row.get("source_requests"),
-        "usage": row.get("usage", {"input_tokens": None, "output_tokens": None}),
-        "usage_report": row.get("usage_report"),
-        "source_reading": reading,
-        "source_reads": row["source_read_report"]["observations"] if "source_read_report" in row else None,
-        "source_gaps": row["source_gaps"] if validated is not None else None,
-        "finding": finding,
-    }
-
-
-def latest_web_runs(conn, case_ids, *, at):
-    if not conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name LIKE 'lifecycle_web_%'").fetchone():
-        return []
-    verify_web_journal(conn)
-    if not case_ids:
-        return []
-    conn.row_factory = sqlite3.Row
-    placeholders = ",".join("?" for _ in case_ids)
-    rows = conn.execute(f"""SELECT run_id FROM lifecycle_web_runs WHERE rowid IN
-        (SELECT MAX(rowid) FROM lifecycle_web_runs WHERE case_id IN ({placeholders}) GROUP BY case_id)
-        ORDER BY case_id""", list(case_ids)).fetchall()
-    return [project_web_run(LifecycleWebStore.read_on_connection(conn, row[0], include_running_sources=False), at=at) for row in rows]
diff --git a/src/lifecycle_web_schema.py b/src/lifecycle_web_schema.py
deleted file mode 100644
index 96457595..00000000
--- a/src/lifecycle_web_schema.py
+++ /dev/null
@@ -1,143 +0,0 @@
-"""Explicit installation of the independent, model-authored Web journal."""
-
-import hashlib
-import sqlite3
-
-from src.security_lifecycle_schema import _normalize_sql, assert_lifecycle_writes_available, verify_profile_connection
-
-
-class WebJournalError(RuntimeError):
-    def __init__(self, code):
-        self.code = code
-        super().__init__(code)
-
-
-RUNNING = ("queued", "searching", "reading_sources", "analyzing")
-TERMINAL = ("succeeded", "failed", "cancelled", "remote_outcome_unknown")
-
-INVENTORY_FIELDS = {
-    "runs": ("run_id", "case_id", "header_sha256", "created_at", "lease_until", "status", "cancel_requested_at", "finished_at", "failure_code"),
-    "calls": ("run_id", "call_id", "terminal"),
-    "actions": ("run_id", "call_id", "item_id", "kind"),
-    "pages": ("run_id", "source_id", "page_sha256"),
-    "results": ("run_id", "result_sha256", "completed_at"),
-    "acceptances": ("assessment_id", "run_id", "packet_sha256", "actor", "confirmed_at"),
-}
-
-
-TABLES = {
-    "lifecycle_web_installation": """CREATE TABLE lifecycle_web_installation (
-        singleton INTEGER PRIMARY KEY CHECK(singleton=1), version INTEGER NOT NULL CHECK(version=1),
-        schema_sha256 TEXT NOT NULL, installed_at TEXT NOT NULL)""",
-    "lifecycle_web_runs": """CREATE TABLE lifecycle_web_runs (
-        run_id TEXT PRIMARY KEY, case_id TEXT NOT NULL REFERENCES security_lifecycle_cases(case_id),
-        request_key TEXT NOT NULL UNIQUE, header_json TEXT NOT NULL, header_sha256 TEXT NOT NULL CHECK(length(header_sha256)=64),
-        owner TEXT NOT NULL, created_at TEXT NOT NULL, lease_until TEXT NOT NULL,
-        status TEXT NOT NULL CHECK(status IN ('queued','searching','reading_sources','analyzing','succeeded','failed','cancelled','remote_outcome_unknown')),
-        cancel_requested_at TEXT, finished_at TEXT, failure_code TEXT,
-        CHECK((status IN ('queued','searching','reading_sources','analyzing') AND finished_at IS NULL AND failure_code IS NULL)
-           OR (status='succeeded' AND finished_at IS NOT NULL AND failure_code IS NULL)
-           OR (status IN ('failed','cancelled','remote_outcome_unknown') AND finished_at IS NOT NULL AND failure_code IS NOT NULL)))""",
-    "lifecycle_web_calls": """CREATE TABLE lifecycle_web_calls (
-        run_id TEXT NOT NULL REFERENCES lifecycle_web_runs(run_id), call_id TEXT NOT NULL CHECK(call_id IN ('search-1','analysis-1')),
-        remote_id TEXT, terminal TEXT CHECK(terminal IS NULL OR terminal IN ('completed','failed','cancelled','interrupted')),
-        PRIMARY KEY(run_id,call_id), UNIQUE(run_id,remote_id), CHECK(terminal IS NULL OR remote_id IS NOT NULL))""",
-    "lifecycle_web_actions": """CREATE TABLE lifecycle_web_actions (
-        run_id TEXT NOT NULL, call_id TEXT NOT NULL, item_id TEXT NOT NULL,
-        kind TEXT NOT NULL CHECK(kind IN ('search','open_page','find_in_page')), PRIMARY KEY(run_id,call_id,item_id),
-        FOREIGN KEY(run_id,call_id) REFERENCES lifecycle_web_calls(run_id,call_id))""",
-    "lifecycle_web_pages": """CREATE TABLE lifecycle_web_pages (
-        run_id TEXT NOT NULL REFERENCES lifecycle_web_runs(run_id), source_id TEXT NOT NULL,
-        page_json TEXT NOT NULL, page_sha256 TEXT NOT NULL CHECK(length(page_sha256)=64), PRIMARY KEY(run_id,source_id))""",
-    "lifecycle_web_results": """CREATE TABLE lifecycle_web_results (
-        run_id TEXT PRIMARY KEY REFERENCES lifecycle_web_runs(run_id), payload_json TEXT NOT NULL,
-        result_sha256 TEXT NOT NULL CHECK(length(result_sha256)=64), completed_at TEXT NOT NULL)""",
-    "lifecycle_web_acceptances": """CREATE TABLE lifecycle_web_acceptances (
-        assessment_id TEXT PRIMARY KEY REFERENCES security_lifecycle_assessments(assessment_id),
-        run_id TEXT NOT NULL UNIQUE REFERENCES lifecycle_web_results(run_id),
-        packet_json TEXT NOT NULL, packet_sha256 TEXT NOT NULL CHECK(length(packet_sha256)=64),
-        actor TEXT NOT NULL CHECK(actor='attended_user'), confirmed_at TEXT NOT NULL)""",
-}
-INDEXES = {"idx_lifecycle_web_active_case": """CREATE UNIQUE INDEX idx_lifecycle_web_active_case
-    ON lifecycle_web_runs(case_id) WHERE status IN ('queued','searching','reading_sources','analyzing')"""}
-TRIGGERS = {
-    f"{name}_{operation.lower()}_immutable": f"""CREATE TRIGGER {name}_{operation.lower()}_immutable BEFORE {operation} ON {name}
-    BEGIN SELECT RAISE(ABORT,'web_immutable_record'); END"""
-    for name in ("lifecycle_web_installation", "lifecycle_web_pages", "lifecycle_web_results", "lifecycle_web_acceptances", "lifecycle_web_actions")
-    for operation in ("UPDATE", "DELETE")
-}
-TRIGGERS["lifecycle_web_runs_identity_immutable"] = """CREATE TRIGGER lifecycle_web_runs_identity_immutable
-    BEFORE UPDATE OF run_id,case_id,request_key,header_json,header_sha256,owner,created_at ON lifecycle_web_runs
-    BEGIN SELECT RAISE(ABORT,'web_immutable_record'); END"""
-TRIGGERS["lifecycle_web_runs_delete_immutable"] = """CREATE TRIGGER lifecycle_web_runs_delete_immutable BEFORE DELETE ON lifecycle_web_runs
-    BEGIN SELECT RAISE(ABORT,'web_immutable_record'); END"""
-TRIGGERS["lifecycle_web_calls_terminal_immutable"] = """CREATE TRIGGER lifecycle_web_calls_terminal_immutable BEFORE UPDATE ON lifecycle_web_calls
-    WHEN OLD.run_id<>NEW.run_id OR OLD.call_id<>NEW.call_id
-      OR (OLD.remote_id IS NOT NULL AND (NEW.remote_id IS NULL OR OLD.remote_id<>NEW.remote_id))
-      OR (OLD.terminal IS NOT NULL AND (NEW.terminal IS NULL OR OLD.terminal<>NEW.terminal))
-    BEGIN SELECT RAISE(ABORT,'web_immutable_record'); END"""
-TRIGGERS["lifecycle_web_calls_delete_immutable"] = """CREATE TRIGGER lifecycle_web_calls_delete_immutable BEFORE DELETE ON lifecycle_web_calls
-    BEGIN SELECT RAISE(ABORT,'web_immutable_record'); END"""
-
-
-def schema_digest():
-    return hashlib.sha256("\n".join(f"{name}:{_normalize_sql(sql)}" for name, sql in sorted({**TABLES, **INDEXES, **TRIGGERS}.items())).encode()).hexdigest()
-
-
-def verify_web_journal(conn):
-    for kind, expected, pattern in (("table", TABLES, "lifecycle_web_%"), ("index", INDEXES, "idx_lifecycle_web_%"),
-                                     ("trigger", TRIGGERS, "lifecycle_web_%")):
-        actual = dict(conn.execute("SELECT name,sql FROM sqlite_master WHERE type=? AND name LIKE ? AND sql IS NOT NULL", (kind, pattern)))
-        if kind == "table" and not actual:
-            raise WebJournalError("web_journal_not_installed")
-        if {name: _normalize_sql(sql) for name, sql in actual.items()} != {name: _normalize_sql(sql) for name, sql in expected.items()}:
-            raise WebJournalError("web_journal_schema_mismatch")
-    row = conn.execute("SELECT version,schema_sha256 FROM lifecycle_web_installation WHERE singleton=1").fetchone()
-    if row is None or tuple(row) != (1, schema_digest()):
-        raise WebJournalError("web_journal_schema_mismatch")
-
-
-def read_web_inventory(conn):
-    """Internal retention metadata; no full pages, model prose or credentials."""
-    installed = bool(conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name LIKE 'lifecycle_web_%'").fetchone())
-    result = {"installed": installed, **{key: [] for key in INVENTORY_FIELDS}}
-    if installed:
-        verify_web_journal(conn)
-        for key, fields in INVENTORY_FIELDS.items():
-            result[key] = [dict(zip(fields, row)) for row in conn.execute(
-                f"SELECT {','.join(fields)} FROM lifecycle_web_{key} ORDER BY rowid")]
-    return result
-
-
-def install_web_journal(conn, *, at):
-    from src.security_lifecycle_provider_snapshot import instant
-    instant(at)
-    if conn.in_transaction:
-        raise WebJournalError("web_installation_transaction_open")
-    conn.execute("PRAGMA foreign_keys=ON")
-    verify_profile_connection(conn)
-    assert_lifecycle_writes_available(conn)
-    if conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name LIKE 'lifecycle_web_%'").fetchone():
-        verify_web_journal(conn)
-        return
-    conn.execute("BEGIN IMMEDIATE")
-    try:
-        _install_on_connection(conn, at=at)
-        conn.commit()
-    except BaseException:
-        conn.rollback()
-        raise
-
-
-def _install_on_connection(conn, *, at):
-    from src.security_lifecycle_provider_snapshot import instant
-    instant(at)
-    if not conn.in_transaction:
-        raise WebJournalError("web_installation_transaction_required")
-    verify_profile_connection(conn)
-    assert_lifecycle_writes_available(conn)
-    for statement in (*TABLES.values(), *INDEXES.values(), *TRIGGERS.values()):
-        conn.execute(statement)
-    conn.execute("INSERT INTO lifecycle_web_installation VALUES (1,1,?,?)", (schema_digest(), at))
-    verify_web_journal(conn)
-    verify_profile_connection(conn)
diff --git a/src/lifecycle_web_store.py b/src/lifecycle_web_store.py
deleted file mode 100644
index e493d85d..00000000
--- a/src/lifecycle_web_store.py
+++ /dev/null
@@ -1,505 +0,0 @@
-"""Durable Web execution, separate from deterministic automation and acceptance."""
-
-from contextlib import contextmanager
-from dataclasses import asdict, dataclass
-from datetime import datetime, timedelta, timezone
-import json
-import math
-from pathlib import Path
-import re
-import sqlite3
-from uuid import uuid4
-
-from src.auth_drivers.lifecycle_web_models import WebModelError
-from src.auth_drivers.lifecycle_web_usage import project_usage_report, token_totals, validate_usage_report
-from src.lifecycle_journal_codec import canonical_json, digest_json
-from src.lifecycle_public_sources import PublicSourcePage, SourceReadLimits, _capture_digest, _page_material_digest, canonical_source_url, validate_source_read_report
-from src.lifecycle_web_schema import RUNNING, TERMINAL, WebJournalError, install_web_journal, verify_web_journal
-from src.security_lifecycle_provider_snapshot import instant
-from src.security_lifecycle_schema import assert_lifecycle_writes_available
-from src.security_lifecycle_web_contract import ExecutionSelection, PublicInvestigationInput, RunControl, validate_selection
-from src.security_lifecycle_web_finding import validate_finding
-from src.lifecycle_source_context import parse_source_context
-
-
-LEASE_SECONDS = 60
-JOURNAL_BUSY_SECONDS = 45
-_MISSING_SOURCE_URLS = object()
-
-
-@dataclass(frozen=True)
-class WebInvestigationOptions:
-    """Decode the existing journal header without importing an orchestrator."""
-
-    max_sources: int
-    max_source_requests: int
-    max_redirects: int
-    max_source_bytes: int
-    source_timeout_seconds: float
-    model_timeout_seconds: float
-    max_search_uses: int
-    output_token_limit: int | None
-    effort: str | None
-    max_decoded_source_bytes: int | None = None
-
-    def __post_init__(self):
-        if (type(self.max_sources) is not int or self.max_sources <= 0
-                or type(self.max_search_uses) is not int or self.max_search_uses <= 0
-                or type(self.model_timeout_seconds) not in (int, float)
-                or not math.isfinite(self.model_timeout_seconds) or self.model_timeout_seconds <= 0):
-            raise ValueError("web_investigation_limits")
-        SourceReadLimits(self.max_source_requests, self.max_redirects, self.max_source_bytes, self.source_timeout_seconds,
-                         self.max_decoded_source_bytes)
-
-
-def _identity(value):
-    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,180}", value):
-        raise WebJournalError("web_identity_invalid")
-    return value
-
-
-def _source_gaps(failures, pages, *, max_sources, urls=_MISSING_SOURCE_URLS):
-    """Join host-observed failures to admitted URLs; legacy URLs stay unknown."""
-    if (type(failures) is not dict
-            or any(not isinstance(key, str) or not re.fullmatch(r"source-[1-9][0-9]*", key)
-                   or not isinstance(reason, str) or not re.fullmatch(r"[a-z_]{1,100}", reason)
-                   for key, reason in failures.items())
-            or set(failures) & set(pages) or len(failures) + len(pages) > max_sources):
-        raise WebJournalError("web_source_gaps_invalid")
-    if urls is not _MISSING_SOURCE_URLS:
-        if type(urls) is not dict or set(urls) != set(failures):
-            raise WebJournalError("web_source_gaps_invalid")
-        try:
-            if any(canonical_source_url(url) != url for url in urls.values()):
-                raise ValueError("url")
-        except (TypeError, ValueError):
-            raise WebJournalError("web_source_gaps_invalid") from None
-    return [{"url": None if urls is _MISSING_SOURCE_URLS else urls[key], "reason": failures[key]}
-            for key in sorted(failures, key=lambda identity: int(identity.split("-")[1]))]
-
-
-@dataclass(frozen=True)
-class ValidatedWebRead:
-    """Request-local source validation; mutable profile decisions are not cached."""
-
-    path: Path
-    run_id: str
-    binding: tuple
-    material: dict
-
-    def on_connection(self, conn, run_id):
-        database = next((row[2] for row in conn.execute("PRAGMA database_list") if row[1] == "main"), None)
-        if (not conn.in_transaction or self.run_id != run_id or not database
-                or Path(database).resolve() != self.path):
-            raise WebJournalError("web_journal_integrity")
-        if LifecycleWebStore._review_binding(conn, run_id) != self.binding:
-            raise WebJournalError("web_journal_integrity")
-        return self.material
-
-
-class LifecycleWebStore:
-    def __init__(self, path, *, clock=None):
-        self.path = Path(path).resolve()
-        self.clock = clock or (lambda: datetime.now(timezone.utc).isoformat())
-
-    def _now(self):
-        return instant(self.clock()).isoformat()
-
-    @contextmanager
-    def connection(self, *, write=False):
-        conn = None
-        try:
-            conn = sqlite3.connect(self.path.as_uri() + ("?mode=rw" if write else "?mode=ro"), uri=True, timeout=JOURNAL_BUSY_SECONDS)
-            conn.row_factory = sqlite3.Row
-            conn.execute("PRAGMA foreign_keys=ON")
-            verify_web_journal(conn)
-            if write:
-                assert_lifecycle_writes_available(conn)
-            conn.execute("BEGIN IMMEDIATE" if write else "BEGIN")
-            yield conn
-            if write:
-                conn.commit()
-        except sqlite3.Error:
-            raise WebJournalError("web_recording_unavailable") from None
-        finally:
-            if conn is not None:
-                conn.close()
-
-    @staticmethod
-    def _row(conn, run_id):
-        row = conn.execute("SELECT * FROM lifecycle_web_runs WHERE run_id=?", (_identity(run_id),)).fetchone()
-        if row is None:
-            raise KeyError(run_id)
-        try:
-            header = json.loads(row["header_json"])
-            if digest_json(header) != row["header_sha256"] or header["case_id"] != row["case_id"] or header["version"] != 1:
-                raise ValueError("binding")
-        except (ValueError, KeyError, TypeError):
-            raise WebJournalError("web_journal_integrity") from None
-        return dict(row), header
-
-    def _owned(self, conn, run_id, owner):
-        row, header = self._row(conn, run_id)
-        if row["owner"] != owner:
-            raise WebJournalError("web_owner_changed")
-        if row["status"] not in RUNNING or instant(row["lease_until"]) <= instant(self._now()):
-            raise WebJournalError("web_run_not_running")
-        return row, header
-
-    def start(self, *, case_id, observation_sha256, request, selection, options, owner, request_key, credential_generation=None):
-        _identity(owner)
-        _identity(request_key)
-        _identity(case_id)
-        if not isinstance(observation_sha256, str) or not re.fullmatch("[0-9a-f]{64}", observation_sha256):
-            raise WebJournalError("web_identity_invalid")
-        request = PublicInvestigationInput.model_validate(request.model_dump())
-        selection = validate_selection(**asdict(selection))
-        options.__post_init__()
-        if credential_generation is not None and not re.fullmatch("[0-9a-f]{64}", credential_generation):
-            raise WebJournalError("web_identity_invalid")
-        header = {"version": 1, "case_id": case_id, "observation_sha256": observation_sha256,
-                  "request": request.model_dump(), "selection": asdict(selection), "options": asdict(options),
-                  "credential_generation": credential_generation}
-        at = self._now()
-        with self.connection(write=True) as conn:
-            existing = conn.execute("SELECT run_id,header_sha256 FROM lifecycle_web_runs WHERE request_key=?", (request_key,)).fetchone()
-            if existing is not None:
-                if existing["header_sha256"] != digest_json(header):
-                    raise WebJournalError("web_request_identity_changed")
-                return {"run_id": existing["run_id"], "created": False}
-            case = conn.execute("SELECT ticker FROM security_lifecycle_cases WHERE case_id=?", (case_id,)).fetchone()
-            if case is None or case["ticker"] != request.ticker:
-                raise WebJournalError("web_case_identity_changed")
-            if conn.execute("SELECT 1 FROM lifecycle_web_runs WHERE case_id=? AND status IN ('queued','searching','reading_sources','analyzing')", (case_id,)).fetchone():
-                raise WebJournalError("web_investigation_running")
-            run_id = "lwr_" + uuid4().hex
-            conn.execute("INSERT INTO lifecycle_web_runs (run_id,case_id,request_key,header_json,header_sha256,owner,created_at,lease_until,status) VALUES (?,?,?,?,?,?,?,?,'queued')",
-                         (run_id, case_id, request_key, canonical_json(header), digest_json(header), owner, at, (instant(at) + timedelta(seconds=LEASE_SECONDS)).isoformat()))
-        return {"run_id": run_id, "created": True}
-
-    def heartbeat(self, run_id, *, owner):
-        with self.connection(write=True) as conn:
-            row, _ = self._owned(conn, run_id, owner)
-            conn.execute("UPDATE lifecycle_web_runs SET lease_until=? WHERE run_id=?", ((instant(self._now()) + timedelta(seconds=LEASE_SECONDS)).isoformat(), run_id))
-            return row["cancel_requested_at"] is not None
-
-    def set_phase(self, run_id, *, owner, phase):
-        if phase not in RUNNING:
-            raise WebJournalError("web_phase_invalid")
-        with self.connection(write=True) as conn:
-            row, _ = self._owned(conn, run_id, owner)
-            if row["cancel_requested_at"] is not None:
-                raise WebJournalError("stop_requested")
-            if RUNNING.index(phase) < RUNNING.index(row["status"]):
-                raise WebJournalError("web_phase_invalid")
-            conn.execute("UPDATE lifecycle_web_runs SET status=? WHERE run_id=?", (phase, run_id))
-
-    def request_cancel(self, run_id):
-        with self.connection(write=True) as conn:
-            row, _ = self._row(conn, run_id)
-            if row["status"] in RUNNING:
-                conn.execute("UPDATE lifecycle_web_runs SET cancel_requested_at=COALESCE(cancel_requested_at,?) WHERE run_id=?", (self._now(), run_id))
-
-    def reserve_call(self, run_id, call_id, *, owner):
-        with self.connection(write=True) as conn:
-            row, _ = self._owned(conn, run_id, owner)
-            if row["cancel_requested_at"] is not None:
-                raise WebJournalError("stop_requested")
-            pending = conn.execute("SELECT call_id,terminal FROM lifecycle_web_calls WHERE run_id=?", (run_id,)).fetchall()
-            if call_id not in {"search-1", "analysis-1"} or any(value["terminal"] != "completed" for value in pending):
-                raise WebJournalError("web_model_work_incomplete")
-            if (call_id == "search-1" and pending) or (call_id == "analysis-1" and [value["call_id"] for value in pending] != ["search-1"]):
-                raise WebJournalError("web_model_work_incomplete")
-            conn.execute("INSERT INTO lifecycle_web_calls (run_id,call_id) VALUES (?,?)", (run_id, call_id))
-
-    def bind_call(self, run_id, call_id, remote_id, *, owner, terminal=None):
-        _identity(remote_id)
-        if terminal not in {None, "completed", "failed", "cancelled", "interrupted"}:
-            raise WebJournalError("web_terminal_invalid")
-        with self.connection(write=True) as conn:
-            self._owned(conn, run_id, owner)
-            result = conn.execute("UPDATE lifecycle_web_calls SET remote_id=?,terminal=COALESCE(?,terminal) WHERE run_id=? AND call_id=?",
-                                  (remote_id, terminal, run_id, call_id))
-            if result.rowcount != 1:
-                raise WebJournalError("web_call_missing")
-
-    def add_action(self, run_id, call_id, item_id, kind, *, owner):
-        _identity(item_id)
-        with self.connection(write=True) as conn:
-            self._owned(conn, run_id, owner)
-            existing = conn.execute("SELECT kind FROM lifecycle_web_actions WHERE run_id=? AND call_id=? AND item_id=?", (run_id, call_id, item_id)).fetchone()
-            if existing is not None:
-                if existing[0] != kind:
-                    raise WebJournalError("web_journal_integrity")
-                return
-            conn.execute("INSERT INTO lifecycle_web_actions VALUES (?,?,?,?)", (run_id, call_id, item_id, kind))
-
-    def add_page(self, run_id, *, owner, source_id, page):
-        if not re.fullmatch(r"source-[1-9][0-9]*", source_id) or not isinstance(page, PublicSourcePage) or _capture_digest(page) != page.capture_sha256:
-            raise WebJournalError("web_source_integrity")
-        material = asdict(page)
-        encoded, digest = canonical_json(material, ensure_ascii=False), _page_material_digest(material)
-        with self.connection(write=True) as conn:
-            row, _ = self._owned(conn, run_id, owner)
-            if row["cancel_requested_at"] is not None:
-                raise WebJournalError("stop_requested")
-            conn.execute("INSERT INTO lifecycle_web_pages VALUES (?,?,?,?)",
-                         (run_id, source_id, encoded, digest))
-
-    @staticmethod
-    def _decode_page(row):
-        material = json.loads(row["page_json"])
-        if _page_material_digest(material) != row["page_sha256"]:
-            raise WebJournalError("web_journal_integrity")
-        material["redirect_chain"] = tuple(material["redirect_chain"])
-        page = PublicSourcePage(**material)
-        if _capture_digest(page) != page.capture_sha256:
-            raise WebJournalError("web_journal_integrity")
-        return page
-
-    @classmethod
-    def _pages(cls, conn, run_id):
-        pages = {}
-        for source_id, digest in cls._source_index(conn, run_id):
-            saved = conn.execute("SELECT * FROM lifecycle_web_pages WHERE run_id=? AND source_id=?", (run_id, source_id)).fetchone()
-            if saved is None or saved["page_sha256"] != digest:
-                raise WebJournalError("web_journal_integrity")
-            pages[source_id] = cls._decode_page(saved)
-            del saved
-        return pages
-
-    @staticmethod
-    def _source_index(conn, run_id):
-        return tuple(tuple(item) for item in conn.execute(
-            "SELECT source_id,page_sha256 FROM lifecycle_web_pages WHERE run_id=? ORDER BY source_id", (run_id,)))
-
-    def _read_pages(self, run_id, source_index):
-        pages = {}
-        # Immutable bodies can be decoded outside the owned read transaction.
-        for source_id, digest in source_index:
-            with self.connection() as conn:
-                saved = conn.execute("SELECT * FROM lifecycle_web_pages WHERE run_id=? AND source_id=?", (run_id, source_id)).fetchone()
-            if saved is None or saved["page_sha256"] != digest:
-                raise WebJournalError("web_journal_integrity")
-            pages[source_id] = self._decode_page(saved)
-            del saved
-        return pages
-
-    def _completion_state(self, conn, run_id, owner):
-        row, header = self._owned(conn, run_id, owner)
-        calls = self._calls(conn, run_id)
-        if {key: value["terminal"] for key, value in calls.items()} != {"search-1": "completed", "analysis-1": "completed"}:
-            raise WebJournalError("web_model_work_incomplete")
-        if row["cancel_requested_at"] is not None:
-            raise WebJournalError("stop_requested")
-        return row, header, self._source_index(conn, run_id), calls
-
-    def complete(self, run_id, *, owner, payload, source_failures, usage, source_requests, source_context=None,
-                 source_read_report=None, source_failure_urls=_MISSING_SOURCE_URLS, usage_report=None):
-        from src.auth_drivers.lifecycle_web_models import normalized_usage
-        if type(source_requests) is not int or source_requests < 0:
-            raise WebJournalError("web_result_invalid")
-        with self.connection() as conn:
-            before, header, source_index, calls = self._completion_state(conn, run_id, owner)
-        if usage_report is not None:
-            usage_report, public_usage = self._usage_report(usage_report, calls, "web_result_invalid")
-            if public_usage["totals"] != normalized_usage(usage):
-                raise WebJournalError("web_result_invalid")
-        pages = self._read_pages(run_id, source_index)
-        _source_gaps(source_failures, pages, max_sources=header["options"]["max_sources"], urls=source_failure_urls)
-        finding = validate_finding(PublicInvestigationInput.model_validate(header["request"]), payload, pages,
-                                   unread_source_count=len(source_failures), source_context=source_context)
-        material = {"finding": finding.finding.model_dump(), "source_failures": source_failures,
-                    "source_requests": source_requests, "usage": normalized_usage(usage)}
-        if usage_report is not None:
-            material["usage_report"] = usage_report
-        if source_failure_urls is not _MISSING_SOURCE_URLS:
-            material["source_failure_urls"] = source_failure_urls
-        if source_context is not None:
-            material["source_context"] = source_context
-        if source_read_report is not None:
-            material["source_read_report"] = validate_source_read_report(source_read_report, max_requests=header["options"]["max_source_requests"])
-            if material["source_read_report"]["requests"] != source_requests:
-                raise WebJournalError("web_result_invalid")
-        with self.connection(write=True) as conn:
-            current, _, current_index, current_calls = self._completion_state(conn, run_id, owner)
-            if current_index != source_index or current["header_sha256"] != before["header_sha256"] or current_calls != calls:
-                raise WebJournalError("web_journal_integrity")
-            at = self._now()
-            conn.execute("INSERT INTO lifecycle_web_results VALUES (?,?,?,?)", (run_id, canonical_json(material), digest_json(material), at))
-            conn.execute("UPDATE lifecycle_web_runs SET status='succeeded',finished_at=? WHERE run_id=?", (at, run_id))
-
-    def fail(self, run_id, *, owner, code, control, source_read_report=None, usage_report=None):
-        if not isinstance(code, str) or not re.fullmatch(r"[a-z_]{1,100}", code):
-            code = "web_execution_failed"
-        with self.connection(write=True) as conn:
-            row, header = self._owned(conn, run_id, owner)
-            pending = conn.execute("SELECT 1 FROM lifecycle_web_calls WHERE run_id=? AND terminal IS NULL", (run_id,)).fetchone()
-            status = "remote_outcome_unknown" if pending else "cancelled" if row["cancel_requested_at"] is not None else "failed"
-            material = {}
-            if usage_report is not None:
-                material["usage_report"], _ = self._usage_report(usage_report, self._calls(conn, run_id), "web_result_invalid")
-            if source_read_report is not None:
-                material["failure_source_read_report"] = validate_source_read_report(source_read_report,
-                             max_requests=header["options"]["max_source_requests"])
-            if material:
-                conn.execute("INSERT INTO lifecycle_web_results VALUES (?,?,?,?)", (run_id, canonical_json(material), digest_json(material), self._now()))
-            conn.execute("UPDATE lifecycle_web_runs SET status=?,failure_code=?,finished_at=? WHERE run_id=?", (status, code, self._now(), run_id))
-
-    def recover_expired(self, *, at):
-        at = instant(at).isoformat()
-        with self.connection(write=True) as conn:
-            # Recovery does not parse model/source blobs or traverse predecessor chains.
-            conn.execute("""UPDATE lifecycle_web_runs SET
-                status=CASE WHEN EXISTS(SELECT 1 FROM lifecycle_web_calls c WHERE c.run_id=lifecycle_web_runs.run_id AND c.terminal IS NULL)
-                  THEN 'remote_outcome_unknown' ELSE 'failed' END,
-                failure_code='web_execution_interrupted',finished_at=?
-                WHERE status IN ('queued','searching','reading_sources','analyzing') AND lease_until<=?""", (at, at))
-
-    def control(self, run_id, *, owner):
-        with self.connection() as conn:
-            row, header = self._owned(conn, run_id, owner)
-            if conn.execute("SELECT 1 FROM lifecycle_web_calls WHERE run_id=?", (run_id,)).fetchone():
-                raise WebJournalError("web_execution_not_resumable")
-        return JournalControl(self, run_id, owner, ExecutionSelection(**header["selection"]))
-
-    def read(self, run_id, *, include_running_sources=True):
-        with self.connection() as conn:
-            row, header, calls, saved = self._read_record(conn, run_id)
-            source_index = self._source_index(conn, run_id)
-        pages = (self._read_pages(run_id, source_index)
-                 if include_running_sources or row["status"] not in RUNNING else {})
-        return self._read_material(row, header, calls, saved, pages)
-
-    @classmethod
-    def _review_binding(cls, conn, run_id):
-        row, header, calls, saved = cls._read_record(conn, run_id)
-        # Verified immutable triggers protect the bytes behind each source hash.
-        # A drop/recreate of those triggers changes the schema generation too.
-        return (row, header, calls, None if saved is None else dict(saved),
-                cls._source_index(conn, run_id), conn.execute("PRAGMA schema_version").fetchone()[0])
-
-    def validated_read(self, run_id):
-        from src.lifecycle_investigation.adoption import is_target_run, validated_read
-        if is_target_run(run_id):
-            return validated_read(self.path, run_id)
-        with self.connection() as conn:
-            binding = self._review_binding(conn, run_id)
-        row, header, calls, saved, source_index, _ = binding
-        pages = self._read_pages(run_id, source_index)
-        material = self._read_material(row, header, calls, saved, pages)
-        read = ValidatedWebRead(self.path, run_id, binding, material)
-        with self.connection() as conn:
-            read.on_connection(conn, run_id)
-        return read
-
-    @classmethod
-    def _read_record(cls, conn, run_id):
-        verify_web_journal(conn)
-        row, header = cls._row(conn, run_id)
-        calls = cls._calls(conn, run_id)
-        saved = conn.execute("SELECT * FROM lifecycle_web_results WHERE run_id=?", (run_id,)).fetchone()
-        return row, header, calls, saved
-
-    @staticmethod
-    def _calls(conn, run_id):
-        return {call[0]: {"remote_id": call[1], "terminal": call[2]} for call in conn.execute(
-            "SELECT call_id,remote_id,terminal FROM lifecycle_web_calls WHERE run_id=?", (run_id,))}
-
-    @staticmethod
-    def _usage_report(value, calls, code):
-        try:
-            report = validate_usage_report(value, calls)
-            return report, project_usage_report(report, calls)
-        except WebModelError:
-            raise WebJournalError(code) from None
-
-    @classmethod
-    def read_on_connection(cls, conn, run_id, *, include_running_sources=True, validated=None):
-        from src.lifecycle_investigation.adoption import is_target_run, read_on_connection
-        if is_target_run(run_id):
-            return read_on_connection(conn, run_id, validated=validated)
-        if validated is not None:
-            if type(validated) is not ValidatedWebRead:
-                raise WebJournalError("web_journal_integrity")
-            return validated.on_connection(conn, run_id)
-        row, header, calls, saved = cls._read_record(conn, run_id)
-        pages = (cls._pages(conn, run_id)
-                 if include_running_sources or row["status"] not in RUNNING else {})
-        return cls._read_material(row, header, calls, saved, pages)
-
-    @staticmethod
-    def _read_material(row, header, calls, saved, pages):
-        result = {**row, "request": PublicInvestigationInput.model_validate(header["request"]),
-                  "selection": ExecutionSelection(**header["selection"]), "options": WebInvestigationOptions(**header["options"]),
-                  "observation_sha256": header["observation_sha256"], "finding": None,
-                  "credential_generation": header.get("credential_generation"),
-                  "calls": calls, "pages": pages}
-        if saved is not None:
-            value = json.loads(saved["payload_json"])
-            if type(value) is not dict or digest_json(value) != saved["result_sha256"]:
-                raise WebJournalError("web_journal_integrity")
-            if "usage_report" in value:
-                _, report = LifecycleWebStore._usage_report(value["usage_report"], calls, "web_journal_integrity")
-                result.update(usage_report=report, usage=report["totals"])
-            if row["status"] != "succeeded":
-                if (row["status"] not in TERMINAL or not value
-                        or set(value) - {"failure_source_read_report", "usage_report"}):
-                    raise WebJournalError("web_journal_integrity")
-                if "failure_source_read_report" in value:
-                    report = validate_source_read_report(value["failure_source_read_report"], max_requests=header["options"]["max_source_requests"])
-                    result.update(source_read_report=report, source_requests=report["requests"])
-                return result
-            try:
-                value["usage"] = token_totals(value.get("usage"))
-            except WebModelError:
-                raise WebJournalError("web_journal_integrity") from None
-            if "usage_report" in value and result["usage"] != value["usage"]:
-                raise WebJournalError("web_journal_integrity")
-            result.update(result_sha256=saved["result_sha256"], usage=value["usage"], source_requests=value["source_requests"], source_failures=value["source_failures"])
-            result["source_gaps"] = _source_gaps(value["source_failures"], pages, max_sources=header["options"]["max_sources"],
-                urls=value.get("source_failure_urls", _MISSING_SOURCE_URLS))
-            if "source_failure_urls" in value:
-                result["source_failure_urls"] = value["source_failure_urls"]
-            if "source_context" in value:
-                parse_source_context(value["source_context"], result["pages"])
-                result["source_context"] = value["source_context"]
-            if "source_read_report" in value:
-                report = validate_source_read_report(value["source_read_report"], max_requests=header["options"]["max_source_requests"])
-                if report["requests"] != result["source_requests"]:
-                    raise WebJournalError("web_journal_integrity")
-                result["source_read_report"] = report
-            result["finding"] = validate_finding(result["request"], value["finding"], result["pages"],
-                                                  unread_source_count=len(value["source_failures"]), source_context=value.get("source_context"))
-        elif row["status"] == "succeeded":
-            raise WebJournalError("web_journal_integrity")
-        return result
-
-
-class JournalControl(RunControl):
-    def __init__(self, store, run_id, owner, selection):
-        super().__init__(selection=selection, max_model_requests=2)
-        self.store, self.run_id, self.owner = store, run_id, owner
-
-    def _record(self, operation, *args, **kwargs):
-        try:
-            operation(self.run_id, *args, owner=self.owner, **kwargs)
-        except BaseException:
-            self.request_stop()
-            raise
-
-    def reserve_model_request(self, call_id):
-        super().reserve_model_request(call_id)
-        self._record(self.store.reserve_call, call_id)
-
-    def bind_remote_id(self, call_id, remote_id):
-        super().bind_remote_id(call_id, remote_id)
-        self._record(self.store.bind_call, call_id, remote_id)
-
-    def observe_terminal(self, call_id, *, response_id, status, selection):
-        super().observe_terminal(call_id, response_id=response_id, status=status, selection=selection)
-        self._record(self.store.bind_call, call_id, response_id, terminal=status)
-
-    def observe_web_action(self, call_id, item_id, kind):
-        super().observe_web_action(call_id, item_id, kind)
-        self._record(self.store.add_action, call_id, item_id, kind)
diff --git a/src/sec_research/__init__.py b/src/sec_research/__init__.py
new file mode 100644
index 00000000..807fb5e2
--- /dev/null
+++ b/src/sec_research/__init__.py
@@ -0,0 +1 @@
+"""SEC research foundation; tool and acquisition workflows are separate owners."""
diff --git a/src/sec_research/config.py b/src/sec_research/config.py
new file mode 100644
index 00000000..bf1daa29
--- /dev/null
+++ b/src/sec_research/config.py
@@ -0,0 +1,47 @@
+"""Typed SEC capture budget over the existing profile settings store."""
+
+from __future__ import annotations
+
+import re
+
+from src.profile_state import ProfileStateStore
+
+
+CAPTURE_BUDGET_KEY = "sec_research.capture_budget_bytes"
+DEFAULT_CAPTURE_BUDGET_BYTES = 100 * 1024**3
+MAX_CAPTURE_BUDGET_BYTES = 2**53 - 1
+_CANONICAL_POSITIVE_INTEGER = re.compile(r"[1-9][0-9]*")
+
+
+def _validate_capture_budget_bytes(value: int) -> int:
+    if type(value) is not int or not 1 <= value <= MAX_CAPTURE_BUDGET_BYTES:
+        raise ValueError(
+            f"{CAPTURE_BUDGET_KEY} must be a positive integer no larger than "
+            f"{MAX_CAPTURE_BUDGET_BYTES}"
+        )
+    return value
+
+
+def get_capture_budget_bytes(store: ProfileStateStore) -> int:
+    """Default only an absent key; never mask or repair persisted corruption."""
+    snapshot = store.get_settings_snapshot((CAPTURE_BUDGET_KEY,))
+    if CAPTURE_BUDGET_KEY not in snapshot:
+        return DEFAULT_CAPTURE_BUDGET_BYTES
+
+    value = snapshot[CAPTURE_BUDGET_KEY]
+    if (
+        not isinstance(value, str)
+        or len(value) > len(str(MAX_CAPTURE_BUDGET_BYTES))
+        or _CANONICAL_POSITIVE_INTEGER.fullmatch(value) is None
+    ):
+        raise ValueError(
+            f"{CAPTURE_BUDGET_KEY} must contain canonical decimal integer text"
+        )
+    return _validate_capture_budget_bytes(int(value))
+
+
+def set_capture_budget_bytes(store: ProfileStateStore, value: int) -> int:
+    """Persist only the validated budget; no scheduling or filesystem effects."""
+    validated = _validate_capture_budget_bytes(value)
+    store.set_setting(CAPTURE_BUDGET_KEY, str(validated))
+    return validated
diff --git a/src/sec_research/paths.py b/src/sec_research/paths.py
new file mode 100644
index 00000000..33623670
--- /dev/null
+++ b/src/sec_research/paths.py
@@ -0,0 +1,70 @@
+"""Market-store-bound capture roots and portable relative object keys."""
+
+from __future__ import annotations
+
+from dataclasses import dataclass
+from pathlib import Path, PurePosixPath, PureWindowsPath
+
+
+@dataclass(frozen=True)
+class SecResearchPaths:
+    market_db_path: Path
+
+    def __post_init__(self) -> None:
+        object.__setattr__(self, "market_db_path", Path(self.market_db_path).resolve())
+
+    @classmethod
+    def resolve(cls) -> SecResearchPaths:
+        from src.market_data_admin import resolve_market_db_path
+
+        return cls.from_market_db(resolve_market_db_path())
+
+    @classmethod
+    def from_market_db(cls, path: str | Path) -> SecResearchPaths:
+        return cls(market_db_path=Path(path))
+
+    @property
+    def capture_root(self) -> Path:
+        path = self.market_db_path
+        return path.parent / (path.name + ".sec-research")
+
+    def object_path(self, key: str) -> Path:
+        """Resolve a portable relative key without creating directories or files.
+
+        Containment is checked at resolution time; future file I/O must also
+        guard against concurrent filesystem changes.
+        """
+        if not isinstance(key, str) or not key:
+            raise ValueError("SEC object key must be a nonempty string")
+
+        relative = PurePosixPath(key)
+        windows = PureWindowsPath(key)
+        if (
+            relative.is_absolute()
+            or windows.drive
+            or windows.root
+            or not relative.parts
+            or relative.as_posix() != key
+            or ".." in relative.parts
+            or any(
+                char in '<>:"\\|?*' or ord(char) < 32 or ord(char) == 127
+                for char in key
+            )
+            or any(
+                part.endswith((".", " ")) or PureWindowsPath(part).is_reserved()
+                for part in relative.parts
+            )
+        ):
+            raise ValueError(
+                "SEC object key must be a portable relative path without traversal"
+            )
+
+        root = self.capture_root
+        try:
+            resolved = root.joinpath(*relative.parts).resolve()
+        except (OSError, RuntimeError) as exc:
+            raise ValueError("SEC object key cannot be resolved safely") from exc
+        # Keep the DB-derived root as the anchor, even if that root is a symlink.
+        if resolved == root or not resolved.is_relative_to(root):
+            raise ValueError("SEC object key escapes the capture root")
+        return resolved
diff --git a/src/security_lifecycle_current.py b/src/security_lifecycle_current.py
index a68959a3..dd8c0ff3 100644
--- a/src/security_lifecycle_current.py
+++ b/src/security_lifecycle_current.py
@@ -256,78 +256,70 @@ def _project(snapshot, manifest, sources, conn):
             "listing": {"state": review["listing_state"], "basis": review["listing_basis"], "ended_on": review["listing_end_date"]},
             "continuation": {"state": review["continuation_state"], "successor_ticker": review["successor_ticker"],
                              "candidate_tickers": list(review["candidate_tickers"])},
             "observed_at": observed_at, "next_check_at": next_check,
             "diagnostics": diagnostics, "next_action": action, "source_checks": _source_checks(check),
             "source_notices": [{"form": case["observation"]["filing_form"], "filed_on": case["observation"]["filing_date"],
                                 "text": case["observation"]["description"] or None, "url": _source_url(case["observation"]["evidence_url"])}
                                for case in members if case["source"] == "sec_edgar" and case.get("observation")],
         })
     active = {ticker for ticker, row in latest.items() if classify_provider_listing(
         ticker=ticker, evidence=row["evidence"], today=instant(snapshot["at"]).date(), provider_codes=row["blockers"]).listing_state == "active"}
     tracked_count = len(sources) if sources is not None else None
     active_count = len(active.intersection(sources)) if sources is not None else None
     return {"version": 1, "as_of": snapshot["at"], "source_context": "unavailable" if sources is None else "available",
             "coverage": {"tracked": tracked_count, "confirmed_active": active_count,
                          "unconfirmed": tracked_count - active_count if tracked_count is not None else None},
             "counts": {"attention": sum(row["bucket"] == "attention" for row in items), "history": sum(row["bucket"] == "history" for row in items)},
             "items": sorted(items, key=lambda row: (row["ticker"], row["review_id"]))}
 
 
-def _read(service, *, at, web_review_id=None):
+def _read(service, *, at):
     at = at if at is not None else datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
     paths = (Path(service.market_db_path), Path(service.profile_db_path))
     try:
         identities = [(path.stat().st_dev, path.stat().st_ino) for path in paths]
         with ExitStack() as stack:
             connections = []
             for path in paths:
                 conn = sqlite3.connect(f"{path.resolve().as_uri()}?mode=ro", uri=True)
                 stack.callback(conn.close)
                 conn.execute("PRAGMA query_only=ON")
                 connections.append(conn)
             versions = [conn.execute("PRAGMA data_version").fetchone()[0] for conn in connections]
             sources = _sources(service.sources_by_ticker())
             snapshot = read_population_snapshot(*paths, at=at)
             manifest = build_population_manifest(snapshot)
             result = _project(snapshot, manifest, sources, connections[1])
-            if web_review_id is not None:
-                from src.lifecycle_web_projection import latest_web_runs
-                from src.lifecycle_web_schema import WebJournalError
-                review = next((row for row in result["items"] if row["review_id"] == web_review_id), None)
-                try:
-                    result["web_runs"] = latest_web_runs(connections[1], review["case_ids"] if review else [], at=at)
-                except WebJournalError:
-                    raise LifecyclePopulationUnavailable("current_web_journal_unavailable") from None
             if (sources != _sources(service.sources_by_ticker())
                     or versions != [conn.execute("PRAGMA data_version").fetchone()[0] for conn in connections]
                     or identities != [(path.stat().st_dev, path.stat().st_ino) for path in paths]):
                 raise LifecyclePopulationUnavailable("current_snapshot_changed")
             return result
     except (OSError, sqlite3.Error):
         raise LifecyclePopulationUnavailable("current_store_unavailable") from None
     except (KeyError, TypeError, ValueError):
         raise LifecyclePopulationUnavailable("current_material_invalid") from None
 
 
 def list_current_reviews(service, *, at=None, view="attention", ticker=None, case_id=None, limit=50, offset=0):
     if view not in {"attention", "history"} or type(limit) is not int or not 1 <= limit <= 200 or type(offset) is not int or offset < 0:
         raise ValueError("current_review_filter")
     if ticker is not None and not isinstance(ticker, str):
         raise ValueError("ticker")
     if case_id is not None and (not isinstance(case_id, str) or not case_id.strip()):
         raise ValueError("case_id")
     result = _read(service, at=at)
     prefix = (ticker or "").strip().upper()
     # Existing case links resolve across both views, independently of the
     # operator's current page. The normal list keeps its selected view/filter.
     rows = [row for row in result["items"] if (case_id in row["case_ids"] if case_id is not None
             else row["bucket"] == view and row["ticker"].startswith(prefix))]
     return {**result, "items": rows[offset:offset + limit], "page": {"offset": offset, "limit": limit, "total": len(rows)}}
 
 
 def get_current_review(service, review_id, *, at=None):
-    result = _read(service, at=at, web_review_id=review_id)
+    result = _read(service, at=at)
     row = next((row for row in result["items"] if row["review_id"] == review_id), None)
     if row is None:
         raise KeyError("current_review_not_found")
-    return {"version": 1, "as_of": result["as_of"], "item": row, "web_runs": result["web_runs"]}
+    return {"version": 1, "as_of": result["as_of"], "item": row}
diff --git a/src/security_lifecycle_population.py b/src/security_lifecycle_population.py
index 2f01b411..ad370fac 100644
--- a/src/security_lifecycle_population.py
+++ b/src/security_lifecycle_population.py
@@ -1,36 +1,35 @@
 """Read-only, digest-bound accounting before lifecycle population changes.
 
 This manifest is an internal dry-run artifact, not action authority or a public
 case DTO. Reading it never approves actions, deletes history, or contacts sources.
 """
 
 from __future__ import annotations
 
 from contextlib import ExitStack
 from datetime import date, timedelta
 import hashlib
 import json
 from pathlib import Path
 import sqlite3
 
-from src.lifecycle_web_schema import INVENTORY_FIELDS, TERMINAL as WEB_TERMINAL, WebJournalError, read_web_inventory
 from src.security_lifecycle import read_market_observations
 from src.security_lifecycle_investigation import (
     LifecycleStoreUnavailable, case_id_for, compose_security_lifecycle_audit, observation_fingerprint,
 )
 from src.security_lifecycle_provider_authority import classify_provider_listing, evidence_dict, validate_provider_material
 from src.security_lifecycle_provider_snapshot import canonical_json, decode_snapshot, instant
 from src.security_lifecycle_schema import (
     LifecycleSchemaMismatch, MARKET_TABLE_SQL, PROFILE_TABLE_SQL,
     verify_market_connection, verify_profile_connection,
 )
 from src.ticker_identity_schema import (
     IDENTITY_TABLE_SQL, TickerIdentitySchemaMismatch, identity_schema_present,
     verify_ticker_identity_connection,
 )
 
 
 POLICY_VERSION = "lifecycle_population_v1"
 _PREFIX = "security_lifecycle_"
 
 
@@ -56,41 +55,40 @@ def _rows(conn, tables):
 
 
 def _schema(conn, tables):
     names = sorted(tables)
     placeholders = ",".join("?" for _ in names)
     return [dict(row) for row in conn.execute(
         f"SELECT type,name,tbl_name,sql FROM sqlite_master WHERE tbl_name IN ({placeholders}) ORDER BY type,name",
         names,
     )]
 
 
 def _capture(market, profile, market_conn, profile_conn):
     identity_tables = {}
     if identity_schema_present(profile_conn):
         verify_ticker_identity_connection(profile_conn)
         identity_tables = _rows(profile_conn, IDENTITY_TABLE_SQL)
     return {
         "market_observations": read_market_observations(str(market), limit=None),
         "profile_tables": _rows(profile_conn, PROFILE_TABLE_SQL),
         "identity_tables": identity_tables,
-        "web_journal_inventory": read_web_inventory(profile_conn),
         "composed_cases": compose_security_lifecycle_audit(str(market), str(profile))["cases"],
         "schemas": {
             "market": _schema(market_conn, MARKET_TABLE_SQL),
             "profile": _schema(profile_conn, (*PROFILE_TABLE_SQL, *identity_tables)),
         },
     }
 
 
 def read_population_snapshot(market_db_path, profile_db_path, *, at: str) -> dict:
     """Capture stable read bounds without holding a transaction across stores.
 
     Monitors remain in autocommit: a transaction would pin their data_version.
     Any committed concurrent change invalidates the capture, including WAL writes.
     Writers are not paused, and a failed capture is never retried implicitly.
     """
     try:
         canonical_at = instant(at).isoformat(timespec="seconds").replace("+00:00", "Z")
     except (ValueError, TypeError):
         raise LifecyclePopulationUnavailable("population_time_invalid") from None
     paths = (Path(market_db_path), Path(profile_db_path))
@@ -98,41 +96,41 @@ def read_population_snapshot(market_db_path, profile_db_path, *, at: str) -> dic
         if not all(path.is_file() for path in paths):
             raise LifecyclePopulationUnavailable("population_store_unavailable")
         identities = tuple(_identity(path) for path in paths)
         if identities[0] == identities[1]:
             raise LifecyclePopulationUnavailable("population_store_identity_invalid")
         with ExitStack() as stack:
             connections = []
             for path in paths:
                 conn = sqlite3.connect(f"{path.resolve().as_uri()}?mode=ro", uri=True)
                 stack.callback(conn.close)
                 conn.row_factory = sqlite3.Row
                 conn.execute("PRAGMA query_only=ON")
                 connections.append(conn)
             versions = tuple(conn.execute("PRAGMA data_version").fetchone()[0] for conn in connections)
             verify_market_connection(connections[0])
             verify_profile_connection(connections[1])
             material = _capture(*paths, *connections)
             after = tuple(conn.execute("PRAGMA data_version").fetchone()[0] for conn in connections)
             if versions != after or identities != tuple(_identity(path) for path in paths):
                 raise LifecyclePopulationUnavailable("population_snapshot_changed")
-    except (LifecycleSchemaMismatch, TickerIdentitySchemaMismatch, WebJournalError):
+    except (LifecycleSchemaMismatch, TickerIdentitySchemaMismatch):
         raise LifecyclePopulationUnavailable("population_schema_invalid") from None
     except (OSError, sqlite3.Error, LifecycleStoreUnavailable):
         raise LifecyclePopulationUnavailable("population_store_unavailable") from None
     except (TypeError, ValueError, KeyError):
         raise LifecyclePopulationUnavailable("population_material_invalid") from None
     unsigned = {"version": 1, "at": canonical_at, "material": material}
     return {**unsigned, "sha256": _digest(unsigned)}
 
 
 def _key(row):
     return row["source"], row["source_ref"], row["ticker"]
 
 
 def _case_id(row):
     return case_id_for(*_key(row))
 
 
 def _reconcile(observations, cases, *, source):
     observed = {_key(row) for row in observations if row["source"] == source}
     persisted = {_key(row) for row in cases if row["source"] == source}
@@ -449,64 +447,41 @@ def _dispositions(reviews, transitions, latest, *, today):
             review["bucket"] = "current"
             review["reason"] = ("action_needs_review" if current["status"] == "needs_review" else
                                 "action_scheduled" if date.fromisoformat(current["execute_on"]) > today else "action_pending")
         elif applied:
             _retain_applied_listing(review, latest, today=today)
             if review["listing_state"] == "active":
                 review.update(bucket="current", reason="listing_reappeared_after_action")
             elif review["listing_state"] == "unresolved":
                 review.update(bucket="current", reason="listing_recheck_required")
             elif current["kind"] == "terminal_delisting":
                 if review["continuation_state"] == "not_observed":
                     review.update(bucket="history", reason="removal_applied")
                 else:
                     review.update(bucket="current", reason="continuation_followup_pending")
             elif review["continuation_state"] == "confirmed" and review["successor_ticker"] == current["successor_ticker"]:
                 review.update(bucket="history", reason="symbol_change_applied")
             else:
                 review.update(bucket="current", reason="continuation_followup_pending")
 
 
-def _web_retention(value, *, tables, assessments):
-    if value is None:
-        return {"installed": False, **{key: [] for key in INVENTORY_FIELDS}}
-    if (not isinstance(value, dict) or set(value) != {"installed", *INVENTORY_FIELDS} or type(value["installed"]) is not bool
-            or any(not isinstance(value[key], list) or any(not isinstance(row, dict) or set(row) != set(fields) for row in value[key])
-                   for key, fields in INVENTORY_FIELDS.items()) or (not value["installed"] and any(value[key] for key in INVENTORY_FIELDS))):
-        raise LifecyclePopulationUnavailable("population_web_dependency_invalid")
-    runs = {row["run_id"]: row for row in value["runs"]}
-    cases = {row["case_id"] for row in tables[_PREFIX + "cases"]}
-    results = {row["run_id"] for row in value["results"]}
-    calls = {(row["run_id"], row["call_id"]) for row in value["calls"]}
-    if (len(runs) != len(value["runs"]) or any(row["case_id"] not in cases for row in runs.values())
-            or any(row["run_id"] not in runs for key in INVENTORY_FIELDS if key != "runs" for row in value[key])
-            or any((row["run_id"], row["call_id"]) not in calls for row in value["actions"])
-            or any((row["status"] == "succeeded" and row["run_id"] not in results)
-                   or (row["run_id"] in results and row["status"] not in WEB_TERMINAL) for row in runs.values())
-            or any(row["assessment_id"] not in assessments or row["run_id"] not in results
-                   or runs[row["run_id"]]["status"] != "succeeded"
-                   or assessments[row["assessment_id"]]["case_id"] != runs[row["run_id"]]["case_id"] for row in value["acceptances"])):
-        raise LifecyclePopulationUnavailable("population_web_dependency_invalid")
-    return value
-
-
-def _retention(tables, identity_tables, web_inventory=None):
+def _retention(tables, identity_tables):
     def rows(name):
         return tables[_PREFIX + name]
     assessments = {row["assessment_id"]: row for row in rows("assessments")}
     evidence = {row["evidence_id"]: row for row in rows("evidence")}
     dependencies = []
     fact_dependencies, translation_dependencies = [], []
     referenced = set()
     for row in rows("assessment_evidence"):
         assessment = assessments.get(row["assessment_id"])
         if assessment is None:
             raise LifecyclePopulationUnavailable("population_dependency_invalid")
         evidence_id = row["evidence_id"]
         if evidence_id is not None:
             target = evidence.get(evidence_id)
             if target is None or target["case_id"] != assessment["case_id"] or target["content_sha256"] != row["cited_content_sha256"]:
                 raise LifecyclePopulationUnavailable("population_dependency_invalid")
             referenced.add(evidence_id)
         dependencies.append({
             "assessment_id": row["assessment_id"], "case_id": assessment["case_id"],
             "reference_kind": row["reference_kind"], "evidence_id": evidence_id,
@@ -517,60 +492,58 @@ def _retention(tables, identity_tables, web_inventory=None):
         if target is None or target["case_id"] != row["case_id"] or target["automation_run_id"] != row["automation_run_id"]:
             raise LifecyclePopulationUnavailable("population_dependency_invalid")
         referenced.add(row["evidence_id"])
         fact_dependencies.append({key: row[key] for key in ("fact_id", "case_id", "evidence_id", "automation_run_id")})
     for row in rows("evidence_translations"):
         target = evidence.get(row["evidence_id"])
         if target is None or target["content_sha256"] != row["evidence_content_sha256"]:
             raise LifecyclePopulationUnavailable("population_dependency_invalid")
         referenced.add(row["evidence_id"])
         translation_dependencies.append({"evidence_id": row["evidence_id"], "content_sha256": row["evidence_content_sha256"], "locale": row["locale"]})
     transitions = _transition_inventory(tables, identity_tables, assessments)
     return {
         "assessment_ids": sorted(assessments), "evidence_ids": sorted(evidence),
         "referenced_evidence_ids": sorted(referenced),
         "unreferenced_evidence_ids": sorted(set(evidence) - referenced),
         "assessment_dependencies": dependencies,
         "fact_dependencies": fact_dependencies, "translation_dependencies": translation_dependencies,
         "proposal_ids": sorted(row["proposal_id"] for row in rows("action_proposals")),
         "transition_ids": sorted(row["transition_id"] for row in transitions),
         "transitions": transitions,
-        "web_journal": _web_retention(web_inventory, tables=tables, assessments=assessments),
         "table_counts": {name: len(value) for name, value in sorted({**tables, **identity_tables}.items())},
         "deletion_candidates": [],
     }
 
 
 def build_population_manifest(snapshot: dict) -> dict:
     """Pure classification of a sealed local capture; never an execution plan."""
     try:
         if (set(snapshot) != {"version", "at", "material", "sha256"}
                 or type(snapshot["version"]) is not int or snapshot["version"] != 1):
             raise LifecyclePopulationUnavailable("population_snapshot_invalid")
         unsigned = {key: snapshot[key] for key in ("version", "at", "material")}
         if snapshot["sha256"] != _digest(unsigned):
             raise LifecyclePopulationUnavailable("population_snapshot_digest")
         material = snapshot["material"]
-        if (not isinstance(material, dict) or set(material) - {"web_journal_inventory"} != {
+        if (not isinstance(material, dict) or set(material) != {
                 "market_observations", "profile_tables", "identity_tables", "composed_cases", "schemas"}
                 or not isinstance(material["schemas"], dict)
-                or ("web_journal_inventory" in material and not isinstance(material["web_journal_inventory"], dict))
                 or set(material["schemas"]) != {"market", "profile"}
                 or any(not isinstance(material[key], list) or any(not isinstance(row, dict) for row in material[key])
                        for key in ("market_observations", "composed_cases"))):
             raise LifecyclePopulationUnavailable("population_material_invalid")
         for key, expected in (("profile_tables", set(PROFILE_TABLE_SQL)), ("identity_tables", set(IDENTITY_TABLE_SQL))):
             rows = material[key]
             if (not isinstance(rows, dict) or (set(rows) != expected and not (key == "identity_tables" and not rows))
                     or any(not isinstance(value, list) or any(not isinstance(row, dict) for row in value) for value in rows.values())):
                 raise LifecyclePopulationUnavailable("population_material_invalid")
         return _build(snapshot)
     except (KeyError, ValueError, TypeError):
         raise LifecyclePopulationUnavailable("population_material_invalid") from None
 
 
 def _build(snapshot):
     material = snapshot["material"]
     tables = material["profile_tables"]
     observations = material["market_observations"]
     cases = tables[_PREFIX + "cases"]
     composed = {row["case_id"]: row for row in material["composed_cases"]}
@@ -586,41 +559,41 @@ def _build(snapshot):
     expected = {_case_id(row) for row in (*observations, *projected)} | {row["case_id"] for row in cases}
     if set(composed) != expected:
         raise LifecyclePopulationUnavailable("population_composition_incomplete")
     sec_diff = _reconcile(observations, cases, source="sec_edgar")
     provider_diff = _reconcile(projected, cases, source="listing_authority")
     provider_diff = {
         "virtual": provider_diff["observation_only"], "persisted": provider_diff["matched"],
         "case_only": provider_diff["case_only"],
     }
     today = instant(snapshot["at"]).date()
     reviews = {case_id: _review(row, _provider_for_case(row, latest), today=today) for case_id, row in composed.items()}
     for ticker, row in sorted(latest.items()):
         case_id = _case_id(row["observation"])
         if case_id in reviews:
             continue
         candidate = _review({"case_id": case_id, **row["observation"], "source_presence": "present"}, row, today=today)
         # Even always-active checks can join an existing, identity-bound review.
         reviews[case_id] = candidate
     review_rows, reviews, coverage = _consolidate(reviews, composed, latest, tables, today=today)
     check_views, coverage = _historical_provider_reviews(history, latest, review_rows, reviews, coverage, today=today)
-    retention = _retention(tables, material["identity_tables"], material.get("web_journal_inventory"))
+    retention = _retention(tables, material["identity_tables"])
     _bind_transition_reviews(retention["transitions"], review_rows, reviews, check_views, composed, history, latest)
     _dispositions(review_rows, retention["transitions"], latest, today=today)
     mappings = []
     for population, rows in (("market_observation", observations), ("profile_case", cases)):
         for row in rows:
             case_id = _case_id(row)
             review = reviews[case_id]
             mappings.append({
                 "population": population, "input_id": str(row["id"]) if population == "market_observation" else case_id,
                 "case_id": case_id, "review_id": review["review_id"],
                 "destination": review["bucket"], "reason": review["reason"],
             })
     for row in history:
         case_id = _case_id(row["observation"])
         review = check_views[row["check_id"]]
         superseded = row["check_id"] != latest[row["ticker"]]["check_id"]
         mappings.append({
             "population": "provider_check", "input_id": row["check_id"], "case_id": case_id,
             "review_id": review["review_id"] if review else None,
             "destination": "history" if superseded else (review["bucket"] if review else "coverage"),
diff --git a/src/security_lifecycle_review.py b/src/security_lifecycle_review.py
index 5b79862b..e3a400a0 100644
--- a/src/security_lifecycle_review.py
+++ b/src/security_lifecycle_review.py
@@ -102,41 +102,41 @@ def _proposal_vetoes(store, *, case, assessment, kind):
             if row["assessment_id"] == assessment["assessment_id"] and row["source_ticker"] == case["ticker"]]
     fingerprint = assessment_fingerprint(assessment)
     if any(row["status"] == "proposed" and row["assessment_fingerprint_sha256"] != fingerprint for row in rows):
         return ("stale_assessment",)
     required_action = "notify" if kind == "terminal_delisting" else "remap_symbol"
     replacement = None if kind == "terminal_delisting" else assessment["successor_ticker"]
     required = [row for row in rows if row["action_type"] == required_action and row["replacement_ticker"] == replacement]
     # Missing recommendations are staged on confirmation; an existing dismissal
     # must not look available now and then fail only after the user confirms.
     if required and not any(row["status"] == "proposed" and row["block_reason"] is None for row in required):
         return ("proposal_missing" if kind == "terminal_delisting" else "remap_proposal_missing",)
     return ()
 
 
 def prepare_on_connection(service, conn, *, case_id, assessment_id, options, web_read=None):
     store = SecurityLifecycleInvestigationStore(conn)
     case = store.get_case_identity(case_id)
     assessment = store.get_assessment(assessment_id)
     if assessment["case_id"] != case_id:
         raise ValueError("assessment_case_mismatch")
-    from src.lifecycle_web_review import acceptance_for, prepare_on_connection as prepare_web
+    from src.lifecycle_investigation.review import acceptance_for, prepare_on_connection as prepare_web
     adoption = acceptance_for(conn, assessment_id)
     if adoption is not None:
         return prepare_web(service, conn, run_id=adoption["run_id"], options=options, web_read=web_read)
     at = now(service)
     sources = service._read_service.sources_by_ticker()
     active_sources = None if sources is None else tuple(sources.get(case["ticker"], ()))
     blockers = []
     latest = conn.execute("SELECT assessment_id,revision FROM security_lifecycle_assessments WHERE case_id=? ORDER BY revision DESC LIMIT 1",
                           (case_id,)).fetchone()
     if latest["assessment_id"] != assessment_id:
         blockers.append("assessment_superseded")
     references = _citation_material(store, assessment)
     # Web findings require their own validated persisted provenance. This entry
     # does not promote SEC, manual evidence, or a prior accepted row to that lane.
     check = ProviderCheckStore.latest_for_connection(conn, case["ticker"])
     observation = None if check is None else check["observation"]
     if (case["source"] != "listing_authority" or observation is None
             or case_id_for(observation["source"], observation["source_ref"], observation["ticker"]) != case_id):
         blockers.append("listing_authority_required")
         observation = None
@@ -222,41 +222,41 @@ def confirmation_for(transition):
             or packet.get("effects") != preview.get("effects") or packet.get("execute_on") != transition["execute_on"]
             or profile_snapshot_sha256(preview) != transition["approved_preview_sha256"]):
         raise ValueError("review_confirmation_invalid")
     return value
 
 
 def approved_preview(conn, *, packet, case, assessment, confirmation, at, web_read=None):
     store = SecurityLifecycleInvestigationStore(conn)
     preview = build_transition_preview(conn, case=case, assessment=assessment,
         proposals=store.project_proposals(case["case_id"], observation_fingerprint_sha256=packet["observation_fingerprint_sha256"]),
         observation_fingerprint_sha256=packet["observation_fingerprint_sha256"], sources=packet["active_sources"],
         options=TransitionOptions(**packet["options"]), at=at, web_read=web_read)
     if preview["effects"] != packet["effects"] or preview["profile_state_sha256"] != packet["profile_state_sha256"]:
         raise ValueError("review_changed")
     preview["review_confirmation"] = confirmation
     preview["preview_sha256"] = profile_snapshot_sha256(preview)
     return preview
 
 
 def prepare(service, case_id, *, assessment_id, options):
-    from src.lifecycle_web_review import validated_adoption_read
+    from src.lifecycle_investigation.review import validated_adoption_read
     web_read = validated_adoption_read(service, assessment_id=assessment_id)
     with service._profile_connection(write=False) as conn:
         conn.execute("BEGIN")
         return prepare_on_connection(service, conn, case_id=case_id, assessment_id=assessment_id, options=options, web_read=web_read)[0]
 
 
 def _matching_transition(store, *, case_id, assessment_id, action, packet_sha256, options):
     cursor = store.conn.execute("SELECT transition_id FROM ticker_identity_transitions WHERE case_id=? AND assessment_id=? AND kind=?",
                                 (case_id, assessment_id, action))
     row = cursor.fetchone()
     if row is None:
         return None
     transition = store.get(str(row[0]))
     if "review_confirmation" not in transition["approved_preview"]:
         return None
     confirmation = confirmation_for(transition)
     if confirmation["packet_sha256"] != packet_sha256 or confirmation["packet"]["options"] != asdict(options):
         return None
     return transition
 
@@ -276,78 +276,78 @@ def _result(service, transition_id, *, repeated=False):
             status = ("already_applied" if repeated else "applied") if matches else "applied_state_changed"
         elif status == "approved":
             status = "scheduled" if transition["execute_on"] > service._new_york_date() else "approved"
         elif status == "needs_review":
             row = conn.execute("SELECT block_reasons_json FROM ticker_identity_transition_attempts WHERE transition_id=? ORDER BY rowid DESC LIMIT 1",
                                (transition_id,)).fetchone()
             blockers = json.loads(row[0]) if row else ["review_changed"]
             status = "blocked"
         return {"version": REVIEW_VERSION, "status": status, "transition_id": transition_id,
                 "case_id": transition["case_id"], "packet_sha256": confirmation["packet_sha256"],
                 "action": transition["kind"], "source_ticker": transition["source_ticker"],
                 "successor_ticker": transition["successor_ticker"], "execute_on": transition["execute_on"],
                 "applied_at": transition["applied_at"], "current_effects_match": matches, "block_reasons": blockers}
 
 
 def execute(service, transition_id, *, before_write, trigger="attended_user", web_read=None):
     before_write()
     with service._profile_connection(write=True) as conn:
         store = service._store(conn)
         if web_read is None:
-            from src.lifecycle_web_review import validated_adoption_read
+            from src.lifecycle_investigation.review import validated_adoption_read
             web_read = validated_adoption_read(service, conn=conn, assessment_id=store.get(transition_id)["assessment_id"])
         if web_read is not None:
             before_write()
         conn.execute("BEGIN IMMEDIATE")
         transition = store.get(transition_id)
         confirmation = confirmation_for(transition)
         if transition["status"] != "approved" or transition["execute_on"] > service._new_york_date():
             conn.rollback()
             return _result(service, transition_id, repeated=transition["status"] == "applied")
         try:
             packet, case, assessment = prepare_on_connection(service, conn, case_id=transition["case_id"],
                 assessment_id=transition["assessment_id"], options=TransitionOptions(**confirmation["packet"]["options"]), web_read=web_read)
             current = None
             if packet["ready"] and packet["packet_sha256"] == confirmation["packet_sha256"]:
                 current = approved_preview(conn, packet=packet, case=case, assessment=assessment, confirmation=confirmation, at=now(service), web_read=web_read)
             before_write()
             store.apply(transition_id, current_preview=current, expected_preview_sha256=transition["approved_preview_sha256"],
                         trigger=trigger, _caller_transaction=True, web_read=web_read)
             service._review_step("application_staged")
             before_write()
             conn.commit()
         except BaseException:
             conn.rollback()
             raise
     service._review_step("application_committed")
     return _result(service, transition_id)
 
 
 def confirm(service, case_id, *, assessment_id, packet_sha256, action, options, before_write):
     from src.ticker_identity_service import TickerIdentityConflict
 
     _sha256("review_digest", packet_sha256)
     if action not in {"terminal_delisting", "symbol_continuation"}:
         raise ValueError("review_action")
     before_write()
     with service._profile_connection(write=True) as conn:
-        from src.lifecycle_web_review import validated_adoption_read
+        from src.lifecycle_investigation.review import validated_adoption_read
         web_read = validated_adoption_read(service, conn=conn, assessment_id=assessment_id)
         if web_read is not None:
             before_write()
         conn.execute("BEGIN IMMEDIATE")
         store = service._store(conn)
         try:
             existing = _matching_transition(store, case_id=case_id, assessment_id=assessment_id, action=action,
                                             packet_sha256=packet_sha256, options=options)
             if existing is not None:
                 transition_id = existing["transition_id"]
                 conn.rollback()
             else:
                 packet, case, assessment = prepare_on_connection(service, conn, case_id=case_id, assessment_id=assessment_id, options=options, web_read=web_read)
                 if packet["packet_sha256"] != packet_sha256 or packet["action"] != action:
                     raise TickerIdentityConflict("review_changed")
                 if not packet["ready"]:
                     raise ValueError("review_ineligible")
                 at = now(service)
                 investigation = SecurityLifecycleInvestigationStore(conn)
                 before_write()
diff --git a/src/security_lifecycle_web_contract.py b/src/security_lifecycle_web_contract.py
index 767a8eb5..9e779ca4 100644
--- a/src/security_lifecycle_web_contract.py
+++ b/src/security_lifecycle_web_contract.py
@@ -169,40 +169,45 @@ class RunControl:
         )
         self._max_model_requests = max_model_requests
         self._lock = RLock()
         self._stop_requested = False
         self._calls: dict[str, _Call] = {}
         self._actions: dict[tuple[str, str], str] = {}
 
     @property
     def selection(self) -> ExecutionSelection:
         return self._selection
 
     @property
     def max_model_requests(self) -> int:
         return self._max_model_requests
 
     @property
     def model_requests(self) -> int:
         with self._lock:
             return len(self._calls)
 
+    @property
+    def recorded_model_requests(self) -> int:
+        """Non-journal controls have only their local reservation record."""
+        return self.model_requests
+
     @property
     def all_requests_terminal(self) -> bool:
         with self._lock:
             return all(call.terminal is not None for call in self._calls.values())
 
     @property
     def terminal_statuses(self) -> dict[str, str]:
         with self._lock:
             return {key: call.terminal for key, call in self._calls.items() if call.terminal is not None}
 
     @property
     def stop_state(self) -> str:
         with self._lock:
             if any(call.transport_lost and call.terminal is None for call in self._calls.values()):
                 return "remote_outcome_unknown"
             if self._stop_requested:
                 return "cancelled" if self.all_requests_terminal else "cancelling"
             return "running"
 
     def request_stop(self) -> None:
diff --git a/src/sqlite_backup.py b/src/sqlite_backup.py
new file mode 100644
index 00000000..d04a3165
--- /dev/null
+++ b/src/sqlite_backup.py
@@ -0,0 +1,14 @@
+"""WAL-safe SQLite backups to a new, private destination."""
+
+from contextlib import closing
+import os
+from pathlib import Path
+import sqlite3
+
+
+def backup_connection(conn: sqlite3.Connection, path: Path) -> None:
+    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
+    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
+    os.close(fd)
+    with closing(sqlite3.connect(path)) as destination:
+        conn.backup(destination)
diff --git a/src/ticker_identity_history.py b/src/ticker_identity_history.py
index 761f755d..4ba696b6 100644
--- a/src/ticker_identity_history.py
+++ b/src/ticker_identity_history.py
@@ -1,29 +1,29 @@
 """Read-only explanations bound to a transition, never today's route or findings."""
 
 from datetime import date
 import hashlib
 import json
 from urllib.parse import parse_qsl, urlsplit
 
 from src.lifecycle_public_sources import SourceReadError, canonical_source_url
-from src.lifecycle_web_schema import WebJournalError
+from src.lifecycle_investigation.schema import verify_journal
 from src.lifecycle_journal_codec import digest_json
 from src.security_lifecycle_investigation import (
     SecurityLifecycleInvestigationStore, assessment_fingerprint, observation_fingerprint,
 )
 from src.security_lifecycle_provider_snapshot import decode_snapshot, instant
 from src.security_lifecycle_review import confirmation_for
 from src.ticker_identity_transition import profile_snapshot_sha256
 
 
 _PROVIDERS = {"massive_reference": "Massive", "massive_ticker_events": "Massive",
               "eodhd_symbol_directory": "EODHD", "nasdaq_symbol_directory": "Nasdaq"}
 
 
 def _text(value, *, required=False):
     if value is None and not required:
         return None
     if not isinstance(value, str) or not value.strip() or "\0" in value:
         raise ValueError("history_text")
     return value
 
@@ -115,165 +115,125 @@ def _provider_check(conn, transition, packet):
         return checked
     return None
 
 
 def _bound_json(encoded, digest):
     value = json.loads(encoded)
     if digest_json(value) != digest or not isinstance(value, dict):
         raise ValueError("history_journal_binding")
     return value
 
 
 def _model(value):
     provider, auth = value["provider"], value["auth_mode"]
     if (provider, auth) not in {("openai", "api_key"), ("openai", "chatgpt_oauth"),
                                ("anthropic", "api_key"), ("anthropic", "claude_code_oauth")}:
         raise ValueError("history_execution")
     # A historical model may be retired now. Do not consult today's registry.
     return {"provider": provider, "auth_mode": auth, "model": _text(value["model"], required=True)}
 
 
-def _web_passages(conn, web, citations):
-    # The approval pins SourcePassage digests, including URL and capture time.
-    # Locate the bound quotations inside SQLite without loading full documents
-    # into Python or rerunning today's finding/model validation.
-    passages = []
-    for citation in citations:
-        quote = _text(citation["quote"], required=True)
-        page = conn.execute("""
-            WITH source AS (
-                SELECT page_json,json_extract(page_json,'$.text') AS body
-                FROM lifecycle_web_pages WHERE run_id=? AND source_id=? AND json_valid(page_json)
-            ), located AS (SELECT *,instr(body,?) AS position FROM source)
-            SELECT json_extract(page_json,'$.url') AS source_url,
-                   json_extract(page_json,'$.body_sha256') AS source_document_sha256,
-                   json_extract(page_json,'$.text_sha256') AS source_text_sha256,
-                   json_extract(page_json,'$.retrieved_at') AS retrieved_at,
-                   position,length(CAST(substr(body,1,position-1) AS BLOB)) AS start_byte,
-                   instr(substr(body,position+1),?) AS duplicate_quote
-            FROM located
-            """, (web["run_id"], citation["source_id"], quote, quote)).fetchone()
-        if page is None or page["position"] is None or page["position"] <= 0 or page["duplicate_quote"]:
-            return []
-        passages.append({key: page[key] for key in ("source_url", "source_document_sha256", "source_text_sha256", "retrieved_at", "start_byte")})
-        passages[-1].update(end_byte=page["start_byte"] + len(quote.encode()), excerpt=quote,
-                            cited_text_sha256=hashlib.sha256(quote.encode()).hexdigest())
-    return passages if digest_json(passages) == web["passages_sha256"] else []
-
-
 def _llm(conn, transition, packet, result):
-    target = packet["lane"] == "investigation"
-    if target:
-        from src.lifecycle_investigation.schema import verify_journal
-        verify_journal(conn)
-        jobs, results, calls = "lifecycle_investigation_jobs", "lifecycle_investigation_results", "lifecycle_investigation_calls"
-        result_hash = "payload_sha256"
-    else:
-        from src.lifecycle_web_schema import verify_web_journal
-        verify_web_journal(conn)
-        jobs, results, calls = "lifecycle_web_runs", "lifecycle_web_results", "lifecycle_web_calls"
-        result_hash = "result_sha256"
+    if packet["lane"] != "investigation":
+        raise ValueError("history_journal_binding")
+    verify_journal(conn)
     web = packet["web"]
-    run = conn.execute(f"SELECT header_json,header_sha256,status,finished_at FROM {jobs} WHERE run_id=?", (web["run_id"],)).fetchone()
-    saved = conn.execute(f"SELECT payload_json,{result_hash} FROM {results} WHERE run_id=?", (web["run_id"],)).fetchone()
+    run = conn.execute("SELECT header_json,header_sha256,status,finished_at FROM lifecycle_investigation_jobs WHERE run_id=?", (web["run_id"],)).fetchone()
+    saved = conn.execute("SELECT payload_json,payload_sha256 FROM lifecycle_investigation_results WHERE run_id=?", (web["run_id"],)).fetchone()
     if run is None or saved is None:
         raise ValueError("history_journal_missing")
     header = _bound_json(run["header_json"], web["header_sha256"])
     material = _bound_json(saved["payload_json"], web["result_sha256"])
     selected = _model(header["selection"])
-    completed = conn.execute(f"SELECT terminal,remote_id FROM {calls} WHERE run_id=?", (web["run_id"],)).fetchall()
-    if (run["status"] != "succeeded" or run["header_sha256"] != web["header_sha256"] or saved[result_hash] != web["result_sha256"]
+    completed = conn.execute("SELECT terminal,remote_id FROM lifecycle_investigation_calls WHERE run_id=?", (web["run_id"],)).fetchall()
+    if (run["status"] != "succeeded" or run["header_sha256"] != web["header_sha256"] or saved["payload_sha256"] != web["result_sha256"]
             or selected != _model(web["execution"]) or not completed
             or any(row["terminal"] != "completed" or not row["remote_id"] for row in completed)
             or instant(run["finished_at"]) > instant(transition["approved_at"])):
         raise ValueError("history_execution_binding")
-    finding = material["validated"]["finding"] if target else material["finding"]
+    finding = material["validated"]["finding"]
     if (finding["source_ticker"] != transition["source_ticker"] or finding.get("successor_ticker") != transition["successor_ticker"]
             or finding["effective_date"] != packet["finding"]["effective_date"]):
         raise ValueError("history_finding_binding")
     result.update(method="llm_investigation", model=selected, summary=_text(finding["summary"], required=True),
                   observed_at=_time(run["finished_at"]), limitations=_strings(finding.get("limitations", [])))
-    if target:
-        passages = material["validated"]["passages"]
-        if digest_json(passages) != web["passages_sha256"]:
-            raise ValueError("history_passage_binding")
-        for passage in passages:
-            result["sources"].append(_source(gaps=result["gaps"], name=passage["publisher"], url=passage["url"], title=passage["title"],
-                published_at=passage["published_at"], observed_at=passage["retrieved_at"],
-                kind="document" if passage["corpus"] == "web" else "local_news"))
-    else:
-        for passage in _web_passages(conn, web, finding["citations"]):
-            result["sources"].append(_source(gaps=result["gaps"], url=passage["source_url"], observed_at=passage["retrieved_at"]))
+    passages = material["validated"]["passages"]
+    if digest_json(passages) != web["passages_sha256"]:
+        raise ValueError("history_passage_binding")
+    for passage in passages:
+        result["sources"].append(_source(gaps=result["gaps"], name=passage["publisher"], url=passage["url"], title=passage["title"],
+            published_at=passage["published_at"], observed_at=passage["retrieved_at"],
+            kind="document" if passage["corpus"] == "web" else "local_news"))
     result["source_gaps"] = [{"url": _link(gap["url"], result["gaps"]), "reason": _text(gap["reason"], required=True)}
                              for gap in packet.get("source_gaps", [])]
 
 
 def _empty(transition, gap):
     return {"summary": None, "impact": None, "method": "unknown", "approval_authority": transition["approval_authority"],
             "event_date": None, "observed_at": None, "model": None, "sources": [], "limitations": [], "source_gaps": [], "gaps": [gap]}
 
 
 def project_decision(conn, transition):
     """Missing/corrupt explanatory material cannot erase an applied receipt."""
     try:
         preview = transition["approved_preview"]
         if (not isinstance(preview, dict) or profile_snapshot_sha256(preview) != transition["approved_preview_sha256"]
                 or preview["assessment_id"] != transition["assessment_id"] or preview["case_id"] != transition["case_id"]
                 or preview["source_ticker"] != transition["source_ticker"] or preview["successor_ticker"] != transition["successor_ticker"]):
             raise ValueError("history_approval_binding")
         packet = confirmation_for(transition)["packet"] if "review_confirmation" in preview else None
         store = SecurityLifecycleInvestigationStore(conn)
         if packet is None:
             try:
                 finding = store.get_assessment(transition["assessment_id"])
             except KeyError:
                 return _empty(transition, "assessment_missing")
             if (finding["case_id"] != transition["case_id"] or assessment_fingerprint(finding) != transition["approved_assessment_fingerprint_sha256"]
                     or finding["observation_fingerprint_sha256"] != transition["approved_observation_fingerprint_sha256"]
                     or finding["evidence_set_sha256"] != preview["evidence_set_sha256"]):
                 raise ValueError("history_assessment_binding")
             provenance = finding
         else:
             finding = packet["finding"]
             provenance = packet.get("provenance", {})
         result = {**_empty(transition, ""), "summary": _text(finding["conclusion"], required=True),
                   "impact": _text(finding["impact_summary"], required=True), "event_date": _day(finding["effective_date"]), "gaps": []}
         if packet is None:
             # Legacy fingerprints bind IDs and evidence, not the assessment's
             # prose/date/provenance. Do not imply that those fields were sealed.
             result["gaps"].append("legacy_assessment_unsealed")
-        if packet is not None and packet.get("lane") in {"web", "investigation"}:
+        if packet is not None and (packet.get("lane") == "investigation" or "web" in packet):
             _llm(conn, transition, packet, result)
         else:
             method = provenance.get("automation_method")
             result["method"] = "rule_engine" if method == "deterministic_rule" else "llm_investigation" if method == "model_assisted" else "manual_review"
             if method == "model_assisted":
                 result["gaps"].append("model_missing")
             case = store.get_case_identity(transition["case_id"])
             if case["source"] == "listing_authority":
                 if method is None:
                     result["method"] = "provider_review"
                 checked = _provider_check(conn, transition, packet)
                 if checked is None:
                     result["gaps"].append("sources_missing")
                 else:
                     result["sources"] = [_evidence_source(row, result["gaps"]) for row in checked["evidence"]]
                     result["observed_at"] = _time(checked["at"])
                     result["limitations"] = [_text(checked["observation"]["description"], required=True)]
             references = packet["source_references"] if packet is not None else []
             if packet is None:
                 for citation in finding["citations"]:
                     if citation["reference_kind"] != "evidence":
                         continue
                     row = store.get_evidence(citation["evidence_id"])
                     if (row["case_id"] != transition["case_id"] or row["content_sha256"] != citation["cited_content_sha256"]
                             or hashlib.sha256(row["excerpt"].encode()).hexdigest() != citation["cited_content_sha256"]):
                         raise ValueError("history_citation_binding")
                     references.append(row)
             result["sources"].extend(_evidence_source(row, result["gaps"]) for row in references)
         result["sources"] = list({json.dumps(row, sort_keys=True): row for row in result["sources"]}.values())
         if not result["sources"]:
             result["gaps"].append("sources_missing")
         result["gaps"] = sorted(set(result["gaps"]))
         return result
-    except (KeyError, TypeError, ValueError, WebJournalError):
+    except (KeyError, TypeError, ValueError):
         return _empty(transition, "record_invalid")
diff --git a/src/ticker_identity_transition.py b/src/ticker_identity_transition.py
index c72b3b1b..74886ea8 100644
--- a/src/ticker_identity_transition.py
+++ b/src/ticker_identity_transition.py
@@ -865,42 +865,42 @@ def build_transition_preview(
     if source_ticker is None:
         raise ValueError("source_ticker")
     successor_ticker = _ticker(assessment.get("successor_ticker"))
     outcomes = frozenset(str(value) for value in assessment.get("outcomes") or ())
 
     blockers: list[str] = []
     transition_kind: str | None = None
     from src.sa_tracking_memberships import SaTrackingMembershipStore
     if "symbol_changed" in outcomes and outcomes <= _SYMBOL_OUTCOMES:
         if successor_ticker is None:
             blockers.append("successor_missing")
         elif successor_ticker == source_ticker:
             blockers.append("successor_not_distinct")
         else:
             transition_kind = "symbol_continuation"
     elif outcomes == {"listing_ended"} and successor_ticker is None:
         transition_kind = "terminal_delisting"
     else:
         blockers.append("outcome_not_executable")
 
-    from src.lifecycle_web_review import web_transition_guard
-    web_blockers = web_transition_guard(conn, assessment=assessment, observation_sha256=observation_fingerprint,
+    from src.lifecycle_investigation.review import investigation_transition_guard
+    web_blockers = investigation_transition_guard(conn, assessment=assessment, observation_sha256=observation_fingerprint,
         transition_kind=transition_kind, successor_ticker=successor_ticker, at=at or _utc_now(), web_read=web_read)
     if web_blockers is not None:
         blockers.extend(web_blockers)
     elif SaTrackingMembershipStore.installed(conn) and case.get("source") != "listing_authority":
         blockers.append("listing_authority_required")
     elif SaTrackingMembershipStore.installed(conn) and transition_kind is not None:
         from src.security_lifecycle_provider_authority import provider_transition_guard
         blockers.extend(provider_transition_guard(conn, ticker=source_ticker, observation_fingerprint_sha256=observation_fingerprint,
             transition_kind=transition_kind, successor_ticker=successor_ticker, effective_date=assessment.get("effective_date"),
             at=at or _utc_now(), human_accepted=assessment.get("acceptance_authority") == "human"))
 
     if str(assessment.get("case_id") or "") != case_id:
         blockers.append("assessment_case_mismatch")
     if assessment.get("status") != "accepted":
         blockers.append("assessment_not_accepted")
     if assessment.get("relevance") != "direct_tracked_security":
         blockers.append("assessment_not_direct")
     if (
         assessment.get("stale") is True
         or assessment.get("observation_fingerprint_sha256") != observation_fingerprint
@@ -1466,46 +1466,46 @@ class TickerIdentityTransitionStore:
         )
         return activity_id
 
     def _begin(self) -> None:
         if self.conn.in_transaction:
             raise RuntimeError("caller_transaction_open")
         self.conn.execute("BEGIN IMMEDIATE")
 
     def _provider_guard(self, preview, *, at, automation, web_read=None):
         if automation:
             membership_blockers = _automatic_membership_guard(
                 self.conn,
                 source_ticker=preview["source_ticker"],
                 successor_ticker=preview.get("successor_ticker"),
                 transition_kind=preview["transition_kind"],
             )
             if membership_blockers:
                 return membership_blockers
         from src.sa_tracking_memberships import SaTrackingMembershipStore
         from src.security_lifecycle_provider_authority import provider_transition_guard
-        from src.lifecycle_web_review import acceptance_for, web_transition_guard
+        from src.lifecycle_investigation.review import acceptance_for, investigation_transition_guard
         identity = str(preview.get("assessment_id") or "")
         if identity.startswith("sla_web_") or acceptance_for(self.conn, identity) is not None:
             from src.security_lifecycle_investigation import SecurityLifecycleInvestigationStore
             assessment = SecurityLifecycleInvestigationStore(self.conn).get_assessment(identity)
-            return web_transition_guard(self.conn, assessment=assessment,
+            return investigation_transition_guard(self.conn, assessment=assessment,
                 observation_sha256=preview["observation_fingerprint_sha256"], transition_kind=preview["transition_kind"],
                 successor_ticker=preview.get("successor_ticker"), at=at, automation=automation,
                 confirmation=preview.get("review_confirmation"), require_confirmation=True, web_read=web_read)
         if not SaTrackingMembershipStore.installed(self.conn):
             return ()
         authority = self.conn.execute("SELECT c.source,a.acceptance_authority,a.effective_date FROM security_lifecycle_cases c "
             "JOIN security_lifecycle_assessments a ON a.case_id=c.case_id WHERE c.case_id=? AND a.assessment_id=?",
             (preview.get("case_id"), preview.get("assessment_id"))).fetchone()
         if authority is None or authority[0] != "listing_authority":
             return ("listing_authority_required",)
         return provider_transition_guard(self.conn, ticker=preview["source_ticker"],
             observation_fingerprint_sha256=preview["observation_fingerprint_sha256"], transition_kind=preview["transition_kind"],
             successor_ticker=preview.get("successor_ticker"), effective_date=authority[2], at=at,
             human_accepted=not automation and authority[1] == "human")
 
     @staticmethod
     def _dedupe_key(preview: Mapping[str, object]) -> str:
         parts = (
             "ticker-identity-transition-v1",
             str(preview.get("case_id") or ""),
diff --git a/tests/test_current_investigation_ownership.py b/tests/test_current_investigation_ownership.py
new file mode 100644
index 00000000..4ffef045
--- /dev/null
+++ b/tests/test_current_investigation_ownership.py
@@ -0,0 +1,157 @@
+"""The current investigation must not retain an abandoned executable journal."""
+
+from pathlib import Path
+import json
+import sqlite3
+import time
+
+import pytest
+
+
+ROOT = Path(__file__).resolve().parents[1]
+
+
+@pytest.mark.parametrize("name", ["store", "review", "projection"])
+def test_abandoned_case_journal_module_is_absent(name):
+    assert not (ROOT / f"src/lifecycle_web_{name}.py").exists()
+
+
+def test_current_review_has_its_own_module():
+    assert (ROOT / "src/lifecycle_investigation/review.py").is_file()
+
+
+@pytest.mark.parametrize("mutation", [None, "request_count", "headers", "credential_url"])
+def test_current_reopened_source_diagnostics_use_the_report_validator(tmp_path, mutation):
+    from src.lifecycle_journal_codec import canonical_json, digest_json
+    from tests.test_lifecycle_investigation_review import context
+
+    c = context(tmp_path)
+    payload = {"url": "https://issuer.example/notice", "http_requests": 1, "observations": [
+        {"request_index": 1, "status": 403, "framing": None, "content_encoding": None,
+         "declared_body_bytes": None, "received_body_bytes": 0, "decoded_body_bytes": 0,
+         "result_code": "source_unavailable"}]}
+    if mutation == "request_count":
+        payload["http_requests"] = True
+    elif mutation == "headers":
+        payload["observations"][0]["headers"] = {"Authorization": "fixture-secret"}
+    elif mutation == "credential_url":
+        payload["url"] = "https://user:fixture-secret@issuer.example/notice"
+    with sqlite3.connect(c["profile"]) as conn:
+        ordinal = conn.execute("SELECT MAX(ordinal)+1 FROM lifecycle_investigation_steps WHERE run_id=?", (c["run_id"],)).fetchone()[0]
+        conn.execute("INSERT INTO lifecycle_investigation_steps VALUES(?,?,?,?,?,?)",
+            (c["run_id"], ordinal, "source_read", canonical_json(payload), digest_json(payload), c["now"][0]))
+    if mutation is None:
+        row = c["investigation"].read(c["run_id"], include_sources=False)
+        assert row["steps"][-1]["payload"] == payload
+    else:
+        with pytest.raises(ValueError, match="^investigation_integrity$"):
+            c["investigation"].read(c["run_id"], include_sources=False)
+
+
+@pytest.mark.parametrize("interruption", ["none", "cancel", "deadline", "recording_failure"])
+def test_completed_reply_interruption_keeps_truthful_readable_usage(tmp_path, monkeypatch, interruption):
+    from src.lifecycle_investigation.agent import run_agent
+    from src.lifecycle_investigation.store import InvestigationStore
+    from tests.lifecycle_investigation_fixtures import controller
+    from tests.test_lifecycle_investigation_agent import choose, completed
+    from tests.test_lifecycle_investigation_findings import payload
+
+    ticks = [0.0]
+
+    async def model(call, credential, control):
+        material = json.loads(call.prompt.split("\nMATERIAL\n")[1])
+        reply = completed(call, control, choose("conclude", finding=payload(material["sources"][0]["passages"])))
+        if interruption == "cancel":
+            service.cancel(control.run_id)
+        elif interruption == "deadline":
+            ticks[0] = binding["runtime"]["deadline_seconds"] + 1
+        return reply
+
+    async def runner(*args, **kwargs):
+        return await run_agent(*args, **kwargs, model=model, monotonic=lambda: ticks[0])
+
+    service, store, loads, binding = controller(tmp_path, runner=runner)
+    original_step = store.step
+
+    def step(*args, **kwargs):
+        if interruption == "recording_failure" and kwargs["kind"] == "model_result":
+            raise ValueError("investigation_recording_unavailable")
+        return original_step(*args, **kwargs)
+
+    monkeypatch.setattr(store, "step", step)
+    try:
+        identity = service.start(binding=binding, request_key="completed-interruption")["run_id"]
+        until = time.monotonic() + 5
+        while service.is_local_running(identity) and time.monotonic() < until:
+            time.sleep(0.01)
+        assert not service.is_local_running(identity)
+        status = {"none": "succeeded", "cancel": "cancelled", "deadline": "incomplete", "recording_failure": "failed"}[interruption]
+        row = InvestigationStore(store.path).read(identity, include_sources=False)
+        assert row["status"] == status
+        assert row["calls"] == [{"call_id": "step-1", "remote_id": "step-1", "terminal": "completed"}]
+        results = [step for step in row["steps"] if step["kind"] == "model_result"]
+        assert len(results) == (0 if interruption == "recording_failure" else 1)
+        stats = row["result"]["stats"]
+        assert stats["model_submissions"] == 1
+        assert (stats["input_tokens"], stats["output_tokens"]) == ((None, None) if interruption == "recording_failure" else (10, 20))
+        assert service.read(identity)["status"] == status
+        assert service.latest("OLD")["run_id"] == identity
+        assert len(loads) == 1 and not row["adopted"]
+    finally:
+        service.close()
+
+
+@pytest.mark.parametrize("interruption", ["none", "cancel_before_reservation", "reservation_failure", "reservation_ack_lost"])
+def test_pre_dispatch_reservation_uses_durable_count_and_preserves_unknown_outcome(tmp_path, monkeypatch, interruption):
+    from src.lifecycle_investigation.agent import run_agent
+    from src.lifecycle_investigation.store import InvestigationStore
+    from tests.lifecycle_investigation_fixtures import controller
+    from tests.test_lifecycle_investigation_agent import choose, completed
+    from tests.test_lifecycle_investigation_findings import payload
+
+    dispatched = []
+
+    async def model(call, credential, control):
+        material = json.loads(call.prompt.split("\nMATERIAL\n")[1])
+        reply = completed(call, control, choose("conclude", finding=payload(material["sources"][0]["passages"])))
+        dispatched.append(call.call_id)
+        return reply
+
+    async def runner(*args, **kwargs):
+        return await run_agent(*args, **kwargs, model=model)
+
+    service, store, loads, binding = controller(tmp_path, runner=runner)
+    original_reserve = store.reserve_call
+
+    def reserve(identity, **kwargs):
+        if interruption == "cancel_before_reservation":
+            store.cancel(identity)
+        elif interruption == "reservation_failure":
+            raise ValueError("investigation_recording_unavailable")
+        original_reserve(identity, **kwargs)
+        if interruption == "reservation_ack_lost":
+            raise ValueError("investigation_recording_unavailable")
+
+    monkeypatch.setattr(store, "reserve_call", reserve)
+    try:
+        identity = service.start(binding=binding, request_key="reservation-interruption")["run_id"]
+        until = time.monotonic() + 5
+        while service.is_local_running(identity) and time.monotonic() < until:
+            time.sleep(0.01)
+        assert not service.is_local_running(identity)
+        status = {"none": "succeeded", "cancel_before_reservation": "cancelled", "reservation_failure": "failed",
+                  "reservation_ack_lost": "remote_outcome_unknown"}[interruption]
+        row = InvestigationStore(store.path).read(identity, include_sources=False)
+        assert row["status"] == status
+        assert len(row["calls"]) == (1 if interruption in {"none", "reservation_ack_lost"} else 0)
+        stats = row["result"]["stats"]
+        assert stats["model_submissions"] == len(row["calls"])
+        tokens = (10, 20) if interruption == "none" else (None, None) if interruption == "reservation_ack_lost" else (0, 0)
+        assert (stats["input_tokens"], stats["output_tokens"]) == tokens
+        assert dispatched == (["step-1"] if interruption == "none" else [])
+        if interruption != "none":
+            assert row["result"]["validated"] is None and not row["adopted"]
+        assert service.read(identity)["status"] == status
+        assert service.latest("OLD")["run_id"] == identity and len(loads) == 1
+    finally:
+        service.close()
diff --git a/tests/test_lifecycle_investigation_adoption_safety.py b/tests/test_lifecycle_investigation_adoption_safety.py
new file mode 100644
index 00000000..bec03066
--- /dev/null
+++ b/tests/test_lifecycle_investigation_adoption_safety.py
@@ -0,0 +1,172 @@
+"""Attended current investigations keep the generic writer's safety contracts."""
+
+from dataclasses import replace
+import json
+import sqlite3
+
+import pytest
+
+from src.profile_state import ProfileStateStore
+from src.ticker_identity_transition import TickerIdentityTransitionStore
+from tests.test_lifecycle_investigation_review import context, prepare, confirm, rows
+
+
+def test_current_review_preparation_never_creates_a_human_assessment_or_tracking_change(tmp_path):
+    c = context(tmp_path)
+    before = rows(c)
+    packet = prepare(c)
+    assert packet["ready"], packet["block_reasons"]
+    assert packet["lane"] == "investigation" and packet["action"] == "terminal_delisting"
+    assert packet["web"]["run_id"] == c["run_id"]
+    assert rows(c) == before
+    assert "OLD" in c["sources"]()
+
+
+@pytest.mark.parametrize("provider,auth", [("openai", "api_key"), ("openai", "chatgpt_oauth"),
+                                          ("anthropic", "api_key"), ("anthropic", "claude_code_oauth")])
+@pytest.mark.parametrize("kind", ["terminal_delisting", "symbol_continuation"])
+def test_current_confirmation_uses_existing_atomic_writer_without_requiring_provider_success(tmp_path, provider, auth, kind):
+    c = context(tmp_path, provider=provider, auth=auth, kind=kind)
+    packet = prepare(c)
+    assert packet["ready"], packet["block_reasons"]
+    result = confirm(c, packet)
+    assert result["status"] == "applied" and result["current_effects_match"] is True
+    assert ("NEW" in c["sources"]()) == (kind == "symbol_continuation")
+    assert "OLD" not in c["sources"]() and "LIVE" in c["sources"]()
+    with sqlite3.connect(c["profile"]) as conn:
+        author, authority = conn.execute("SELECT author,acceptance_authority FROM security_lifecycle_assessments").fetchone()
+        assert (author, authority) == ("human", "human")
+        linked = conn.execute("SELECT run_id,actor,packet_sha256 FROM lifecycle_investigation_acceptances").fetchone()
+        assert linked == (c["run_id"], "attended_user", packet["packet_sha256"])
+        receipt = json.loads(conn.execute("SELECT approved_preview_json FROM ticker_identity_transitions").fetchone()[0])
+        assert receipt["review_confirmation"]["packet"]["web"]["execution"]["auth_mode"] == auth
+        assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_investigation_runs").fetchone()[0] == 0
+    before = rows(c)
+    assert confirm(c, packet)["status"] == "already_applied"
+    assert rows(c) == before
+
+
+@pytest.mark.parametrize("change", ["membership", "new_observation", "future_lease", "open_position"])
+def test_current_confirmation_rejects_changed_material_without_partial_human_adoption(tmp_path, change):
+    c = context(tmp_path)
+    packet = prepare(c)
+    if change == "membership":
+        ProfileStateStore(c["profile"]).import_lists([{"name": "New", "kind": "custom", "tickers": ["OLD"]}])
+    elif change == "new_observation":
+        c["checks"].record(ticker="OLD", at="2026-09-08T01:01:00Z", evidence=(), diagnostics={}, blockers=("massive_unavailable",))
+        c["now"][0] = "2026-09-08T01:01:00Z"
+    elif change == "future_lease":
+        c["now"][0] = "2026-09-12T01:00:00Z"
+    else:
+        # Use the same authoritative open-position source as ordinary review.
+        c["service"]._read_service.sources_by_ticker = lambda: {"OLD": ("manual_lists", "portfolio_open"), "LIVE": ("manual_lists",)}
+    before = rows(c)
+    with pytest.raises((ValueError, RuntimeError), match="review_changed|web_review_ineligible"):
+        confirm(c, packet)
+    assert rows(c) == before and "OLD" in c["sources"]()
+
+
+def test_current_active_otc_veto_is_not_lost_when_other_provider_requests_failed(tmp_path):
+    from src.security_lifecycle_listing_evidence import _evidence
+    from tests.test_security_lifecycle_provider_authority import record
+    c = context(tmp_path)
+    c["checks"].record(ticker="OLD", at=c["now"][0], evidence=[_evidence(record("massive_reference", "active", market="otc"))],
+                       diagnostics={}, blockers=("massive_unavailable",))
+    packet = prepare(c)
+    assert packet["ready"] is False and "web_active_listing_conflict" in packet["block_reasons"]
+    assert "OLD" in c["sources"]()
+
+
+def test_future_current_action_is_scheduled_and_rechecked_before_applying(tmp_path):
+    c = context(tmp_path, future=True)
+    packet = prepare(c)
+    result = confirm(c, packet)
+    assert result["status"] == "scheduled" and "OLD" in c["sources"]()
+    c["now"][0] = "2026-09-09T15:00:00Z"
+    with sqlite3.connect(c["profile"]) as conn:
+        digest = conn.execute("SELECT approved_preview_sha256 FROM ticker_identity_transitions WHERE transition_id=?", (result["transition_id"],)).fetchone()[0]
+    applied = c["service"].execute_transition(result["transition_id"], preview_sha256=digest, before_write=lambda: None)
+    assert applied["status"] == "applied" and "OLD" not in c["sources"]()
+
+
+def test_current_adoption_cannot_survive_an_approval_failure_in_a_partial_transaction(tmp_path, monkeypatch):
+    c = context(tmp_path)
+    packet = prepare(c)
+    before = rows(c)
+    def fail(*args, **kwargs):
+        raise RuntimeError("approval_failed")
+    monkeypatch.setattr(TickerIdentityTransitionStore, "_approve", fail)
+    with pytest.raises(RuntimeError, match="approval_failed"):
+        confirm(c, packet)
+    assert rows(c) == before
+
+
+def test_unrelated_sa_refresh_and_other_ticker_edits_do_not_block_current_review(tmp_path):
+    c = context(tmp_path)
+    packet = prepare(c)
+    ProfileStateStore(c["profile"]).import_lists([{"name": "Other", "kind": "custom", "tickers": ["OTHER"]}])
+    c["tracking"].reconcile(({**c["observed"], "observed_at": "2026-09-08T01:01:00Z"},), at="2026-09-08T01:01:00Z")
+    assert confirm(c, packet)["status"] == "applied"
+    assert set(c["sources"]()) == {"LIVE", "OTHER"}
+
+
+@pytest.mark.parametrize("mutation", ["strip_confirmation", "edit_finding", "automation"])
+def test_central_writer_rejects_forged_current_authority_even_with_recomputed_preview_digest(tmp_path, mutation):
+    from src.ticker_identity_transition import profile_snapshot_sha256
+    c = context(tmp_path, future=True)
+    packet = prepare(c)
+    result = confirm(c, packet)
+    c["now"][0] = "2026-09-09T15:00:00Z"
+    with sqlite3.connect(c["profile"]) as conn:
+        store = TickerIdentityTransitionStore(conn, clock=lambda: c["now"][0])
+        transition = store.get(result["transition_id"])
+        preview = transition["approved_preview"]
+        if mutation == "strip_confirmation":
+            preview.pop("review_confirmation")
+        elif mutation == "edit_finding":
+            conn.execute("UPDATE security_lifecycle_assessments SET effective_date='2026-08-01' WHERE assessment_id=?", (transition["assessment_id"],))
+        preview["preview_sha256"] = profile_snapshot_sha256(preview)
+        blockers = store._provider_guard(preview, at=c["now"][0], automation=mutation == "automation")
+        assert "web_acceptance_required" in blockers or "web_acceptance_invalid" in blockers
+    assert "OLD" in c["sources"]()
+
+
+def test_stale_provider_state_after_current_approval_blocks_the_real_due_writer(tmp_path):
+    from src.security_lifecycle_listing_evidence import _evidence
+    from tests.test_security_lifecycle_provider_authority import record
+    c = context(tmp_path, future=True)
+    packet = prepare(c)
+    result = confirm(c, packet)
+    with sqlite3.connect(c["profile"]) as conn:
+        digest = conn.execute("SELECT approved_preview_sha256 FROM ticker_identity_transitions WHERE transition_id=?", (result["transition_id"],)).fetchone()[0]
+    c["now"][0] = "2026-09-09T15:00:00Z"
+    c["checks"].record(ticker="OLD", at=c["now"][0], evidence=[_evidence(replace(record("massive_reference", "active", market="otc"), retrieved_at=c["now"][0]))], diagnostics={})
+    result = c["service"].execute_transition(result["transition_id"], preview_sha256=digest, before_write=lambda: None)
+    assert result["status"] == "blocked" and "OLD" in c["sources"]()
+
+
+def test_current_applied_receipt_can_reverse_without_erasing_investigation_or_reenrolling_on_sa_refresh(tmp_path):
+    c = context(tmp_path)
+    result = confirm(c, prepare(c))
+    c["tracking"].reconcile(({**c["observed"], "observed_at": "2026-09-08T01:01:00Z"},), at="2026-09-08T01:01:00Z")
+    assert "OLD" not in c["sources"]()
+    reversed_result = c["service"].reverse_transition(result["transition_id"], before_write=lambda: None)
+    assert reversed_result["status"] == "reversed"
+    assert "OLD" in c["sources"]() and c["investigation"].read(c["run_id"])["status"] == "succeeded"
+
+
+def test_current_due_writer_rejects_evidence_added_after_attended_adoption(tmp_path):
+    from src.security_lifecycle_investigation import SecurityLifecycleInvestigationStore
+    c = context(tmp_path, future=True)
+    packet = prepare(c)
+    result = confirm(c, packet)
+    with sqlite3.connect(c["profile"]) as conn:
+        digest = conn.execute("SELECT approved_preview_sha256 FROM ticker_identity_transitions WHERE transition_id=?", (result["transition_id"],)).fetchone()[0]
+        SecurityLifecycleInvestigationStore(conn).add_evidence(case_id=packet["case_id"], run_id=None,
+            kind="manual_text", adapter="manual", excerpt="New contradictory evidence", source_url=None,
+            title=None, publisher=None, domain=None, source_published_at=None, retrieved_at=None,
+            mime_type=None, document_status=None, at=c["now"][0])
+    c["now"][0] = "2026-09-09T15:00:00Z"
+    outcome = c["service"].execute_transition(result["transition_id"], preview_sha256=digest, before_write=lambda: None)
+    assert outcome["status"] == "blocked"
+    assert "OLD" in c["sources"]()
diff --git a/tests/test_lifecycle_investigation_attended_concurrency.py b/tests/test_lifecycle_investigation_attended_concurrency.py
new file mode 100644
index 00000000..f1c9e32d
--- /dev/null
+++ b/tests/test_lifecycle_investigation_attended_concurrency.py
@@ -0,0 +1,295 @@
+"""Current source validation must preserve writer availability and approval binding."""
+
+from contextlib import contextmanager
+import sqlite3
+
+import pytest
+
+from src.lifecycle_investigation import adoption, review, store as journal
+from src.lifecycle_journal_codec import canonical_json, digest_json
+from tests.test_lifecycle_investigation_review import context, prepare, confirm, rows
+from tests.test_ticker_identity_history import damage_saved_rows
+
+
+def observe_source_work(monkeypatch, callback, *, phase="decode"):
+    if phase == "decode":
+        original = journal._decoded
+        def decode(raw, digest):
+            value = original(raw, digest)
+            if isinstance(value, dict) and "text" in value and "text_sha256" in value:
+                callback()
+            return value
+        monkeypatch.setattr(journal, "_decoded", decode)
+    else:
+        original = adoption.validate_finding
+        def validate(*args, **kwargs):
+            callback()
+            return original(*args, **kwargs)
+        monkeypatch.setattr(adoption, "validate_finding", validate)
+
+
+@pytest.mark.parametrize("phase", ["decode", "finding"])
+@pytest.mark.parametrize("command", ["prepare", "confirm", "execute", "generic_prepare", "generic_confirm"])
+@pytest.mark.parametrize("journal_mode", ["DELETE", "WAL"])
+def test_current_source_validation_leaves_profile_writers_available(tmp_path, monkeypatch, command, phase, journal_mode):
+    c = context(tmp_path, future=command not in {"prepare", "confirm"})
+    with sqlite3.connect(c["profile"]) as conn:
+        assert conn.execute(f"PRAGMA journal_mode={journal_mode}").fetchone()[0] == journal_mode.lower()
+        conn.execute("CREATE TABLE test_writer_progress (value INTEGER)")
+        conn.execute("INSERT INTO test_writer_progress VALUES (0)")
+    packet = prepare(c)
+    if command not in {"prepare", "confirm"}:
+        scheduled = confirm(c, packet)
+        assert scheduled["status"] == "scheduled"
+        with sqlite3.connect(c["profile"]) as conn:
+            preview = conn.execute("SELECT approved_preview_sha256 FROM ticker_identity_transitions").fetchone()[0]
+    observations = []
+    def other_writer():
+        with sqlite3.connect(c["profile"], timeout=0) as other:
+            other.execute("UPDATE test_writer_progress SET value=value+1")
+        observations.append("committed")
+    observe_source_work(monkeypatch, other_writer, phase=phase)
+    if command == "prepare":
+        assert prepare(c)["ready"]
+        assert "OLD" in c["sources"]()
+    elif command == "confirm":
+        assert confirm(c, packet)["status"] == "applied"
+        assert "OLD" not in c["sources"]()
+    elif command == "execute":
+        c["now"][0] = "2026-09-09T15:00:00Z"
+        assert c["service"].execute_transition(scheduled["transition_id"], preview_sha256=preview,
+            before_write=lambda: None)["status"] == "applied"
+    elif command == "generic_prepare":
+        current = c["service"].prepare_review(packet["case_id"], assessment_id=packet["assessment_id"], options=c["options"])
+        assert current["packet_sha256"] == packet["packet_sha256"]
+    else:
+        current = c["service"].confirm_review(packet["case_id"], assessment_id=packet["assessment_id"],
+            packet_sha256=packet["packet_sha256"], action=packet["action"], options=c["options"], before_write=lambda: None)
+        assert current["status"] == "scheduled"
+    assert observations == ["committed"]
+    with sqlite3.connect(c["profile"]) as conn:
+        assert conn.execute("SELECT value FROM test_writer_progress").fetchone()[0] == 1
+    assert "LIVE" in c["sources"]()
+
+
+@pytest.mark.parametrize("change", ["source_added", "cancellation_after_trigger_bypass", "result_rewritten", "schema_generation", "model_request_added", "call_added"])
+def test_current_validated_read_rechecks_its_binding_inside_the_transaction(tmp_path, change):
+    c = context(tmp_path)
+    read = adoption.validated_read(c["profile"], c["run_id"])
+    with sqlite3.connect(c["profile"]) as conn:
+        if change == "source_added":
+            material = next(iter(c["investigation"].read(c["run_id"])["sources"].values()))
+            conn.execute("INSERT INTO lifecycle_investigation_sources VALUES (?,?,?,?)",
+                (c["run_id"], "source-2", canonical_json(material), digest_json(material)))
+        elif change == "cancellation_after_trigger_bypass":
+            damage_saved_rows(conn, "lifecycle_investigation_jobs",
+                "UPDATE lifecycle_investigation_jobs SET cancel_requested_at=?", (c["now"][0],))
+        elif change == "model_request_added":
+            ordinal = conn.execute("SELECT MAX(ordinal)+1 FROM lifecycle_investigation_steps").fetchone()[0]
+            material = {"call_id": "unbound", "phase": "analysis", "supplied_passages": []}
+            conn.execute("INSERT INTO lifecycle_investigation_steps VALUES (?,?,?,?,?,?)",
+                (c["run_id"], ordinal, "model_request", canonical_json(material), digest_json(material), c["now"][0]))
+        elif change == "call_added":
+            conn.execute("INSERT INTO lifecycle_investigation_calls (run_id,call_id) VALUES (?,?)", (c["run_id"], "unbound"))
+        elif change == "result_rewritten":
+            damage_saved_rows(conn, "lifecycle_investigation_results", "UPDATE lifecycle_investigation_results SET payload_sha256=?", ("0" * 64,))
+        else:
+            conn.execute("CREATE TABLE unrelated_schema_change (value TEXT)")
+    with c["investigation"].connection(write=True) as conn:
+        with pytest.raises(ValueError, match="^investigation_integrity$"):
+            adoption.read_on_connection(conn, c["run_id"], validated=read)
+        assert conn.in_transaction
+    assert "OLD" in c["sources"]()
+
+
+@pytest.mark.parametrize("when", ["during_validation", "after_validation"])
+def test_current_source_rewrite_with_unchanged_digest_invalidates_verified_read(tmp_path, monkeypatch, when):
+    c = context(tmp_path)
+    changed = []
+    def rewrite():
+        with sqlite3.connect(c["profile"]) as conn:
+            damage_saved_rows(conn, "lifecycle_investigation_sources",
+                "UPDATE lifecycle_investigation_sources SET payload_json='{}'")
+        changed.append(True)
+    if when == "during_validation":
+        observe_source_work(monkeypatch, rewrite, phase="finding")
+        with pytest.raises(ValueError, match="^investigation_integrity$"):
+            adoption.validated_read(c["profile"], c["run_id"])
+    else:
+        read = adoption.validated_read(c["profile"], c["run_id"])
+        rewrite()
+        with c["investigation"].connection(write=True) as conn:
+            with pytest.raises(ValueError, match="^investigation_integrity$"):
+                adoption.read_on_connection(conn, c["run_id"], validated=read)
+    assert changed == [True] and "OLD" in c["sources"]()
+
+
+@pytest.mark.parametrize("wrong", ["profile", "run", "transaction", "unvalidated_dict"])
+def test_current_verified_material_cannot_cross_profile_run_or_transaction(tmp_path, wrong):
+    c = context(tmp_path)
+    read = adoption.validated_read(c["profile"], c["run_id"])
+    path = c["profile"]
+    if wrong == "profile":
+        path = tmp_path / "copied-profile.db"
+        with sqlite3.connect(c["profile"]) as source, sqlite3.connect(path) as target:
+            source.backup(target)
+            target.execute(f"PRAGMA schema_version={read.binding[-1]}")
+    with sqlite3.connect(path) as conn:
+        conn.row_factory = sqlite3.Row
+        if wrong != "transaction":
+            conn.execute("BEGIN IMMEDIATE")
+        if wrong == "profile":
+            assert adoption.binding_on_connection(conn, c["run_id"]) == read.binding
+        with pytest.raises(ValueError, match="^investigation_integrity$"):
+            adoption.read_on_connection(conn, "li_other" if wrong == "run" else c["run_id"],
+                validated=read.material if wrong == "unvalidated_dict" else read)
+        assert conn.in_transaction is (wrong != "transaction")
+
+
+@pytest.mark.parametrize("change", ["membership", "open_position", "observation", "active_otc", "stale"])
+def test_current_prevalidated_sources_do_not_cache_mutable_adoption_authority(tmp_path, monkeypatch, change):
+    from dataclasses import replace
+    from src.portfolio_state import PortfolioStore
+    from src.profile_state import ProfileStateStore
+    from src.security_lifecycle_listing_evidence import _evidence
+    from tests.test_security_lifecycle_provider_authority import record
+    c = context(tmp_path)
+    packet = prepare(c)
+    original, changed = review.validated_read, []
+    def read(path, identity):
+        result = original(path, identity)
+        assert not changed
+        changed.append(True)
+        if change == "membership":
+            ProfileStateStore(c["profile"]).import_lists([{"name": "New", "kind": "custom", "tickers": ["OLD"]}])
+        elif change == "open_position":
+            portfolio = PortfolioStore(c["profile"])
+            account = portfolio.ensure_manual_account()
+            portfolio.upsert_manual_position(account_id=account.id, symbol="OLD", quantity=1)
+        elif change == "observation":
+            c["now"][0] = "2026-09-08T01:01:00Z"
+            c["checks"].record(ticker="OLD", at=c["now"][0], evidence=(), diagnostics={}, blockers=("massive_unavailable",))
+        elif change == "active_otc":
+            c["checks"].record(ticker="OLD", at=c["now"][0], evidence=[_evidence(replace(
+                record("massive_reference", "active", market="otc"), retrieved_at=c["now"][0]))], diagnostics={})
+        else:
+            c["now"][0] = "2026-09-12T01:00:00Z"
+        return result
+    monkeypatch.setattr(review, "validated_read", read)
+    with pytest.raises((ValueError, RuntimeError), match="review_changed|web_review_ineligible"):
+        confirm(c, packet)
+    assert changed == [True] and "OLD" in c["sources"]()
+    with sqlite3.connect(c["profile"]) as conn:
+        for table in ("lifecycle_investigation_acceptances", "security_lifecycle_assessments", "security_lifecycle_cases"):
+            assert conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] == 0
+
+
+def test_current_permission_is_rechecked_after_expensive_validation_before_opening_writer(tmp_path, monkeypatch):
+    c = context(tmp_path)
+    packet = prepare(c)
+    original, verified, permission_checks, opened_writers = review.validated_read, [], [], []
+    connection = c["service"]._profile_connection
+    @contextmanager
+    def profile_connection(*, write):
+        if write:
+            opened_writers.append(True)
+        with connection(write=write) as conn:
+            yield conn
+    def read(path, identity):
+        result = original(path, identity)
+        verified.append(True)
+        return result
+    def before_write():
+        permission_checks.append(bool(verified))
+        if verified:
+            raise PermissionError("permission_revoked_during_validation")
+    monkeypatch.setattr(review, "validated_read", read)
+    monkeypatch.setattr(c["service"], "_profile_connection", profile_connection)
+    before = rows(c)
+    with pytest.raises(PermissionError, match="permission_revoked_during_validation"):
+        confirm(c, packet, before_write=before_write)
+    assert permission_checks == [False, True] and opened_writers == []
+    assert rows(c) == before
+
+
+def test_current_source_validation_is_not_cached_between_user_commands(tmp_path, monkeypatch):
+    c = context(tmp_path)
+    decoded = []
+    observe_source_work(monkeypatch, lambda: decoded.append(True))
+    packet = prepare(c)
+    assert decoded == [True]
+    assert confirm(c, packet)["status"] == "applied"
+    assert decoded == [True, True]
+    assert confirm(c, packet)["status"] == "already_applied"
+    assert decoded == [True, True, True]
+
+
+def test_current_confirmation_rejects_source_added_after_validation(tmp_path, monkeypatch):
+    c = context(tmp_path)
+    packet = prepare(c)
+    original = review.validated_read
+    def read(path, identity):
+        checked = original(path, identity)
+        material = next(iter(checked.material["sources"].values()))
+        with sqlite3.connect(c["profile"]) as conn:
+            conn.execute("INSERT INTO lifecycle_investigation_sources VALUES (?,?,?,?)",
+                (identity, "source-2", canonical_json(material), digest_json(material)))
+        return checked
+    monkeypatch.setattr(review, "validated_read", read)
+    with pytest.raises(ValueError, match="^investigation_integrity$"):
+        confirm(c, packet)
+    assert "OLD" in c["sources"]()
+    with sqlite3.connect(c["profile"]) as conn:
+        assert conn.execute("SELECT COUNT(*) FROM lifecycle_investigation_sources").fetchone()[0] == 2
+        assert conn.execute("SELECT COUNT(*) FROM lifecycle_investigation_acceptances").fetchone()[0] == 0
+        assert conn.execute("SELECT COUNT(*) FROM ticker_identity_transitions").fetchone()[0] == 0
+
+
+def test_current_adoption_prevalidation_never_releases_callers_transaction(tmp_path):
+    c = context(tmp_path, future=True)
+    assert confirm(c, prepare(c))["status"] == "scheduled"
+    with c["investigation"].connection(write=True) as conn:
+        with pytest.raises(RuntimeError, match="^caller_transaction_open$"):
+            review.validated_adoption_read(c["service"], conn=conn, assessment_id=review.assessment_id_for(c["run_id"]))
+        assert conn.in_transaction
+
+
+def test_current_confirmation_does_not_starve_a_real_investigation_worker(tmp_path, monkeypatch):
+    from threading import Event, current_thread
+    from src.auth_drivers.lifecycle_web_models import WebCredential
+    from src.lifecycle_investigation.controller import InvestigationController
+    from src.lifecycle_investigation.news import LocalNews
+    from tests.lifecycle_investigation_fixtures import completed_runner, wait_done
+    c = context(tmp_path)
+    with sqlite3.connect(c["profile"]) as conn:
+        assert conn.execute("PRAGMA journal_mode=DELETE").fetchone()[0] == "delete"
+    packet = prepare(c)
+    binding, _ = c["preflight"]._material("OLD")
+    started, validating, finished = Event(), Event(), Event()
+    original, main_thread = adoption.validate_finding, current_thread()
+    async def runner(*args, **kwargs):
+        started.set()
+        assert validating.wait(3)
+        result = await completed_runner(*args, **kwargs)
+        finished.set()
+        return result
+    service = InvestigationController(c["investigation"],
+        credential_loader=lambda selected: WebCredential(selected, api_key="synthetic", generation=binding["credential_generation"]),
+        news_factory=lambda: LocalNews(tmp_path / "news.db", None, clock=lambda: c["now"][0]),
+        runner=runner, heartbeat_seconds=.02)
+    try:
+        identity = service.start(binding=binding, request_key="other-worker")["run_id"]
+        assert started.wait(3)
+        def validate(*args, **kwargs):
+            if current_thread() is main_thread:
+                validating.set()
+                assert finished.wait(3)
+                assert wait_done(service, identity)["status"] == "succeeded"
+            return original(*args, **kwargs)
+        monkeypatch.setattr(adoption, "validate_finding", validate)
+        assert confirm(c, packet)["status"] == "applied"
+        assert wait_done(service, identity)["status"] == "succeeded"
+        assert "OLD" not in c["sources"]() and "LIVE" in c["sources"]()
+    finally:
+        validating.set()
+        service.close()
diff --git a/tests/test_lifecycle_investigation_gaps.py b/tests/test_lifecycle_investigation_gaps.py
new file mode 100644
index 00000000..0b578c7d
--- /dev/null
+++ b/tests/test_lifecycle_investigation_gaps.py
@@ -0,0 +1,223 @@
+"""Gap disclosure is bound to the real current agent, review, and attended receipt."""
+
+from copy import deepcopy
+import json
+import sqlite3
+
+from fastapi import FastAPI
+from fastapi.testclient import TestClient
+import pytest
+
+from src.lifecycle_investigation import review
+from src.lifecycle_investigation.controller import project_job
+from src.lifecycle_investigation.store import JournalError
+from src.lifecycle_journal_codec import canonical_json, digest_json
+from src.lifecycle_public_sources import PublicSourceReader
+from src.security_lifecycle_review import packet_digest, project_packet
+from src.ticker_identity_transition import TransitionOptions
+from tests.test_lifecycle_investigation_agent import choose, completed
+from tests.test_lifecycle_investigation_findings import payload
+from tests.test_lifecycle_investigation_review import context, prepare, confirm, rows
+from tests.test_lifecycle_public_sources import Response, _reader
+from tests.test_ticker_identity_history import damage_saved_rows
+
+
+URL = "https://issuer.example/supplement"
+GAPS = [{"url": URL, "reason": "source_unavailable"}]
+CHANNELS = [("openai", "api_key"), ("openai", "chatgpt_oauth"),
+            ("anthropic", "api_key"), ("anthropic", "claude_code_oauth")]
+
+
+def gap_context(tmp_path, monkeypatch, *, kind="terminal_delisting", finding_edit=lambda value: value, **kwargs):
+    _, connections, _, _ = _reader(monkeypatch, [Response(status=403, headers={"Set-Cookie": "private-cookie"})])
+    calls = []
+    async def model(call, credential, control):
+        calls.append(call)
+        if len(calls) == 1:
+            return completed(call, control, choose("search_web", query="OLD listing supplement"))
+        if call.phase == "search":
+            return completed(call, control, {"sources": [URL], "unresolved_conditions": []})
+        if len(calls) == 3:
+            return completed(call, control, choose("read_url", url=URL))
+        material = json.loads(call.prompt.split("\nMATERIAL\n")[1])
+        assert material["source_gaps"] == [{**GAPS[0], "corpus": None}]
+        finding = payload(material["sources"][0]["passages"])
+        if kind == "symbol_continuation":
+            finding.update(event_kind="symbol_continuation", successor_ticker="NEW")
+            finding["citations"][-1]["supports"] = ["same_security_continuation", "effective_date"]
+        return completed(call, control, choose("conclude", finding=finding_edit(finding)))
+    c = context(tmp_path, kind=kind, model=model, reader_factory=PublicSourceReader, **kwargs)
+    assert len(connections) == 1 and all(conn.closed for conn in connections)
+    return c
+
+
+@pytest.mark.parametrize("provider,auth", CHANNELS)
+@pytest.mark.parametrize("kind", ["terminal_delisting", "symbol_continuation"])
+def test_current_gap_disclosure_follows_finding_review_and_explicit_receipt(tmp_path, monkeypatch, provider, auth, kind):
+    c = gap_context(tmp_path, monkeypatch, provider=provider, auth=auth, kind=kind)
+    before = rows(c)
+    public = project_job(c["investigation"].read(c["run_id"]), at=c["now"][0])
+    packet = prepare(c)
+    assert packet["ready"] and packet["source_gaps"] == project_packet(packet)["source_gaps"] == GAPS
+    assert public["gaps"] == [{**GAPS[0], "corpus": None}]
+    assert "private-cookie" not in json.dumps(public)
+    assert rows(c) == before and "OLD" in c["sources"]()
+    assert confirm(c, packet, acknowledge_source_gaps=True)["status"] == "applied"
+    assert ("NEW" in c["sources"]()) is (kind == "symbol_continuation")
+    assert "OLD" not in c["sources"]() and "LIVE" in c["sources"]()
+    with sqlite3.connect(c["profile"]) as conn:
+        receipt, actor = conn.execute("SELECT packet_json,actor FROM lifecycle_investigation_acceptances").fetchone()
+        assert actor == "attended_user" and json.loads(receipt)["source_gaps"] == GAPS
+        assert conn.execute("SELECT author,acceptance_authority FROM security_lifecycle_assessments").fetchone() == ("human", "human")
+    after = rows(c)
+    assert confirm(c, packet, acknowledge_source_gaps=True)["status"] == "already_applied"
+    assert rows(c) == after
+
+
+@pytest.mark.parametrize("change", ["omitted", "empty", "reason", "url"])
+def test_current_confirmation_rejects_different_gap_disclosure_without_write(tmp_path, monkeypatch, change):
+    c = gap_context(tmp_path, monkeypatch)
+    packet = prepare(c)
+    if change == "omitted":
+        packet.pop("source_gaps")
+    elif change == "empty":
+        packet["source_gaps"] = []
+    else:
+        packet["source_gaps"][0][change] = "source_read_timeout" if change == "reason" else "https://other.example/notice"
+    packet["packet_sha256"] = packet_digest(packet)
+    before = rows(c)
+    with pytest.raises((ValueError, RuntimeError), match="review_changed"):
+        confirm(c, packet, acknowledge_source_gaps=True)
+    assert rows(c) == before
+
+
+@pytest.mark.parametrize("acknowledgement", [False, None, 1, "true"])
+def test_current_direct_adoption_requires_literal_gap_acknowledgement(tmp_path, monkeypatch, acknowledgement):
+    c = gap_context(tmp_path, monkeypatch)
+    packet = prepare(c)
+    before = rows(c)
+    with pytest.raises(JournalError, match="^web_source_gaps_not_acknowledged$"):
+        confirm(c, packet, acknowledge_source_gaps=acknowledgement)
+    assert rows(c) == before
+
+
+@pytest.mark.parametrize("acknowledgement", ["omitted", False, None, 1, "true"])
+def test_current_confirmation_api_cannot_apply_unacknowledged_gaps(tmp_path, monkeypatch, acknowledgement):
+    from src.api.routes import lifecycle_investigation as api
+    c = gap_context(tmp_path, monkeypatch)
+    app = FastAPI()
+    app.include_router(api.router)
+    app.dependency_overrides[api.get_ticker_identity_service] = lambda: c["service"]
+    monkeypatch.setattr(api, "require_db_write", lambda *args: None)
+    monkeypatch.setattr(api, "require_profile_state_write", lambda *args: None)
+    with TestClient(app) as client:
+        route = f"/security-lifecycle/investigations/runs/{c['run_id']}"
+        packet = client.get(route + "/review").json()
+        assert packet["ready"] and packet["source_gaps"] == GAPS
+        body = {"packet_sha256": packet["packet_sha256"], "action": packet["action"], **packet["options"]}
+        if acknowledgement != "omitted":
+            body["acknowledge_source_gaps"] = acknowledgement
+        before = rows(c)
+        response = client.post(route + "/confirm", json=body)
+        assert response.status_code == (409 if acknowledgement in ("omitted", False) else 422), response.text
+        if acknowledgement in ("omitted", False):
+            assert response.json()["detail"]["code"] == "web_source_gaps_not_acknowledged"
+        assert rows(c) == before
+        accepted = client.post(route + "/confirm", json={**body, "acknowledge_source_gaps": True})
+        assert accepted.status_code == 200 and accepted.json()["status"] == "applied", accepted.text
+
+
+@pytest.mark.parametrize("failed", [False, True])
+def test_current_gap_acknowledgement_never_substitutes_for_completed_finding(tmp_path, failed):
+    from tests.test_lifecycle_investigation_store import running
+    c, store, identity, _ = running(tmp_path)
+    if failed:
+        store.finish(identity, owner="worker", status="failed", failure_code="source_unavailable")
+    before = rows(c)
+    with pytest.raises(ValueError, match="^web_finding_not_complete$"):
+        review.confirm(c["service"], identity, packet_sha256="a" * 64, action="terminal_delisting",
+            options=TransitionOptions(execute_on=None), before_write=lambda: None, acknowledge_source_gaps=True)
+    assert rows(c) == before
+
+
+@pytest.mark.parametrize("change,reason", [
+    ({"contradictions": ["The exchange reports continued trading."]}, "material_contradiction"),
+    ({"unresolved_conditions": ["Trading status remains uncertain."]}, "finding_incomplete"),
+    ({"source_ticker": "OTHER"}, "security_identity_mismatch"),
+    ({"citations": []}, "source_passage_missing"),
+])
+def test_current_disclosed_gap_does_not_override_missing_essential_proof(tmp_path, monkeypatch, change, reason):
+    c = gap_context(tmp_path, monkeypatch, finding_edit=lambda value: {**value, **change}, expected_status="incomplete")
+    row = c["investigation"].read(c["run_id"])
+    assert row["result"]["validated"]["action"] is None
+    assert reason in row["result"]["validated"]["block_reasons"]
+    assert row["result"]["gaps"] == [{**GAPS[0], "corpus": None}]
+    before = rows(c)
+    with pytest.raises(ValueError, match="^web_finding_not_complete$"):
+        review.confirm(c["service"], c["run_id"], packet_sha256="a" * 64, action="terminal_delisting",
+            options=c["options"], before_write=lambda: None, acknowledge_source_gaps=True)
+    assert rows(c) == before and "OLD" in c["sources"]()
+
+
+@pytest.mark.parametrize("strip", [False, True])
+def test_current_writer_rechecks_gap_disclosure_even_when_acceptance_is_resigned(tmp_path, monkeypatch, strip):
+    from src.security_lifecycle_investigation import SecurityLifecycleInvestigationStore
+    from src.ticker_identity_transition import TickerIdentityTransitionStore
+    c = gap_context(tmp_path, monkeypatch, future=True)
+    result = confirm(c, prepare(c), acknowledge_source_gaps=True)
+    read_acceptance = review.acceptance_for
+    def changed(conn, assessment_id):
+        accepted = deepcopy(read_acceptance(conn, assessment_id))
+        packet = accepted["packet"]
+        packet.pop("source_gaps") if strip else packet.update(source_gaps=[])
+        accepted["packet_sha256"] = packet["packet_sha256"] = packet_digest(packet)
+        return accepted
+    with sqlite3.connect(c["profile"]) as conn:
+        store = TickerIdentityTransitionStore(conn, clock=lambda: c["now"][0])
+        preview = store.get(result["transition_id"])["approved_preview"]
+        assert store._provider_guard(preview, at=c["now"][0], automation=False) == ()
+        monkeypatch.setattr(review, "acceptance_for", changed)
+        assessment = SecurityLifecycleInvestigationStore(conn).get_assessment(preview["assessment_id"])
+        blockers = review.investigation_transition_guard(conn, assessment=assessment,
+            observation_sha256=preview["observation_fingerprint_sha256"], transition_kind=preview["transition_kind"],
+            successor_ticker=preview["successor_ticker"], at=c["now"][0])
+        assert "web_acceptance_invalid" in blockers
+    assert "OLD" in c["sources"]()
+
+
+@pytest.mark.parametrize("value", [None, {}, [{"url": "https://user:secret@example.com/private", "reason": "source_unavailable", "corpus": None}],
+    [{"url": URL, "reason": "raw error: private-token", "corpus": None}]])
+def test_current_adoption_rejects_malformed_saved_gaps_even_with_valid_payload_hash(tmp_path, monkeypatch, value):
+    c = gap_context(tmp_path, monkeypatch)
+    with sqlite3.connect(c["profile"]) as conn:
+        saved = json.loads(conn.execute("SELECT payload_json FROM lifecycle_investigation_results").fetchone()[0])
+        saved["gaps"] = value
+        damage_saved_rows(conn, "lifecycle_investigation_results",
+            "UPDATE lifecycle_investigation_results SET payload_json=?,payload_sha256=?", (canonical_json(saved), digest_json(saved)))
+    before = rows(c)
+    with pytest.raises(ValueError, match="investigation_integrity|web_source_gaps_invalid"):
+        prepare(c)
+    assert rows(c) == before and "OLD" in c["sources"]()
+
+
+def test_current_gap_acknowledgement_never_waives_active_provider_evidence(tmp_path, monkeypatch):
+    from tests.test_security_lifecycle_population import active
+    c = gap_context(tmp_path, monkeypatch)
+    packet = prepare(c)
+    c["checks"].record(ticker="OLD", at="2026-09-08T01:00:01Z",
+        evidence=(active("OLD", at="2026-09-08T01:00:01Z"),), diagnostics={})
+    c["now"][0] = "2026-09-08T01:00:02Z"
+    fresh = prepare(c)
+    assert not fresh["ready"] and "web_active_listing_conflict" in fresh["block_reasons"]
+    assert fresh["source_gaps"] == GAPS
+    before = rows(c)
+    with pytest.raises((ValueError, RuntimeError), match="review_changed"):
+        confirm(c, packet, acknowledge_source_gaps=True)
+    assert rows(c) == before and "OLD" in c["sources"]()
+
+
+def test_current_review_has_empty_gaps_without_internal_source_fields(tmp_path):
+    c = context(tmp_path)
+    packet = project_packet(prepare(c))
+    assert packet["source_gaps"] == []
+    assert not {"source_failure_urls", "source_failures", "web"} & set(packet)
diff --git a/tests/test_lifecycle_investigation_retirement.py b/tests/test_lifecycle_investigation_retirement.py
index dd53915e..f7feb88d 100644
--- a/tests/test_lifecycle_investigation_retirement.py
+++ b/tests/test_lifecycle_investigation_retirement.py
@@ -1,28 +1,157 @@
+from contextlib import closing
 import json
 import sqlite3
 
 import pytest
 
 from tests.test_security_lifecycle_population import stores, sec as observe, persist
 
 
+CASED_FK_TARGETS = [
+    pytest.param("profile", "SECURITY_LIFECYCLE_CASES", "case_id", id="profile-upper"),
+    pytest.param("profile", "Security_Lifecycle_Cases", "case_id", id="profile-mixed"),
+    pytest.param("market", "SECURITY_LIFECYCLE_OBSERVATIONS", "id", id="market-upper"),
+    pytest.param("market", "Security_Lifecycle_Observations", "id", id="market-mixed"),
+]
+
+
+def disposal_case(tmp_path):
+    from src.lifecycle_investigation.schema import install_journal
+
+    market, profile = stores(tmp_path)
+    event = observe(market, ticker="OLD", ref="case-sensitive-fk")
+    case = persist(profile, event)
+    with closing(sqlite3.connect(profile)) as conn:
+        install_journal(conn, at="2026-09-08T00:00:00Z")
+    return market, profile, event, case
+
+
+def cascade_child(path, target, column, identity):
+    with closing(sqlite3.connect(path)) as conn:
+        conn.execute("PRAGMA foreign_keys=ON")
+        conn.execute(f'CREATE TABLE independent_receipt(id INTEGER PRIMARY KEY, parent_id REFERENCES "{target}"("{column}") ON DELETE CASCADE, payload TEXT)')
+        conn.execute("INSERT INTO independent_receipt VALUES (1, ?, 'retain')", (identity,))
+        conn.commit()
+        assert not conn.execute("PRAGMA foreign_key_check").fetchall()
+
+
+@pytest.mark.parametrize("stage,target,column", CASED_FK_TARGETS)
+def test_cased_cascade_fk_is_retained_by_preview_and_empty_apply(tmp_path, stage, target, column):
+    from src.lifecycle_investigation.disposal import apply_disposal_stage, preview_disposal
+
+    market, profile, event, case = disposal_case(tmp_path)
+    path, identity = (profile, case) if stage == "profile" else (market, event["id"])
+    cascade_child(path, target, column, identity)
+    plan = preview_disposal(market, profile)
+    assert plan["roots"] == []
+    assert plan["stages"]["profile"] == {}
+    assert plan["stages"]["market"]["observation_ids"] == []
+    assert plan["retained"][0]["reason"] == ("retained_external_dependency" if stage == "profile" else "market_dependency")
+    for name, store in (("profile", profile), ("market", market)):
+        assert apply_disposal_stage(store, plan, stage=name, approval_sha256=plan["approval_sha256"],
+            backup_path=tmp_path / f"{name}-backup", app_stopped=True, profile_path=profile)["status"] == "completed"
+    with closing(sqlite3.connect(path)) as conn:
+        assert conn.execute("SELECT * FROM independent_receipt").fetchall() == [(1, identity, "retain")]
+        assert conn.execute(f'SELECT "{column}" FROM "{target}"').fetchall() == [(identity,)]
+        assert not conn.execute("PRAGMA foreign_key_check").fetchall()
+
+
+@pytest.mark.parametrize("stage,target,column", CASED_FK_TARGETS)
+@pytest.mark.parametrize("when", ("after_preview", "after_backup"))
+def test_cased_cascade_fk_added_after_preview_blocks_apply(tmp_path, monkeypatch, stage, target, column, when):
+    from src.lifecycle_investigation import disposal
+
+    market, profile, event, case = disposal_case(tmp_path)
+    plan = disposal.preview_disposal(market, profile)
+    assert plan["roots"] == [case]
+    assert plan["stages"]["market"]["observation_ids"] == [event["id"]]
+    if stage == "market":
+        disposal.apply_disposal_stage(profile, plan, stage="profile", approval_sha256=plan["approval_sha256"],
+            backup_path=tmp_path / "profile-backup", app_stopped=True)
+    path, identity = (profile, case) if stage == "profile" else (market, event["id"])
+    backup = tmp_path / "blocked-backup"
+    if when == "after_preview":
+        cascade_child(path, target, column, identity)
+    else:
+        original = disposal.backup_connection
+
+        def changed(conn, destination):
+            original(conn, destination)
+            cascade_child(path, target, column, identity)
+
+        monkeypatch.setattr(disposal, "backup_connection", changed)
+    with pytest.raises(ValueError, match="disposal_changed"):
+        disposal.apply_disposal_stage(path, plan, stage=stage, approval_sha256=plan["approval_sha256"],
+            backup_path=backup, app_stopped=True, profile_path=profile)
+    assert backup.exists() is (when == "after_backup")
+    with closing(sqlite3.connect(path)) as conn:
+        assert conn.execute("SELECT * FROM independent_receipt").fetchall() == [(1, identity, "retain")]
+        assert conn.execute(f'SELECT "{column}" FROM "{target}"').fetchall() == [(identity,)]
+        assert not conn.execute("PRAGMA foreign_key_check").fetchall()
+        assert not conn.execute("SELECT 1 FROM sqlite_master WHERE name='lifecycle_legacy_disposal_receipts'").fetchone()
+
+
+@pytest.mark.parametrize("stage,parent,target,column", (
+    pytest.param("profile", "\u017fecurity_lifecycle_cases", "\u017fECURITY_LIFECYCLE_CASES", "case_id", id="profile-distinct-unicode"),
+    pytest.param("market", "\u017fecurity_lifecycle_observations", "\u017fECURITY_LIFECYCLE_OBSERVATIONS", "id", id="market-distinct-unicode"),
+))
+def test_disposal_does_not_casefold_distinct_non_ascii_fk_targets(tmp_path, stage, parent, target, column):
+    from src.lifecycle_investigation.disposal import apply_disposal_stage, preview_disposal
+
+    market, profile, event, case = disposal_case(tmp_path)
+    path, identity = (profile, case) if stage == "profile" else (market, event["id"])
+    with closing(sqlite3.connect(path)) as conn:
+        conn.execute(f'CREATE TABLE "{parent}"("{column}" PRIMARY KEY)')
+        conn.execute(f'INSERT INTO "{parent}" VALUES (?)', (identity,))
+        conn.commit()
+    cascade_child(path, target, column, identity)
+    plan = preview_disposal(market, profile)
+    assert plan["roots"] == [case]
+    assert plan["stages"]["market"]["observation_ids"] == [event["id"]]
+    for name, store in (("profile", profile), ("market", market)):
+        assert apply_disposal_stage(store, plan, stage=name, approval_sha256=plan["approval_sha256"],
+            backup_path=tmp_path / f"{name}-backup", app_stopped=True, profile_path=profile)["status"] == "completed"
+    with closing(sqlite3.connect(path)) as conn:
+        assert conn.execute("SELECT * FROM independent_receipt").fetchall() == [(1, identity, "retain")]
+        assert conn.execute(f'SELECT "{column}" FROM "{parent}"').fetchall() == [(identity,)]
+        assert not conn.execute("PRAGMA foreign_key_check").fetchall()
+
+
+def test_disposal_preserves_approved_current_investigation_and_idempotent_confirmation(tmp_path):
+    from src.lifecycle_investigation.disposal import apply_disposal_stage, preview_disposal
+    from tests.test_lifecycle_investigation_review import context, prepare, confirm
+
+    c = context(tmp_path)
+    packet = prepare(c)
+    assert confirm(c, packet)["status"] == "applied"
+    before = c["investigation"].read(c["run_id"])
+    disposable = persist(c["profile"], observe(c["market"], ticker="DISCARD", ref="discard"))
+    plan = preview_disposal(c["market"], c["profile"])
+    assert plan["roots"] == [disposable]
+    for stage in ("profile", "market"):
+        assert apply_disposal_stage(c[stage], plan, stage=stage, approval_sha256=plan["approval_sha256"],
+            backup_path=tmp_path / f"{stage}-backup", app_stopped=True, profile_path=c["profile"])["status"] == "completed"
+    assert c["investigation"].read(c["run_id"]) == before
+    assert confirm(c, packet)["status"] == "already_applied"
+
+
 def test_retirement_disposal_is_scoped_and_preserves_other_data(tmp_path):
     from src.lifecycle_investigation.disposal import preview_disposal, apply_disposal_stage
     from src.lifecycle_investigation.schema import install_journal
     market, profile = stores(tmp_path)
     event = observe(market, ticker="OLD", ref="old")
     persist(profile, event)
     with sqlite3.connect(profile) as conn:
         install_journal(conn, at="2026-09-08T00:00:00Z")
         conn.execute("CREATE TABLE unrelated(value TEXT)")
         conn.execute("INSERT INTO unrelated VALUES ('keep')")
     plan = preview_disposal(market, profile)
     assert plan["counts"]["discard_cases"] == 1
     assert plan["counts"]["discard_observations"] == 1
     for stage, path in (("profile", profile), ("market", market)):
         result = apply_disposal_stage(path, plan, stage=stage, approval_sha256=plan["approval_sha256"],
             backup_path=tmp_path / f"{stage}-backup.sqlite", app_stopped=True, profile_path=profile)
         assert result["status"] == "completed"
         assert apply_disposal_stage(path, plan, stage=stage, approval_sha256=plan["approval_sha256"],
             backup_path=tmp_path / "unused", app_stopped=True, profile_path=profile)["status"] == "already_completed"
     with sqlite3.connect(profile) as conn:
@@ -31,40 +160,60 @@ def test_retirement_disposal_is_scoped_and_preserves_other_data(tmp_path):
 
 
 def test_disposal_stops_for_new_dependency_and_never_requires_quiescing_unrelated_sa(tmp_path):
     from src.lifecycle_investigation.disposal import preview_disposal, apply_disposal_stage
     from src.lifecycle_investigation.schema import install_journal
     market, profile = stores(tmp_path)
     event = observe(market, ticker="OLD", ref="old")
     case = persist(profile, event)
     with sqlite3.connect(profile) as conn:
         install_journal(conn, at="2026-09-08T00:00:00Z")
     plan = preview_disposal(market, profile)
     with sqlite3.connect(profile) as conn:
         conn.execute("CREATE TABLE new_dependency(case_id TEXT REFERENCES security_lifecycle_cases(case_id))")
         conn.execute("INSERT INTO new_dependency VALUES (?)", (case,))
     with pytest.raises(ValueError, match="disposal_changed"):
         apply_disposal_stage(profile, plan, stage="profile", approval_sha256=plan["approval_sha256"],
             backup_path=tmp_path / "backup", app_stopped=True)
     assert preview_disposal(market, profile)["counts"]["retained_cases"] == 1
 
 
+def test_unrelated_child_reference_retains_case_and_market_observation(tmp_path):
+    from src.lifecycle_investigation.disposal import preview_disposal
+
+    market, profile = stores(tmp_path)
+    event = observe(market, ticker="OLD", ref="retained")
+    case = persist(profile, event)
+    with sqlite3.connect(profile) as conn:
+        conn.execute("CREATE TABLE independent_receipt(case_id TEXT REFERENCES security_lifecycle_cases(case_id), payload TEXT)")
+        conn.execute("INSERT INTO independent_receipt VALUES (?, 'retained')", (case,))
+    plan = preview_disposal(market, profile)
+    assert plan["roots"] == []
+    assert plan["stages"]["profile"] == {}
+    assert plan["stages"]["market"]["observation_ids"] == []
+    assert plan["counts"]["retained_cases"] == 1
+    assert plan["retained"] == [{"case_id": case, "source": "sec_edgar", "source_ref": "retained", "ticker": "OLD", "reason": "retained_external_dependency"}]
+    with sqlite3.connect(profile) as conn:
+        assert conn.execute("SELECT * FROM independent_receipt").fetchall() == [(case, "retained")]
+        assert not conn.execute("PRAGMA foreign_key_check").fetchall()
+
+
 @pytest.mark.parametrize("journal_installed", (False, True))
 def test_current_composition_excludes_unretained_sec_without_a_cutover(tmp_path, journal_installed):
     from src.lifecycle_investigation.schema import install_journal
     from src.security_lifecycle_investigation import compose_security_lifecycle
     from src.security_lifecycle_provider_store import ProviderCheckStore
     market, profile = stores(tmp_path)
     event = observe(market, ticker="OLD", ref="old")
     persist(profile, event)
     observe(market, ticker="UNSAVED", ref="unsaved")
     persist(profile, {"source": "sec_edgar", "source_ref": "missing", "ticker": "MISSING"})
     ProviderCheckStore(profile).record(ticker="LISTED", at="2026-09-08T00:00:00Z", evidence=(), diagnostics={})
     if journal_installed:
         with sqlite3.connect(profile) as conn:
             install_journal(conn, at="2026-09-08T00:00:00Z")
     cases = compose_security_lifecycle(str(market), str(profile))["cases"]
     assert [(case["source"], case["ticker"]) for case in cases] == [("listing_authority", "LISTED")]
 
 
 @pytest.mark.parametrize("journal_installed", (False, True))
 def test_retained_sec_action_history_is_readable_but_not_background_intake(tmp_path, monkeypatch, journal_installed):
@@ -141,49 +290,52 @@ def test_disposal_deletes_draft_dependencies_but_retains_human_acceptance(tmp_pa
         case = persist(profile, event)
         with sqlite3.connect(profile) as conn:
             store = SecurityLifecycleInvestigationStore(conn)
             fingerprint = observation_fingerprint(event)
             assessment = store.create_assessment(case_id=case, relevance="direct_tracked_security", confidence="high", author="human",
                 conclusion="Preserve an accepted user assessment.", impact_summary="No change.", outcomes=("no_tracked_security_change",),
                 citations=({"reference_kind": "observation", "cited_content_sha256": fingerprint},),
                 observation_fingerprint_sha256=fingerprint, at="2026-09-08T00:00:00Z")
             if ticker == "HUMAN":
                 store.accept_assessment(assessment, observation_fingerprint_sha256=fingerprint, acceptance_authority="human", at="2026-09-08T00:00:00Z")
     with sqlite3.connect(profile) as conn:
         install_journal(conn, at="2026-09-08T00:00:00Z")
     plan = preview_disposal(market, profile)
     assert plan["counts"]["discard_cases"] == 1
     apply_disposal_stage(profile, plan, stage="profile", approval_sha256=plan["approval_sha256"], backup_path=tmp_path / "backup", app_stopped=True)
     with sqlite3.connect(profile) as conn:
         assert conn.execute("SELECT ticker FROM security_lifecycle_cases").fetchall() == [("HUMAN",)]
         assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_assessments").fetchone()[0] == 1
 
 
-def test_v1_web_dependencies_are_deleted_atomically_and_their_guards_restored(tmp_path, monkeypatch):
+def test_disposal_rolls_back_shared_evidence_when_receipt_publication_fails(tmp_path, monkeypatch):
     from src.lifecycle_investigation import disposal
-    from src.lifecycle_investigation.schema import install_journal
-    from src.lifecycle_web_schema import verify_web_journal
-    from tests.test_lifecycle_web_store import setup_store, completed
-    market, _ = stores(tmp_path)
-    profile, store = setup_store(tmp_path)
-    identity = completed(store)
-    observe(market, ticker="OLD", ref="source-1")
+    from src.lifecycle_investigation.schema import install_journal, verify_journal
+    from tests.test_security_lifecycle_population import bind_listing
+
+    market, profile = stores(tmp_path)
+    case_id = bind_listing(profile, observe(market, ticker="OLD", ref="source-1"), ())
     with sqlite3.connect(profile) as conn:
         install_journal(conn, at="2026-09-08T00:00:00Z")
     plan = disposal.preview_disposal(market, profile)
     assert plan["counts"]["discard_cases"] == 1
+    assert len(plan["stages"]["profile"]["security_lifecycle_automation_facts"]["rowids"]) == 3
     real_hash = disposal._sha_file
     monkeypatch.setattr(disposal, "_sha_file", lambda path: (_ for _ in ()).throw(OSError("receipt publication failed")))
     with pytest.raises(OSError, match="receipt publication failed"):
         disposal.apply_disposal_stage(profile, plan, stage="profile", approval_sha256=plan["approval_sha256"],
             backup_path=tmp_path / "failed-backup", app_stopped=True)
-    assert store.read(identity)["status"] == "succeeded"
+    assert disposal.preview_disposal(market, profile) == plan
+    with disposal.connect(tmp_path / "failed-backup") as conn:
+        assert disposal.profile_scope(conn, [case_id]) == plan["stages"]["profile"]
     with sqlite3.connect(profile) as conn:
-        verify_web_journal(conn)
+        verify_journal(conn)
         assert not conn.execute("SELECT 1 FROM sqlite_master WHERE name='lifecycle_legacy_disposal_receipts'").fetchall()
     monkeypatch.setattr(disposal, "_sha_file", real_hash)
     disposal.apply_disposal_stage(profile, plan, stage="profile", approval_sha256=plan["approval_sha256"],
         backup_path=tmp_path / "successful-backup", app_stopped=True)
     with sqlite3.connect(profile) as conn:
-        verify_web_journal(conn)
-        assert conn.execute("SELECT COUNT(*) FROM lifecycle_web_runs").fetchone()[0] == 0
+        verify_journal(conn)
+        assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_cases").fetchone()[0] == 0
+        assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_evidence").fetchone()[0] == 0
+        assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_automation_facts").fetchone()[0] == 0
         assert not conn.execute("PRAGMA foreign_key_check").fetchall()
diff --git a/tests/test_lifecycle_investigation_review.py b/tests/test_lifecycle_investigation_review.py
index a0350ea4..e353266f 100644
--- a/tests/test_lifecycle_investigation_review.py
+++ b/tests/test_lifecycle_investigation_review.py
@@ -3,156 +3,181 @@ import json
 import sqlite3
 
 import pytest
 
 from src.auth_drivers.lifecycle_web_models import WebCredential
 from src.lifecycle_investigation.agent import run_agent
 from src.lifecycle_investigation.news import LocalNews
 from src.lifecycle_investigation.runtime import InvestigationRuntime
 from src.lifecycle_investigation.schema import install_journal
 from src.lifecycle_investigation.store import InvestigationStore
 from src.lifecycle_investigation.target import Target, TargetPreflight
 from src.security_lifecycle_web_contract import ExecutionSelection
 from src.ticker_identity_transition import TransitionOptions
 from tests.test_lifecycle_investigation_agent import completed, choose
 from tests.test_lifecycle_investigation_findings import NOTICE, payload
 from tests.test_lifecycle_investigation_news import corpus
 from tests.lifecycle_investigation_fixtures import synthetic_credentials
 from tests.test_security_lifecycle_terminal_workflow import setup_workflow
 
 
-def context(tmp_path, *, finding_edit=lambda value: value, provider="openai", auth="api_key", body=NOTICE):
+def context(tmp_path, *, finding_edit=lambda value: value, provider="openai", auth="api_key", body=NOTICE,
+            model=None, reader_factory=None, kind="terminal_delisting", future=False, expected_status="succeeded"):
     c = setup_workflow(tmp_path, assess=False, event_available=False)
     c["now"][0] = "2026-09-08T01:00:00Z"
     c["checks"].record(ticker="OLD", at=c["now"][0], evidence=(), diagnostics={}, blockers=("massive_unavailable",))
     credentials, _, route = synthetic_credentials(provider=provider, auth=auth)
     with sqlite3.connect(c["profile"]) as conn:
         install_journal(conn, at=c["now"][0])
         conn.execute("DELETE FROM security_lifecycle_cases")
     preflight = TargetPreflight(c["service"], credential_store=credentials, route_loader=lambda: route,
         market_path=c["market"], sa_path=c["sa"])
     binding, _ = preflight._material("OLD")
     store = InvestigationStore(c["profile"], clock=lambda: c["now"][0])
     job = store.start(binding=binding, owner="worker", request_key="explicit-click")
     identity = job["run_id"]
     control = store.control(identity, owner="worker")
-    async def model(call, credential, control):
+    if kind == "symbol_continuation":
+        body = NOTICE.split("\n")[0] + "\nOn September 1, 2026, the same common stock on NASDAQ changed its ticker from OLD to NEW and continues trading."
+    async def default_model(call, credential, control):
         material = json.loads(call.prompt.split("\nMATERIAL\n")[1])
-        return completed(call, control, choose("conclude", finding=finding_edit(payload(material["sources"][0]["passages"]))))
+        finding = payload(material["sources"][0]["passages"])
+        if kind == "symbol_continuation":
+            finding.update(event_kind="symbol_continuation", successor_ticker="NEW", summary="The same common stock now trades as NEW.")
+            finding["citations"][-1]["supports"] = ["same_security_continuation", "effective_date"]
+        return completed(call, control, choose("conclude", finding=finding_edit(finding)))
+    reader = {} if reader_factory is None else {"reader_factory": reader_factory}
     result = asyncio.run(run_agent(Target.model_validate(binding["target"]), WebCredential(ExecutionSelection(**binding["selection"])), control,
-        runtime=InvestigationRuntime(), effort="high", news=LocalNews(corpus(tmp_path, body=body), None, clock=lambda: c["now"][0]), model=model,
+        runtime=InvestigationRuntime(), effort="high", news=LocalNews(corpus(tmp_path, body=body), None, clock=lambda: c["now"][0]), model=model or default_model,
         on_source=lambda key, value: store.source(identity, owner="worker", source_id=key, payload=value),
-        on_step=lambda kind, value: store.step(identity, owner="worker", kind=kind, payload=value)))
-    assert result["status"] == "succeeded", result
-    store.finish(identity, owner="worker", status="succeeded", payload=result)
-    c.update(investigation=store, run_id=identity, preflight=preflight)
+        on_step=lambda kind, value: store.step(identity, owner="worker", kind=kind, payload=value), **reader))
+    assert result["status"] == expected_status, result
+    store.finish(identity, owner="worker", status=result["status"], payload=result)
+    c.update(investigation=store, run_id=identity, preflight=preflight, control=control,
+        options=TransitionOptions(execute_on="2026-09-09" if future else None))
     return c
 
 
+def prepare(c):
+    from src.lifecycle_investigation.review import prepare
+    return prepare(c["service"], c["run_id"], options=c["options"])
+
+
+def confirm(c, packet, *, before_write=lambda: None, acknowledge_source_gaps=False):
+    from src.lifecycle_investigation.review import confirm
+    return confirm(c["service"], c["run_id"], packet_sha256=packet["packet_sha256"], action=packet["action"],
+        options=c["options"], before_write=before_write, acknowledge_source_gaps=acknowledge_source_gaps)
+
+
+def rows(c):
+    with sqlite3.connect(c["profile"]) as conn:
+        return tuple(conn.iterdump())
+
+
 def test_target_finding_uses_existing_atomic_receipt_without_fabricating_a_case_at_launch(tmp_path):
-    from src.lifecycle_web_review import prepare, confirm
+    from src.lifecycle_investigation.review import prepare, confirm
     c = context(tmp_path)
     with sqlite3.connect(c["profile"]) as conn:
         assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_cases").fetchone()[0] == 0
     packet = prepare(c["service"], c["run_id"], options=TransitionOptions(execute_on=None))
     assert packet["ready"], packet["block_reasons"]
     assert packet["lane"] == "investigation"
     result = confirm(c["service"], c["run_id"], packet_sha256=packet["packet_sha256"], action=packet["action"],
         options=TransitionOptions(execute_on=None), before_write=lambda: None)
     assert result["status"] == "applied", result
     assert "OLD" not in c["sources"]() and "LIVE" in c["sources"]()
     with sqlite3.connect(c["profile"]) as conn:
         assert conn.execute("SELECT source,source_ref FROM security_lifecycle_cases").fetchall() == [("lifecycle_investigation", c["run_id"])]
         assert conn.execute("SELECT actor FROM lifecycle_investigation_acceptances").fetchone()[0] == "attended_user"
     again = confirm(c["service"], c["run_id"], packet_sha256=packet["packet_sha256"], action=packet["action"],
         options=TransitionOptions(execute_on=None), before_write=lambda: None)
     assert again["status"] == "already_applied"
 
 
 def test_failed_adoption_does_not_leave_an_anchor_or_partial_profile_change(tmp_path, monkeypatch):
-    from src.lifecycle_web_review import prepare, confirm
+    from src.lifecycle_investigation.review import prepare, confirm
     from src.ticker_identity_transition import TickerIdentityTransitionStore
     c = context(tmp_path)
     packet = prepare(c["service"], c["run_id"], options=TransitionOptions(execute_on=None))
     monkeypatch.setattr(TickerIdentityTransitionStore, "_approve", lambda *a, **k: (_ for _ in ()).throw(ValueError("blocked")))
     with pytest.raises(ValueError, match="blocked"):
         confirm(c["service"], c["run_id"], packet_sha256=packet["packet_sha256"], action=packet["action"],
             options=TransitionOptions(execute_on=None), before_write=lambda: None)
     with sqlite3.connect(c["profile"]) as conn:
         assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_cases").fetchone()[0] == 0
         assert conn.execute("SELECT COUNT(*) FROM lifecycle_investigation_acceptances").fetchone()[0] == 0
     assert "OLD" in c["sources"]()
 
 
 def test_unknown_event_date_is_explicit_and_requires_an_attended_execution_date(tmp_path):
-    from src.lifecycle_web_review import prepare, confirm
+    from src.lifecycle_investigation.review import prepare, confirm
     def unknown_date(value):
         return {**value, "effective_date": None, "effective_date_text": None,
             "limitations": ["The exact trading-end date was not established."]}
     c = context(tmp_path, finding_edit=unknown_date)
     packet = prepare(c["service"], c["run_id"], options=TransitionOptions(execute_on=None))
     assert not packet["ready"]
     assert packet["execute_on"] is None
     assert "exact trading-end date" in packet["finding"]["impact_summary"]
     options = TransitionOptions(execute_on="2026-09-07")
     packet = prepare(c["service"], c["run_id"], options=options)
     assert packet["ready"], packet["block_reasons"]
     result = confirm(c["service"], c["run_id"], packet_sha256=packet["packet_sha256"], action=packet["action"],
         options=options, before_write=lambda: None)
     assert result["status"] == "applied"
     with sqlite3.connect(c["profile"]) as conn:
         assert conn.execute("SELECT effective_date FROM security_lifecycle_assessments").fetchone()[0] is None
         assert conn.execute("SELECT execute_on FROM ticker_identity_transitions").fetchone()[0] == "2026-09-07"
 
 
 def test_new_position_invalidates_target_review_even_with_source_gap_acknowledgement(tmp_path):
-    from src.lifecycle_web_review import prepare, confirm
+    from src.lifecycle_investigation.review import prepare, confirm
     from src.portfolio_state import PortfolioStore
     from src.ticker_identity_service import TickerIdentityConflict
     c = context(tmp_path)
     packet = prepare(c["service"], c["run_id"], options=TransitionOptions(execute_on=None))
     assert packet["ready"]
     portfolio = PortfolioStore(c["profile"])
     account = portfolio.ensure_manual_account()
     portfolio.upsert_manual_position(account_id=account.id, symbol="OLD", quantity=1)
     with pytest.raises(TickerIdentityConflict, match="review_changed"):
         confirm(c["service"], c["run_id"], packet_sha256=packet["packet_sha256"], action=packet["action"],
             options=TransitionOptions(execute_on=None), before_write=lambda: None, acknowledge_source_gaps=True)
     assert "OLD" in c["sources"]()
     with sqlite3.connect(c["profile"]) as conn:
         assert conn.execute("SELECT COUNT(*) FROM lifecycle_investigation_acceptances").fetchone()[0] == 0
 
 
 def test_fresh_active_provider_evidence_is_not_waived_by_source_gap_acknowledgement(tmp_path):
-    from src.lifecycle_web_review import prepare, confirm
+    from src.lifecycle_investigation.review import prepare, confirm
     from tests.test_security_lifecycle_population import active
     from src.ticker_identity_service import TickerIdentityConflict
     c = context(tmp_path)
     packet = prepare(c["service"], c["run_id"], options=TransitionOptions(execute_on=None))
     c["checks"].record(ticker="OLD", at="2026-09-08T01:00:01Z", evidence=(active("OLD", at="2026-09-08T01:00:01Z"),), diagnostics={})
     c["now"][0] = "2026-09-08T01:00:02Z"
     fresh = prepare(c["service"], c["run_id"], options=TransitionOptions(execute_on=None))
     assert not fresh["ready"] and "web_active_listing_conflict" in fresh["block_reasons"]
     with pytest.raises(TickerIdentityConflict, match="review_changed"):
         confirm(c["service"], c["run_id"], packet_sha256=packet["packet_sha256"], action=packet["action"],
             options=TransitionOptions(execute_on=None), before_write=lambda: None, acknowledge_source_gaps=True)
     assert "OLD" in c["sources"]()
 
 
 def test_same_security_rename_moves_tracking_but_preserves_the_source_history(tmp_path):
-    from src.lifecycle_web_review import prepare, confirm
+    from src.lifecycle_investigation.review import prepare, confirm
     body = NOTICE.split("\n")[0] + "\nOn September 1, 2026, the same common stock on NASDAQ changed its ticker from OLD to NEW and continues trading."
     def rename(value):
         value.update(event_kind="symbol_continuation", successor_ticker="NEW", summary="The same common stock now trades as NEW.")
         value["citations"][-1]["supports"] = ["same_security_continuation", "effective_date"]
         return value
     c = context(tmp_path, body=body, finding_edit=rename)
     with sqlite3.connect(c["sa"]) as conn:
         history = tuple(conn.iterdump())
     packet = prepare(c["service"], c["run_id"], options=TransitionOptions(execute_on=None))
     assert packet["ready"] and packet["action"] == "symbol_continuation", packet["block_reasons"]
     result = confirm(c["service"], c["run_id"], packet_sha256=packet["packet_sha256"], action=packet["action"],
         options=TransitionOptions(execute_on=None), before_write=lambda: None)
     assert result["status"] == "applied"
     assert "OLD" not in c["sources"]() and {"NEW", "LIVE"} <= set(c["sources"]())
     with sqlite3.connect(c["sa"]) as conn:
         assert tuple(conn.iterdump()) == history
diff --git a/tests/test_lifecycle_investigation_routes.py b/tests/test_lifecycle_investigation_routes.py
index 8ed49b4a..ae620f22 100644
--- a/tests/test_lifecycle_investigation_routes.py
+++ b/tests/test_lifecycle_investigation_routes.py
@@ -129,41 +129,41 @@ def test_unknown_failures_are_closed_and_contain_no_private_data(client, monkeyp
     assert response.json() == {"detail": {"code": "investigation_unavailable"}}
 
 
 def test_saved_provider_observations_are_dated_readonly_and_refresh_is_target_scoped(client, monkeypatch):
     from src.api.routes import lifecycle_investigation as api
     c = client
     reads = []
     monkeypatch.setattr(api, "run_provider_scan", lambda **kw: reads.append(kw))
     url = "/security-lifecycle/investigations/targets/OLD/providers"
     response = c["client"].get(url)
     assert response.status_code == 200
     assert response.json()["observations"]["observed_at"] == c["now"][0]
     assert reads == [] and c["calls"] == []
     assert c["client"].post(url + "/check").status_code == 200
     assert len(reads) == 1 and reads[0]["tickers"] == ("OLD",) and reads[0]["target_ticker"] == "OLD"
     assert c["client"].post(url.replace("OLD", "UNKNOWN") + "/check").status_code == 409
     assert len(reads) == 1
 
 
 def test_pending_confirmed_actions_remain_visible_without_the_legacy_queue(client):
-    from src.lifecycle_web_review import prepare, confirm
+    from src.lifecycle_investigation.review import prepare, confirm
     from src.ticker_identity_transition import TransitionOptions
     c = client
     options = TransitionOptions(execute_on="2026-09-10")
     packet = prepare(c["service"], c["run_id"], options=options)
     receipt = confirm(c["service"], c["run_id"], packet_sha256=packet["packet_sha256"], action=packet["action"],
         options=options, before_write=lambda: None)
     response = c["client"].get("/security-lifecycle/investigations/actions")
     assert response.status_code == 200
     action, = response.json()["actions"]
     assert action["transition_id"] == receipt["transition_id"]
     assert action["state"] == "scheduled" and action["execute_on"] == "2026-09-10"
     assert "approved_preview" not in action
     c["service"].cancel_transition(receipt["transition_id"], before_write=lambda: None)
     assert c["client"].get("/security-lifecycle/investigations/actions").json()["actions"] == []
 
 
 def test_provider_preparation_api_is_bound_to_the_selected_snapshot_without_dispatch(client, monkeypatch):
     from dataclasses import replace
     import sqlite3
     from src.api.routes import lifecycle_investigation as api
diff --git a/tests/test_lifecycle_investigation_source_journal.py b/tests/test_lifecycle_investigation_source_journal.py
new file mode 100644
index 00000000..7126a9a4
--- /dev/null
+++ b/tests/test_lifecycle_investigation_source_journal.py
@@ -0,0 +1,96 @@
+"""Retained current sources, supplied passages, and cooperative final validation."""
+
+import json
+import sqlite3
+
+import pytest
+
+from src.lifecycle_investigation import agent
+from src.lifecycle_investigation.store import InvestigationStore
+from src.lifecycle_journal_codec import canonical_json, digest_json
+from tests.lifecycle_investigation_fixtures import controller, wait_done
+from tests.test_lifecycle_investigation_agent import choose, completed
+from tests.test_lifecycle_investigation_findings import NOTICE, payload
+from tests.test_lifecycle_investigation_review import context, prepare
+from tests.test_ticker_identity_history import damage_saved_rows
+
+
+def test_current_journal_preserves_full_unicode_source_and_supplied_passages_after_reopen(tmp_path):
+    body = "Public appendix \U00020000\u4e2d.\n" * 15000 + NOTICE
+    async def model(call, credential, control):
+        material = json.loads(call.prompt.split("\nMATERIAL\n")[1])
+        parts = material["sources"][0]["passages"]
+        identity = next(part for part in parts if "Issuer Old Inc" in part["text"])
+        event = next(part for part in parts if "Trading in" in part["text"])
+        assert len(call.prompt) < len(body) / 3
+        return completed(call, control, choose("conclude", finding=payload([identity, event])))
+    c = context(tmp_path, body=body, model=model)
+    row = InvestigationStore(c["profile"]).read(c["run_id"])
+    assert row["sources"]["source-1"]["text"] == body
+    requested = [step["payload"] for step in row["steps"] if step["kind"] == "model_request"][-1]
+    assert set(row["result"]["supplied_passages"]) == set(requested["supplied_passages"])
+    assert {item["passage_id"] for item in row["result"]["validated"]["passages"]} <= set(requested["supplied_passages"])
+    with sqlite3.connect(c["profile"]) as conn:
+        raw, digest = conn.execute("SELECT payload_json,payload_sha256 FROM lifecycle_investigation_sources").fetchone()
+        assert json.loads(raw)["text"] == body and digest == digest_json(json.loads(raw))
+    assert prepare(c)["ready"]
+
+
+@pytest.mark.parametrize("change", ["payload_digest", "source_digest", "source_text"])
+def test_current_adoption_rejects_changed_source_or_capture_digest(tmp_path, change):
+    c = context(tmp_path)
+    with sqlite3.connect(c["profile"]) as conn:
+        material = json.loads(conn.execute("SELECT payload_json FROM lifecycle_investigation_sources").fetchone()[0])
+        if change == "source_digest":
+            material["text_sha256"] = "0" * 64
+        elif change == "source_text":
+            material["text"] += "\nContrary new material."
+        digest = "0" * 64 if change == "payload_digest" else digest_json(material)
+        damage_saved_rows(conn, "lifecycle_investigation_sources",
+            "UPDATE lifecycle_investigation_sources SET payload_json=?,payload_sha256=?", (canonical_json(material), digest))
+    with pytest.raises(ValueError, match="investigation_integrity|source_integrity"):
+        prepare(c)
+    assert "OLD" in c["sources"]()
+
+
+@pytest.mark.parametrize("supplied", [[], ["source-999:p1"], None])
+def test_current_adoption_requires_citations_from_the_recorded_model_context(tmp_path, supplied):
+    c = context(tmp_path)
+    with sqlite3.connect(c["profile"]) as conn:
+        ordinal, raw = conn.execute("SELECT ordinal,payload_json FROM lifecycle_investigation_steps WHERE kind='model_request' ORDER BY ordinal DESC LIMIT 1").fetchone()
+        material = json.loads(raw)
+        material["supplied_passages"] = supplied
+        damage_saved_rows(conn, "lifecycle_investigation_steps",
+            "UPDATE lifecycle_investigation_steps SET payload_json=?,payload_sha256=? WHERE ordinal=?",
+            (canonical_json(material), digest_json(material), ordinal))
+    with pytest.raises(ValueError, match="investigation_integrity"):
+        prepare(c)
+    assert "OLD" in c["sources"]()
+
+
+@pytest.mark.parametrize("cancel", [False, True])
+def test_current_agent_final_source_validation_allows_heartbeat_and_running_cancellation(tmp_path, monkeypatch, cancel):
+    service, store, _, binding = controller(tmp_path)
+    original, observed = agent.validate_finding, []
+    def validate(*args, **kwargs):
+        with sqlite3.connect(store.path) as conn:
+            identity, owner = conn.execute("SELECT run_id,owner FROM lifecycle_investigation_jobs WHERE status='running'").fetchone()
+        assert store.heartbeat(identity, owner=owner) is False
+        if cancel:
+            service.cancel(identity)
+        observed.append(True)
+        return original(*args, **kwargs)
+    monkeypatch.setattr(agent, "validate_finding", validate)
+    try:
+        identity = service.start(binding=binding, request_key="current-validation")["run_id"]
+        result = wait_done(service, identity)
+        assert result["status"] == ("cancelled" if cancel else "succeeded"), result
+        assert result["action"] == (None if cancel else "terminal_delisting")
+        assert observed == [True]
+        row = store.read(identity)
+        assert all(call["terminal"] == "completed" for call in row["calls"])
+        assert row["sources"]["source-1"]["text"] == NOTICE
+        with sqlite3.connect(store.path) as conn:
+            assert conn.execute("SELECT COUNT(*) FROM lifecycle_investigation_acceptances").fetchone()[0] == 0
+    finally:
+        service.close()
diff --git a/tests/test_lifecycle_investigation_store.py b/tests/test_lifecycle_investigation_store.py
index e16c18f7..64b47fda 100644
--- a/tests/test_lifecycle_investigation_store.py
+++ b/tests/test_lifecycle_investigation_store.py
@@ -7,53 +7,54 @@ from tests.test_security_lifecycle_terminal_workflow import setup_workflow
 
 
 def running(tmp_path, *, ticker="OLD"):
     from src.lifecycle_investigation.runtime import InvestigationRuntime
     from src.lifecycle_investigation.schema import install_journal
     from src.lifecycle_investigation.store import InvestigationStore
     from src.lifecycle_investigation.target import Target
     from src.lifecycle_journal_codec import digest_json
     c = setup_workflow(tmp_path, assess=False, event_available=False)
     with sqlite3.connect(c["profile"]) as conn:
         install_journal(conn, at=c["now"][0])
     binding = {"version": 2, "language": "en", "target": Target(ticker=ticker, as_of="2026-09-08").model_dump(),
         "selection": {"provider": "anthropic", "model": "claude-sonnet-5", "auth_mode": "claude_code_oauth", "credential_id": "local:7"},
         "runtime": InvestigationRuntime().model_dump(), "effort": "high", "credential_generation": "generation-1",
         "provider_observations": [], "provider_sha256": digest_json([])}
     store = InvestigationStore(c["profile"], clock=lambda: c["now"][0])
     identity = store.start(binding=binding, owner="worker", request_key="explicit-click")["run_id"]
     return c, store, identity, binding
 
 
-def test_v2_installation_preserves_v1_and_requires_no_case(tmp_path):
+def test_current_installation_preserves_unrelated_data_and_requires_no_case(tmp_path):
     from src.lifecycle_investigation.schema import install_journal, verify_journal
-    from src.lifecycle_web_schema import install_web_journal, verify_web_journal
     c = setup_workflow(tmp_path, assess=False, event_available=False)
     with sqlite3.connect(c["profile"]) as conn:
-        install_web_journal(conn, at=c["now"][0])
-        before = list(conn.execute("SELECT name,sql FROM sqlite_master WHERE name LIKE 'lifecycle_web_%'"))
+        conn.execute("CREATE TABLE unrelated_receipts (receipt TEXT NOT NULL)")
+        conn.execute("INSERT INTO unrelated_receipts VALUES ('retained')")
+        before = conn.execute("SELECT COUNT(*) FROM security_lifecycle_cases").fetchone()[0]
+        conn.commit()
         install_journal(conn, at=c["now"][0])
         verify_journal(conn)
-        verify_web_journal(conn)
-        assert before == list(conn.execute("SELECT name,sql FROM sqlite_master WHERE name LIKE 'lifecycle_web_%'"))
-        assert not list(conn.execute("PRAGMA foreign_key_list(lifecycle_investigation_jobs)"))
         install_journal(conn, at=c["now"][0])
+        assert conn.execute("SELECT * FROM unrelated_receipts").fetchall() == [("retained",)]
+        assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_cases").fetchone()[0] == before
+        assert not list(conn.execute("PRAGMA foreign_key_list(lifecycle_investigation_jobs)"))
 
 
 def test_journal_read_does_not_install_or_tolerate_unknown_schema(tmp_path):
     from src.lifecycle_investigation.schema import verify_journal
     with sqlite3.connect(tmp_path / "profile.db") as conn:
         with pytest.raises(ValueError, match="investigation_not_installed"):
             verify_journal(conn)
         assert list(conn.execute("SELECT name FROM sqlite_master")) == []
 
 
 @pytest.mark.parametrize("failure", ("no_result", "failed_remote"))
 def test_success_requires_a_completed_owned_conclusion(tmp_path, failure):
     _, store, identity, _ = running(tmp_path)
     store.reserve_call(identity, owner="worker", call_id="one")
     store.bind_call(identity, owner="worker", call_id="one", remote_id="remote-one",
         terminal="completed" if failure == "no_result" else "failed")
     with pytest.raises(ValueError, match="investigation_integrity"):
         store.finish(identity, owner="worker", status="succeeded")
     assert store.read(identity)["status"] == "running"
     store.finish(identity, owner="worker", status="failed", failure_code="model_output_invalid")
@@ -96,35 +97,82 @@ def test_cancel_owner_and_immutable_call_guards_are_independent(tmp_path):
         store.step(identity, owner="other", kind="searching", payload={})
     store.reserve_call(identity, owner="worker", call_id="one")
     store.bind_call(identity, owner="worker", call_id="one", remote_id="remote-one", terminal="completed")
     with pytest.raises(ValueError, match="investigation_recording_unavailable"):
         store.bind_call(identity, owner="worker", call_id="one", remote_id="remote-two", terminal="completed")
     store.cancel(identity)
     with pytest.raises(ValueError, match="stop_requested"):
         store.reserve_call(identity, owner="worker", call_id="two")
     store.finish(identity, owner="worker", status="failed")
     assert store.read(identity)["status"] == "cancelled"
     with pytest.raises(ValueError, match="investigation_not_running"):
         store.step(identity, owner="worker", kind="searching", payload={})
 
 
 @pytest.mark.parametrize("kind", ["model", "journal", "contract", "source", "value", "unexpected"])
 @pytest.mark.parametrize("message", ["provider_call_failed", "secret=private-token", "x" * 101])
 def test_current_error_projection_keeps_typed_codes_but_never_raw_provider_errors(kind, message):
     from src.auth_drivers.lifecycle_web_models import WebModelError
     from src.lifecycle_investigation.store import safe_code
     from src.lifecycle_public_sources import SourceReadError
-    from src.lifecycle_web_store import WebJournalError
+    from src.lifecycle_investigation.store import JournalError
     from src.security_lifecycle_web_contract import WebContractError
 
-    classes = {"model": WebModelError, "journal": WebJournalError, "contract": WebContractError,
+    classes = {"model": WebModelError, "journal": JournalError, "contract": WebContractError,
         "source": SourceReadError, "value": ValueError, "unexpected": RuntimeError}
     expected = "provider_call_failed" if kind not in {"value", "unexpected"} and message == "provider_call_failed" else "web_execution_failed"
     assert safe_code(classes[kind](message)) == expected
     assert safe_code(ValueError("investigation_recording_unavailable")) == "investigation_recording_unavailable"
 
 
 def test_current_error_projection_keeps_the_unavailable_route_code():
     from src.lifecycle_investigation.store import safe_code
     from src.model_routing import ModelRouteUnavailable
 
     assert safe_code(ModelRouteUnavailable()) == "model_route_unavailable"
+
+
+def test_current_start_replays_request_without_resetting_recorded_work(tmp_path):
+    c, store, identity, binding = running(tmp_path)
+    store.step(identity, owner="worker", kind="local_search", payload={"query": {}})
+    before = store.read(identity)
+    assert store.start(binding=binding, owner="other", request_key="explicit-click") == {"run_id": identity, "created": False}
+    assert store.read(identity) == before
+    with pytest.raises(ValueError, match="investigation_running"):
+        store.start(binding=binding, owner="other", request_key="new-click")
+
+
+def test_current_recording_failure_stops_control_before_remote_dispatch(tmp_path, monkeypatch):
+    _, store, identity, _ = running(tmp_path)
+    control = store.control(identity, owner="worker")
+    def fail(*args, **kwargs):
+        raise ValueError("investigation_recording_unavailable")
+    monkeypatch.setattr(store, "reserve_call", fail)
+    with pytest.raises(ValueError, match="^investigation_recording_unavailable$"):
+        control.reserve_model_request("not-dispatched")
+    assert control.stop_state != "running"
+    row = store.read(identity)
+    assert row["calls"] == [] and row["result"] is None and row["status"] == "running"
+
+
+@pytest.mark.parametrize("expired", [False, True])
+def test_current_wrong_or_expired_owner_cannot_record_provider_work(tmp_path, expired):
+    c, store, identity, _ = running(tmp_path)
+    if expired:
+        c["now"][0] = "2026-09-09T00:00:00Z"
+    with pytest.raises(ValueError, match="investigation_not_running" if expired else "investigation_owner_changed"):
+        store.reserve_call(identity, owner="worker" if expired else "other", call_id="not-dispatched")
+    assert store.read(identity)["calls"] == []
+
+
+def test_current_source_rows_are_immutable_and_no_human_acceptance_is_fabricated(tmp_path):
+    from tests.test_lifecycle_investigation_review import context
+    c = context(tmp_path)
+    row = c["investigation"].read(c["run_id"])
+    assert row["status"] == "succeeded" and not row["adopted"]
+    with sqlite3.connect(c["profile"]) as conn:
+        for statement in ("UPDATE lifecycle_investigation_sources SET payload_json='{}'", "DELETE FROM lifecycle_investigation_sources",
+                          "UPDATE lifecycle_investigation_jobs SET status='failed'", "UPDATE lifecycle_investigation_jobs SET cancel_requested_at=created_at"):
+            with pytest.raises(sqlite3.IntegrityError, match="investigation_immutable"):
+                conn.execute(statement)
+        for table in ("security_lifecycle_cases", "security_lifecycle_assessments", "lifecycle_investigation_acceptances"):
+            assert conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] == 0
diff --git a/tests/test_lifecycle_investigation_usage_journal.py b/tests/test_lifecycle_investigation_usage_journal.py
new file mode 100644
index 00000000..3ab12a42
--- /dev/null
+++ b/tests/test_lifecycle_investigation_usage_journal.py
@@ -0,0 +1,101 @@
+"""Current usage belongs to durable calls, never inferred remote success."""
+
+from dataclasses import replace
+import json
+import sqlite3
+
+import pytest
+
+from src.auth_drivers.lifecycle_web_models import WebModelError
+from src.lifecycle_investigation.agent import run_agent
+from src.lifecycle_investigation.store import InvestigationStore
+from src.lifecycle_journal_codec import canonical_json, digest_json
+from tests.lifecycle_investigation_fixtures import controller, wait_done
+from tests.test_lifecycle_investigation_agent import choose, completed
+from tests.test_lifecycle_investigation_findings import payload
+from tests.test_ticker_identity_history import damage_saved_rows
+
+
+def usage_run(tmp_path, *, outcome="complete"):
+    calls = []
+    async def model(call, credential, control):
+        calls.append(call)
+        if len(calls) == 1:
+            reply = completed(call, control, "not JSON", error="model_output_invalid")
+            if outcome == "partial":
+                reply = replace(reply, usage={"input_tokens": None, "output_tokens": None})
+            return reply
+        if outcome in {"lost", "failed"}:
+            if outcome == "lost":
+                control.reserve_model_request(call.call_id)
+                control.bind_remote_id(call.call_id, "lost-remote")
+                control.observe_transport_loss(call.call_id)
+            raise WebModelError("provider_call_failed")
+        material = json.loads(call.prompt.split("\nMATERIAL\n")[1])
+        return completed(call, control, choose("conclude", finding=payload(material["sources"][0]["passages"])))
+    async def runner(*args, **kwargs):
+        return await run_agent(*args, **kwargs, model=model)
+    service, store, loads, binding = controller(tmp_path, runner=runner)
+    try:
+        identity = service.start(binding=binding, request_key="usage-case")["run_id"]
+        projected = wait_done(service, identity)
+        assert len(calls) == 2 and len(loads) == 1
+        return store, identity, projected
+    finally:
+        service.close()
+
+
+@pytest.mark.parametrize("outcome,status,tokens", [
+    ("complete", "succeeded", (20, 40)), ("partial", "succeeded", (None, None)),
+    ("lost", "remote_outcome_unknown", (None, None)), ("failed", "failed", (10, 20)),
+])
+def test_current_usage_retains_known_or_unknown_totals_and_truthful_remote_outcome(tmp_path, outcome, status, tokens):
+    store, identity, projected = usage_run(tmp_path, outcome=outcome)
+    row = InvestigationStore(store.path).read(identity)
+    assert projected["status"] == row["status"] == status
+    assert (projected["stats"]["input_tokens"], projected["stats"]["output_tokens"]) == tokens
+    results = [step["payload"] for step in row["steps"] if step["kind"] == "model_result"]
+    calls = {call["call_id"]: call for call in row["calls"]}
+    assert all(calls[result["call_id"]]["remote_id"] == result["remote_id"] for result in results)
+    assert all(calls[result["call_id"]]["terminal"] == "completed" for result in results)
+    assert all(result["usage_observation"] is None for result in results)
+    assert row["result"]["validated"] is None if outcome in {"lost", "failed"} else projected["action"] == "terminal_delisting"
+    if outcome == "lost":
+        assert calls["step-2"] == {"call_id": "step-2", "remote_id": "lost-remote", "terminal": None}
+    with sqlite3.connect(store.path) as conn:
+        assert conn.execute("SELECT COUNT(*) FROM lifecycle_investigation_acceptances").fetchone()[0] == 0
+
+
+@pytest.mark.parametrize("mutation", ["remote_id", "unknown_call", "duplicate", "malformed_usage", "malformed_observation", "aggregate"])
+def test_current_reopened_usage_rechecks_call_binding_and_integrity(tmp_path, mutation):
+    store, identity, projected = usage_run(tmp_path)
+    assert projected["status"] == "succeeded"
+    with sqlite3.connect(store.path) as conn:
+        if mutation == "aggregate":
+            raw = conn.execute("SELECT payload_json FROM lifecycle_investigation_results WHERE run_id=?", (identity,)).fetchone()[0]
+            material = json.loads(raw)
+            material["stats"]["input_tokens"] = 999
+            damage_saved_rows(conn, "lifecycle_investigation_results",
+                "UPDATE lifecycle_investigation_results SET payload_json=?,payload_sha256=? WHERE run_id=?",
+                (canonical_json(material), digest_json(material), identity))
+        else:
+            ordinal, raw, at = conn.execute("SELECT ordinal,payload_json,created_at FROM lifecycle_investigation_steps WHERE run_id=? AND kind='model_result' ORDER BY ordinal LIMIT 1", (identity,)).fetchone()
+            material = json.loads(raw)
+            if mutation == "remote_id":
+                material["remote_id"] = "unbound-remote"
+            elif mutation == "unknown_call":
+                material["call_id"] = "unbound-call"
+            elif mutation == "malformed_usage":
+                material["usage"] = {"input_tokens": True, "output_tokens": 20}
+            elif mutation == "malformed_observation":
+                material["usage_observation"] = {"basis": "adapter_report", "values": {}, "secret": "private-token"}
+            if mutation == "duplicate":
+                ordinal = conn.execute("SELECT MAX(ordinal)+1 FROM lifecycle_investigation_steps WHERE run_id=?", (identity,)).fetchone()[0]
+                conn.execute("INSERT INTO lifecycle_investigation_steps VALUES (?,?,?,?,?,?)",
+                    (identity, ordinal, "model_result", canonical_json(material), digest_json(material), at))
+            else:
+                damage_saved_rows(conn, "lifecycle_investigation_steps",
+                    "UPDATE lifecycle_investigation_steps SET payload_json=?,payload_sha256=? WHERE run_id=? AND ordinal=?",
+                    (canonical_json(material), digest_json(material), identity, ordinal))
+    with pytest.raises(ValueError, match="^investigation_integrity$"):
+        InvestigationStore(store.path).read(identity, include_sources=False)
diff --git a/tests/test_lifecycle_journal_codec.py b/tests/test_lifecycle_journal_codec.py
index 18ef8d7d..47beddf8 100644
--- a/tests/test_lifecycle_journal_codec.py
+++ b/tests/test_lifecycle_journal_codec.py
@@ -37,47 +37,40 @@ _CASES = [
         {"z": "\b\f\r\x00", "a": 'quote" slash\\ line\n\t'},
         rb'{"a":"quote\" slash\\ line\n\t","z":"\b\f\r\u0000"}',
         "c116ff05bd0ea0b5a3f991efe3f2d4254bd41f2801abac52c2aaaef16591cbd2",
         id="control-escaping",
     ),
     pytest.param(
         {"\u4e2d": 2, "\u00e9": 1, "a": 0},
         rb'{"a":0,"\u00e9":1,"\u4e2d":2}',
         "1e28c10f01a640bce81e3d0ed71e098937e44a7ef4fb730ac4a03a2035e93721",
         id="unicode-key-sort",
     ),
 ]
 
 
 def test_neutral_journal_codec_owns_public_functions():
     codec = import_module(_OWNER)
     assert codec.canonical_json.__module__ == _OWNER
     assert codec.digest_json.__module__ == _OWNER
 
 
-@pytest.mark.parametrize("name", ["_json", "_sha"])
-def test_retained_journal_does_not_export_legacy_codec_helpers(name):
-    journal = import_module("src.lifecycle_web_store")
-    assert not hasattr(journal, name)
-    assert name not in getattr(journal, "__all__", ())
-
-
 @pytest.mark.parametrize("value,expected_bytes,_digest", _CASES)
 def test_canonical_json_matches_literal_journal_bytes(value, expected_bytes, _digest):
     codec = import_module(_OWNER)
     assert codec.canonical_json(value).encode("utf-8") == expected_bytes
 
 
 @pytest.mark.parametrize("value,_encoded,expected_digest", _CASES)
 def test_digest_json_matches_literal_utf8_sha256(value, _encoded, expected_digest):
     codec = import_module(_OWNER)
     assert codec.digest_json(value) == expected_digest
 
 
 def test_canonical_json_can_preserve_utf8_without_ascii_expansion():
     codec = import_module(_OWNER)
     value = {"z": "\U0001f680", "a": "caf\u00e9 \u4e2d"}
     assert codec.canonical_json(value, ensure_ascii=False).encode("utf-8") == (
         b'{"a":"caf\xc3\xa9 \xe4\xb8\xad","z":"\xf0\x9f\x9a\x80"}'
     )
     assert codec.digest_json(value) == "4b5704b5afed23706bd0c195a110a296219e5cef9d18f0dc7e71c86e2ed1004e"
 
@@ -85,42 +78,41 @@ def test_canonical_json_can_preserve_utf8_without_ascii_expansion():
 @pytest.mark.parametrize("number", [float("nan"), float("inf"), float("-inf")], ids=["nan", "infinity", "negative-infinity"])
 @pytest.mark.parametrize("nested", [False, True], ids=["scalar", "nested"])
 @pytest.mark.parametrize("operation", ["canonical", "utf8", "digest"])
 def test_nonfinite_numbers_are_rejected_before_journaling(number, nested, operation):
     codec = import_module(_OWNER)
     value = {"rows": [{"value": number}]} if nested else number
     with pytest.raises(ValueError):
         if operation == "digest":
             codec.digest_json(value)
         else:
             codec.canonical_json(value, ensure_ascii=operation != "utf8")
 
 
 @pytest.mark.parametrize("module,names", [
     ("lifecycle_investigation.store", {"canonical_json", "digest_json"}),
     ("lifecycle_investigation.adoption", {"digest_json"}),
     ("lifecycle_investigation.agent", {"digest_json"}),
     ("lifecycle_investigation.target", {"digest_json"}),
     ("lifecycle_investigation.migration", {"digest_json"}),
     ("lifecycle_investigation.disposal", {"canonical_json", "digest_json"}),
-    ("lifecycle_web_store", {"canonical_json", "digest_json"}),
-    ("lifecycle_web_review", {"canonical_json", "digest_json"}),
+    ("lifecycle_investigation.review", {"canonical_json"}),
     ("ticker_identity_history", {"digest_json"}),
 ])
 def test_journal_consumers_import_the_neutral_codec_directly(module, names):
     path = Path(__file__).resolve().parents[1] / "src" / (module.replace(".", "/") + ".py")
     tree = ast.parse(path.read_text(encoding="utf-8"))
     imported = {
         alias.name
         for node in tree.body
         if isinstance(node, ast.ImportFrom) and node.module == _OWNER
         for alias in node.names
         if alias.asname is None
     }
     assert names <= imported
     legacy = {"_json", "_sha"}
     legacy_imports = [
         (node.lineno, node.name, node.asname)
         for node in ast.walk(tree)
         if isinstance(node, ast.alias) and legacy.intersection((node.name, node.asname))
     ]
     assert not legacy_imports, legacy_imports
diff --git a/tests/test_lifecycle_source_capacity.py b/tests/test_lifecycle_source_capacity.py
index 52c62f7c..e433afe7 100644
--- a/tests/test_lifecycle_source_capacity.py
+++ b/tests/test_lifecycle_source_capacity.py
@@ -27,150 +27,37 @@ def test_large_page_hash_never_serializes_the_whole_source_at_once(monkeypatch):
     from src import lifecycle_public_sources as sources
 
     page = source_page("\U00020000" * (512 * 1024))
     expected = page.capture_sha256
     original = json.dumps
     chunks = []
 
     def bounded(value, **kwargs):
         if isinstance(value, dict):
             assert len(value.get("text", "")) <= 65536
         if isinstance(value, str):
             assert len(value) <= 65536
             chunks.append(len(value))
         return original(value, **kwargs)
 
     monkeypatch.setattr(sources.json, "dumps", bounded)
     assert sources._capture_digest(page) == expected
     assert len([length for length in chunks if length == 65536]) == 8
 
 
-def test_unicode_source_journal_avoids_escape_expansion_without_changing_old_digests(tmp_path):
-    from src.lifecycle_journal_codec import canonical_json, digest_json
-    from tests.test_lifecycle_web_store import setup_store, start
-
-    _, store = setup_store(tmp_path)
-    identity = start(store)["run_id"]
-    text = "\u6539\u540d \U00020000\n" * 10000
-    page = source_page(text)
-    store.add_page(identity, owner="worker-1", source_id="source-1", page=page)
-    material = asdict(page)
-    with store.connection(write=True) as conn:
-        row = conn.execute("SELECT page_json,page_sha256 FROM lifecycle_web_pages WHERE run_id=?", (identity,)).fetchone()
-        assert len(row["page_json"].encode()) < len(text.encode()) * 1.2
-        assert row["page_sha256"] == digest_json(material)
-        assert json.loads(row["page_json"])["text"] == text
-        # Both encodings use the same canonical digest; no migration or rewriting.
-        conn.execute("INSERT INTO lifecycle_web_pages VALUES (?,?,?,?)", (identity, "source-2", canonical_json(material), digest_json(material)))
-    pages = store.read(identity)["pages"]
-    assert pages["source-1"] == pages["source-2"] == page
-
-
-@pytest.mark.parametrize("field", ["page_sha256", "capture_sha256"])
-def test_source_journal_still_rejects_changed_page_and_capture_fingerprints(tmp_path, field):
-    from src.lifecycle_journal_codec import canonical_json, digest_json
-    from src.lifecycle_web_schema import WebJournalError
-    from tests.test_lifecycle_web_store import setup_store, start
-
-    _, store = setup_store(tmp_path)
-    identity = start(store)["run_id"]
-    material = asdict(source_page("\u4e0b\u5e02 \U00020000"))
-    if field == "capture_sha256":
-        material[field] = "0" * 64
-    digest = "0" * 64 if field == "page_sha256" else digest_json(material)
-    with store.connection(write=True) as conn:
-        conn.execute("INSERT INTO lifecycle_web_pages VALUES (?,?,?,?)", (identity, "source-1", canonical_json(material), digest))
-    with pytest.raises(WebJournalError, match="^web_journal_integrity$"):
-        store.read(identity)
-
-
-@pytest.mark.parametrize("cancel", [False, True])
-def test_final_source_validation_does_not_block_heartbeat_or_cancellation(tmp_path, monkeypatch, cancel):
-    import sqlite3
-    from src import lifecycle_web_store as journal
-    from tests.test_lifecycle_web_store import setup_store, completed
-
-    path, store = setup_store(tmp_path)
-    original, observed = journal.validate_finding, []
-
-    def validate(*args, **kwargs):
-        # A different connection must commit while potentially large source
-        # validation is in progress, including in rollback-journal mode.
-        with sqlite3.connect(path, timeout=0) as conn:
-            conn.execute("BEGIN IMMEDIATE")
-            conn.execute("UPDATE lifecycle_web_runs SET lease_until=lease_until")
-            if cancel:
-                conn.execute("UPDATE lifecycle_web_runs SET cancel_requested_at=created_at")
-        observed.append(True)
-        return original(*args, **kwargs)
-
-    monkeypatch.setattr(journal, "validate_finding", validate)
-    if cancel:
-        with pytest.raises(journal.WebJournalError, match="^stop_requested$"):
-            completed(store)
-        with store.connection() as conn:
-            assert conn.execute("SELECT COUNT(*) FROM lifecycle_web_results").fetchone()[0] == 0
-    else:
-        completed(store)
-        with store.connection() as conn:
-            assert conn.execute("SELECT status FROM lifecycle_web_runs").fetchone()[0] == "succeeded"
-    assert observed == [True]
-
-
-def test_final_source_decoding_does_not_keep_a_read_transaction_open(tmp_path, monkeypatch):
-    import sqlite3
-    from src.lifecycle_web_store import LifecycleWebStore
-    from tests.test_lifecycle_web_store import setup_store, completed
-
-    path, store = setup_store(tmp_path)
-    original, observed = LifecycleWebStore._decode_page, []
-
-    def decode(row):
-        with sqlite3.connect(path, timeout=0) as conn:
-            conn.execute("BEGIN IMMEDIATE")
-            conn.execute("UPDATE lifecycle_web_runs SET lease_until=lease_until")
-        observed.append(True)
-        return original(row)
-
-    monkeypatch.setattr(store, "_decode_page", decode)
-    completed(store)
-    assert observed == [True]
-
-
-def test_changed_source_snapshot_cannot_commit_a_previously_validated_finding(tmp_path, monkeypatch):
-    from src import lifecycle_web_store as journal
-    from tests.test_lifecycle_web_store import setup_store, completed
-
-    _, store = setup_store(tmp_path)
-    original = journal.validate_finding
-
-    def validate(*args, **kwargs):
-        result = original(*args, **kwargs)
-        with store.connection() as conn:
-            identity = conn.execute("SELECT run_id FROM lifecycle_web_runs").fetchone()[0]
-        store.add_page(identity, owner="worker-1", source_id="source-2", page=source_page("New contrary information."))
-        return result
-
-    monkeypatch.setattr(journal, "validate_finding", validate)
-    with pytest.raises(journal.WebJournalError, match="^web_journal_integrity$"):
-        completed(store)
-    with store.connection() as conn:
-        assert conn.execute("SELECT COUNT(*) FROM lifecycle_web_results").fetchone()[0] == 0
-
-
 @pytest.mark.parametrize("mime", ["text/plain", "application/json", "application/xml"])
 def test_full_context_reuses_the_retained_text_without_a_second_source_copy(mime):
     from src.lifecycle_public_sources import _capture_digest
     from src.lifecycle_source_context import select_source_context
     from tests.test_security_lifecycle_web_finding import public_input
 
     text = "\U00020000" * 50000
     if mime == "application/json":
         text = json.dumps({"description": text}, ensure_ascii=False)
     elif mime == "application/xml":
         text = "<description>" + text + "</description>"
     page = replace(source_page(text), mime_type=mime)
     page = replace(page, capture_sha256=_capture_digest(page))
     material = select_source_context(public_input(), page).prompt_material(page)
     assert material["coverage"] == "full_text"
     assert material["passages"][0]["text"] is page.text
     assert material["passages"][0]["end_byte"] == len(text.encode())
diff --git a/tests/test_lifecycle_source_context.py b/tests/test_lifecycle_source_context.py
index 0be160cd..5f06e366 100644
--- a/tests/test_lifecycle_source_context.py
+++ b/tests/test_lifecycle_source_context.py
@@ -71,67 +71,20 @@ def test_citation_must_have_been_in_model_context_not_merely_stored_page():
         "version": 1, "source_text_sha256": page.text_sha256,
         "source_bytes": len(text.encode()), "ranges": [[0, text.index("\n")]],
     }, page)
     checked = validate_finding(public_input(), finding_payload(), {"source-1": page},
                                source_context={"source-1": context.to_material()})
     assert checked.action is None
     assert "source_citation_not_supplied" in checked.block_reasons
     assert checked.passages == ()
     # Original full-source journal entries remain readable and actionable.
     assert validate_finding(public_input(), finding_payload(), {"source-1": page}).action == "terminal_delisting"
 
 
 def test_json_metadata_cannot_stand_in_for_a_listing_notice():
     from src.security_lifecycle_web_finding import validate_finding
     from src.lifecycle_public_sources import _capture_digest
 
     page = replace(source_page(NOTICE), mime_type="application/json")
     page = replace(page, capture_sha256=_capture_digest(page))
     finding = validate_finding(public_input(), finding_payload(), {"source-1": page})
     assert finding.action is None and "source_metadata_not_notice" in finding.block_reasons
-
-
-def test_web_journal_retains_context_ranges_and_full_source_after_reopen(tmp_path, monkeypatch):
-    from src.lifecycle_source_context import select_source_context
-    from tests.test_lifecycle_web_store import setup_store, completed
-
-    path, store = setup_store(tmp_path)
-    original = store.complete
-    material = {"source-1": select_source_context(public_input(), source_page(NOTICE)).to_material()}
-    monkeypatch.setattr(store, "complete", lambda *args, **kwargs: original(*args, **kwargs, source_context=material))
-    identity = completed(store)
-    from src.lifecycle_web_store import LifecycleWebStore
-    row = LifecycleWebStore(path).read(identity)
-    assert row["source_context"] == material
-    assert row["pages"]["source-1"].text == NOTICE
-    assert row["finding"].action == "terminal_delisting"
-    from src.lifecycle_web_projection import project_web_run
-    projected = project_web_run(row, at="2026-09-07T00:00:00Z")
-    assert projected["source_reading"] == {"sources": 1, "selected_sources": 0,
-                                            "retained_text_bytes": len(NOTICE.encode()), "model_text_bytes": len(NOTICE.encode())}
-    assert page_private_data_absent(projected)
-
-
-def page_private_data_absent(projected):
-    encoded = json.dumps(projected)
-    return not any(value in encoded for value in ("source_text_sha256", "ranges", "page_json", "worker-1", "local:7"))
-
-
-@pytest.mark.parametrize("value", [None, [], {"source-1": None}, {}])
-def test_present_but_malformed_journal_context_is_not_treated_as_legacy_full_text(tmp_path, value):
-    from tests.test_lifecycle_web_store import setup_store, completed
-    from src.lifecycle_journal_codec import canonical_json, digest_json
-
-    _, store = setup_store(tmp_path)
-    identity = completed(store)
-    with store.connection(write=True) as conn:
-        row = conn.execute("SELECT payload_json FROM lifecycle_web_results WHERE run_id=?", (identity,)).fetchone()
-        material = json.loads(row[0])
-        material["source_context"] = value
-        from src.lifecycle_web_schema import TRIGGERS
-        trigger = "lifecycle_web_results_update_immutable"
-        conn.execute("DROP TRIGGER " + trigger)
-        conn.execute("UPDATE lifecycle_web_results SET payload_json=?,result_sha256=? WHERE run_id=?",
-                     (canonical_json(material), digest_json(material), identity))
-        conn.execute(TRIGGERS[trigger])
-    with pytest.raises(ValueError, match="^source_context_invalid$"):
-        store.read(identity)
diff --git a/tests/test_lifecycle_source_progress.py b/tests/test_lifecycle_source_progress.py
index 56e37420..2e2e1530 100644
--- a/tests/test_lifecycle_source_progress.py
+++ b/tests/test_lifecycle_source_progress.py
@@ -1,191 +1,118 @@
-import sqlite3
+"""Source snapshots and caller transactions are owned by the current journal."""
+
 from concurrent.futures import ThreadPoolExecutor
+import sqlite3
 from threading import Event
-import time
 
 import pytest
 
-from tests.test_lifecycle_web_store import AT, completed, setup_store, start
-from tests.test_security_lifecycle_web_finding import source_page
+from src.lifecycle_investigation import adoption
+from src.lifecycle_investigation.sources import capture_text
+from src.security_lifecycle_provider_snapshot import instant
+from tests.test_lifecycle_investigation_attended_concurrency import observe_source_work
+from tests.test_lifecycle_investigation_review import context
+from tests.test_lifecycle_investigation_store import running
 
 
-@pytest.mark.parametrize("write", [False, True])
-def test_web_journal_wait_is_bounded_below_the_unchanged_lease(tmp_path, write):
-    from src.lifecycle_web_store import LEASE_SECONDS
+def source(text):
+    return capture_text(text, url="https://issuer.example/notice",
+        retrieved_at="2026-09-08T00:00:00Z", coverage="full_text")
+
 
-    _, store = setup_store(tmp_path)
+@pytest.mark.parametrize("write", [False, True])
+def test_current_journal_wait_is_bounded_below_the_lease(tmp_path, write):
+    _, store, identity, _ = running(tmp_path)
+    row = store.read(identity)
+    lease_seconds = (instant(row["lease_until"]) - instant(row["created_at"])).total_seconds()
     with store.connection(write=write) as conn:
-        assert conn.execute("PRAGMA busy_timeout").fetchone()[0] == 45_000
-    assert LEASE_SECONDS == 60
+        timeout_seconds = conn.execute("PRAGMA busy_timeout").fetchone()[0] / 1000
+    assert 0 < timeout_seconds < lease_seconds
 
 
 @pytest.mark.parametrize("competing_write", ["commit", "cancel", "busy"])
-def test_web_journal_wait_preserves_owner_cancellation_and_failure(tmp_path, monkeypatch, competing_write):
-    from src.lifecycle_web_store import WebJournalError
-
-    path, store = setup_store(tmp_path)
-    identity = start(store)["run_id"]
+def test_current_journal_wait_preserves_cancellation_and_failure(tmp_path, monkeypatch, competing_write):
+    c, store, identity, _ = running(tmp_path)
     connect, waiting = sqlite3.connect, Event()
-
     def scaled_connection(*args, **kwargs):
-        # Exercise real SQLite contention at 1/100 of the configured wait.
-        kwargs["timeout"] *= 0.01
+        kwargs["timeout"] *= 0.03
         conn = connect(*args, **kwargs)
         conn.set_trace_callback(lambda sql: waiting.set() if sql == "BEGIN IMMEDIATE" else None)
         return conn
-
-    with connect(path) as competing:
+    with connect(c["profile"]) as competing:
         competing.execute("BEGIN IMMEDIATE")
         if competing_write == "cancel":
-            competing.execute("UPDATE lifecycle_web_runs SET cancel_requested_at=? WHERE run_id=?", (AT, identity))
+            competing.execute("UPDATE lifecycle_investigation_jobs SET cancel_requested_at=? WHERE run_id=?", (c["now"][0], identity))
         monkeypatch.setattr(sqlite3, "connect", scaled_connection)
         with ThreadPoolExecutor(max_workers=1) as worker:
-            future = worker.submit(store.heartbeat, identity, owner="worker-1")
-            assert waiting.wait(5)
+            future = worker.submit(store.heartbeat, identity, owner="worker")
+            assert waiting.wait(3)
             if competing_write == "busy":
-                with pytest.raises(WebJournalError, match="^web_recording_unavailable$"):
+                with pytest.raises(ValueError, match="^investigation_recording_unavailable$"):
                     future.result(timeout=2)
             else:
-                time.sleep(0.15)
                 competing.commit()
                 assert future.result(timeout=2) is (competing_write == "cancel")
-    assert store.read(identity)["calls"] == {}
-
-
-def test_historical_projection_does_not_decode_running_source_bodies(tmp_path, monkeypatch):
-    from src.lifecycle_web_projection import latest_web_runs
-    from src.lifecycle_web_store import LifecycleWebStore
-
-    path, store = setup_store(tmp_path)
-    identity = start(store)["run_id"]
-    store.add_page(identity, owner="worker-1", source_id="source-1", page=source_page("Retained source."))
-
-    def forbidden(row):
-        raise AssertionError("progress must not decode uncompleted source bodies")
-
-    monkeypatch.setattr(LifecycleWebStore, "_decode_page", staticmethod(forbidden))
-    with sqlite3.connect(path) as conn:
-        rows = latest_web_runs(conn, ["case-1"], at=AT)
-    assert len(rows) == 1
-    result = rows[0]
-    assert result["status"] == "queued"
-    assert result["finding"] is result["source_reading"] is result["source_requests"] is None
-    assert result["model_submissions"] == 0
-
-
-def test_source_read_decoding_releases_its_owned_read_transaction(tmp_path, monkeypatch):
-    from src.lifecycle_web_store import LifecycleWebStore
-
-    path, store = setup_store(tmp_path)
-    identity = completed(store)
-    original, observed = LifecycleWebStore._decode_page, []
-
-    def decode(row):
-        with sqlite3.connect(path, timeout=0) as conn:
-            conn.execute("UPDATE lifecycle_web_runs SET lease_until=lease_until")
-        observed.append(True)
-        return original(row)
-
-    monkeypatch.setattr(LifecycleWebStore, "_decode_page", staticmethod(decode))
-    assert store.read(identity)["finding"].action == "terminal_delisting"
-    assert observed == [True]
-
-
-def test_source_read_validation_releases_its_owned_read_transaction(tmp_path, monkeypatch):
-    from src import lifecycle_web_store as journal
-
-    path, store = setup_store(tmp_path)
-    identity = completed(store)
-    original, observed = journal.validate_finding, []
-
-    def validate(*args, **kwargs):
-        with sqlite3.connect(path, timeout=0) as conn:
-            conn.execute("UPDATE lifecycle_web_runs SET lease_until=lease_until")
-        observed.append(True)
-        return original(*args, **kwargs)
-
-    monkeypatch.setattr(journal, "validate_finding", validate)
-    assert store.read(identity)["finding"].action == "terminal_delisting"
-    assert observed == [True]
-
-
-def test_transaction_bound_adoption_read_retains_caller_atomicity(tmp_path, monkeypatch):
-    from src import lifecycle_web_store as journal
-
-    path, store = setup_store(tmp_path)
-    identity = completed(store)
-    original, observed = journal.validate_finding, []
-
-    def validate(*args, **kwargs):
-        with sqlite3.connect(path, timeout=0) as other:
+    assert store.read(identity)["calls"] == []
+
+
+def test_current_source_read_decoding_releases_its_owned_read_transaction(tmp_path, monkeypatch):
+    c, store, identity, _ = running(tmp_path)
+    store.source(identity, owner="worker", source_id="source-1", payload=source("First retained source."))
+    with sqlite3.connect(c["profile"]) as conn:
+        assert conn.execute("PRAGMA journal_mode=DELETE").fetchone()[0] == "delete"
+    observed = []
+    def heartbeat():
+        observed.append(store.heartbeat(identity, owner="worker"))
+    observe_source_work(monkeypatch, heartbeat)
+    assert store.read(identity)["sources"]["source-1"]["text"] == "First retained source."
+    assert observed == [False]
+
+
+def test_current_transaction_bound_adoption_read_retains_caller_atomicity(tmp_path, monkeypatch):
+    c = context(tmp_path)
+    observed = []
+    def blocked_writer():
+        with sqlite3.connect(c["profile"], timeout=0) as other:
             with pytest.raises(sqlite3.OperationalError, match="locked"):
-                other.execute("UPDATE lifecycle_web_runs SET lease_until=lease_until")
+                other.execute("BEGIN IMMEDIATE")
         observed.append(True)
-        return original(*args, **kwargs)
-
-    monkeypatch.setattr(journal, "validate_finding", validate)
-    with store.connection(write=True) as conn:
-        assert store.read_on_connection(conn, identity)["finding"].action == "terminal_delisting"
+    observe_source_work(monkeypatch, blocked_writer, phase="finding")
+    with c["investigation"].connection(write=True) as conn:
+        assert adoption.read_on_connection(conn, c["run_id"])["finding"].action == "terminal_delisting"
         assert conn.in_transaction
     assert observed == [True]
 
 
-def test_connection_reader_does_not_hold_page_cursor_during_decoding(tmp_path, monkeypatch):
-    from src.lifecycle_web_store import LifecycleWebStore
-
-    path, store = setup_store(tmp_path)
-    identity = start(store)["run_id"]
+def test_current_connection_reader_releases_source_cursor_before_decoding(tmp_path, monkeypatch):
+    c, store, identity, _ = running(tmp_path)
     for index in (1, 2):
-        store.add_page(identity, owner="worker-1", source_id=f"source-{index}", page=source_page("Retained source."))
-    original, observed = LifecycleWebStore._decode_page, []
-
-    def decode(row):
-        with sqlite3.connect(path, timeout=0) as other:
-            other.execute("UPDATE lifecycle_web_runs SET lease_until=lease_until")
-        observed.append(True)
-        return original(row)
-
-    monkeypatch.setattr(LifecycleWebStore, "_decode_page", staticmethod(decode))
-    with sqlite3.connect(path) as conn:
+        store.source(identity, owner="worker", source_id=f"source-{index}", payload=source(f"Retained source {index}."))
+    with sqlite3.connect(c["profile"]) as conn:
+        assert conn.execute("PRAGMA journal_mode=DELETE").fetchone()[0] == "delete"
+    observed = []
+    observe_source_work(monkeypatch, lambda: observed.append(store.heartbeat(identity, owner="worker")))
+    with sqlite3.connect(c["profile"]) as conn:
         conn.row_factory = sqlite3.Row
         result = store.read_on_connection(conn, identity)
         assert not conn.in_transaction
-    assert len(result["pages"]) == 2 and observed == [True, True]
+    assert len(result["sources"]) == 2 and observed == [False, False]
 
 
-def test_source_read_keeps_snapshot_when_worker_adds_a_later_source(tmp_path, monkeypatch):
-    from src.lifecycle_web_store import LifecycleWebStore
-
-    _, store = setup_store(tmp_path)
-    identity = start(store)["run_id"]
-    store.add_page(identity, owner="worker-1", source_id="source-1", page=source_page("First source."))
-    original, added = LifecycleWebStore._decode_page, []
-
-    def decode(row):
+def test_current_source_read_keeps_snapshot_when_worker_adds_a_later_source(tmp_path, monkeypatch):
+    c, store, identity, _ = running(tmp_path)
+    store.source(identity, owner="worker", source_id="source-1", payload=source("First source."))
+    with sqlite3.connect(c["profile"]) as conn:
+        assert conn.execute("PRAGMA journal_mode=DELETE").fetchone()[0] == "delete"
+    added = []
+    def add_later():
         if not added:
             added.append(True)
-            store.add_page(identity, owner="worker-1", source_id="source-2", page=source_page("Later source."))
-            store.set_phase(identity, owner="worker-1", phase="reading_sources")
-        return original(row)
-
-    monkeypatch.setattr(LifecycleWebStore, "_decode_page", staticmethod(decode))
+            store.source(identity, owner="worker", source_id="source-2", payload=source("Later source."))
+            store.step(identity, owner="worker", kind="source_captured", payload={"source_id": "source-2"})
+    observe_source_work(monkeypatch, add_later)
     before = store.read(identity)
-    assert before["status"] == "queued" and set(before["pages"]) == {"source-1"}
+    assert before["phase"] == "queued" and before["steps"] == []
+    assert set(before["sources"]) == {"source-1"}
     after = store.read(identity)
-    assert after["status"] == "reading_sources" and set(after["pages"]) == {"source-1", "source-2"}
-
-
-def test_terminal_historical_projection_still_validates_source_integrity(tmp_path, monkeypatch):
-    from src.lifecycle_web_projection import latest_web_runs
-    from src.lifecycle_web_store import LifecycleWebStore, WebJournalError
-
-    path, store = setup_store(tmp_path)
-    completed(store)
-
-    def corrupted(row):
-        raise WebJournalError("web_journal_integrity")
-
-    monkeypatch.setattr(LifecycleWebStore, "_decode_page", staticmethod(corrupted))
-    with sqlite3.connect(path) as conn:
-        with pytest.raises(WebJournalError, match="^web_journal_integrity$"):
-            latest_web_runs(conn, ["case-1"], at=AT)
+    assert after["phase"] == "source_captured"
+    assert set(after["sources"]) == {"source-1", "source-2"}
diff --git a/tests/test_lifecycle_source_read_report.py b/tests/test_lifecycle_source_read_report.py
index 7eb9ffb6..b32203e7 100644
--- a/tests/test_lifecycle_source_read_report.py
+++ b/tests/test_lifecycle_source_read_report.py
@@ -1,89 +1,75 @@
+"""Measured source failures survive the real current agent and journal."""
+
 from dataclasses import asdict
 import json
 
 import pytest
 
-from src.lifecycle_public_sources import SourceReadError
+from src.lifecycle_investigation.agent import run_agent
+from src.lifecycle_investigation.news import LocalNews
+from src.lifecycle_investigation.store import InvestigationStore
+from src.lifecycle_public_sources import PublicSourceReader, SourceReadError, SourceReadObservation, validate_source_read_report
+from tests.lifecycle_investigation_fixtures import controller, wait_done
+from tests.test_lifecycle_investigation_agent import choose, completed
+from tests.test_lifecycle_investigation_findings import payload
 from tests.test_lifecycle_public_sources import Response, _reader, deny_real_network
-from tests.test_lifecycle_web_store import setup_store, start
 
 
 def test_all_source_failures_keep_measured_diagnostics_after_journal_reopen(tmp_path, monkeypatch):
-    from src.lifecycle_web_projection import project_web_run
-    from src.lifecycle_web_store import LifecycleWebStore
-
-    path, store = setup_store(tmp_path)
-    run = start(store)
-    control = store.control(run["run_id"], owner="worker-1")
-    reader, connections, _, _ = _reader(monkeypatch, [
+    urls = ["https://issuer.example/notice", "https://issuer.example/second"]
+    _, connections, _, _ = _reader(monkeypatch, [
         Response(b"short", headers={"Content-Length": "1000"}),
         Response(status=403, headers={"Set-Cookie": "do-not-retain-this-secret"}),
     ])
-    control.reserve_model_request("search-1")
-    control.bind_remote_id("search-1", "remote-search")
-    control.observe_terminal("search-1", response_id="remote-search", status="completed", selection=control.selection)
-    for url in [
-        "https://ir.example.com/notice", "https://news.example.com/notice",
-    ]:
-        with pytest.raises(SourceReadError):
-            reader.read(url)
-    assert len(connections) == 2 and reader.request_count == 2
-    report = {"requests": reader.request_count, "observations": [asdict(value) for value in reader.observations]}
-    assert report["observations"][0]["declared_body_bytes"] == 1000
-    assert report["observations"][0]["received_body_bytes"] == 5
-    assert report["observations"][1]["status"] == 403
-    store.fail(run["run_id"], owner="worker-1", code="source_read_incomplete", control=control, source_read_report=report)
-    row = LifecycleWebStore(path).read(run["run_id"])
-    assert row["status"] == "failed" and row["finding"] is None
-    assert row["source_read_report"] == report and row["source_requests"] == 2
-    projected = project_web_run(row, at="2026-09-07T00:00:00Z")
-    assert projected["source_reads"] == report["observations"]
-    assert projected["source_requests"] == 2 and projected["model_submissions"] == 1
-    assert "secret" not in json.dumps(projected)
-    assert projected["finding"] is None
+    calls = []
+    async def model(call, credential, control):
+        calls.append(call)
+        if len(calls) == 1:
+            return completed(call, control, choose("search_web", query="OLD listing status"))
+        if call.phase == "search":
+            return completed(call, control, {"sources": urls, "unresolved_conditions": []})
+        if len(calls) <= 4:
+            return completed(call, control, choose("read_url", url=urls[len(calls) - 3]))
+        finding = {**payload([{"passage_id": "source-1:p1"}]), "event_kind": "unresolved",
+            "timing": "unknown", "citations": [], "effective_date": None, "effective_date_text": None,
+            "summary": "No readable listing evidence.", "unresolved_conditions": ["Trading status is unknown."]}
+        return completed(call, control, choose("conclude", finding=finding))
+    async def runner(*args, **kwargs):
+        return await run_agent(*args, **kwargs, model=model)
+    service, store, loads, binding = controller(tmp_path, runner=runner, reader_factory=PublicSourceReader)
+    service.news_factory = lambda: LocalNews(None, None)
+    try:
+        identity = service.start(binding=binding, request_key="source-failures")["run_id"]
+        result = wait_done(service, identity)
+        assert result["status"] == "incomplete" and result["action"] is None
+        assert len(connections) == result["stats"]["http_requests"] == 2
+        assert all(conn.closed for conn in connections)
+        row = InvestigationStore(store.path).read(identity)
+        reports = [step["payload"] for step in row["steps"] if step["kind"] == "source_read"]
+        assert [report["url"] for report in reports] == urls
+        first, second = [report["observations"][0] for report in reports]
+        assert first["declared_body_bytes"] == 1000 and first["received_body_bytes"] == 5
+        assert first["result_code"] == "source_body_incomplete" and second["status"] == 403
+        assert row["sources"] == {} and row["result"]["validated"]["action"] is None
+        assert {(gap["url"], gap["reason"]) for gap in result["gaps"] if gap["url"]} == {
+            (urls[0], "source_body_incomplete"), (urls[1], "source_unavailable")}
+        assert "do-not-retain-this-secret" not in json.dumps([reports, result])
+        assert len(loads) == 1
+    finally:
+        service.close()
 
 
 @pytest.mark.parametrize("mutate", [
     lambda report: report.update(requests=True),
     lambda report: report.update(requests=9),
     lambda report: report.update(observations={}),
     lambda report: report["observations"][0].update(status="200"),
     lambda report: report["observations"][0].update(headers={"Authorization": "secret"}),
     lambda report: report["observations"][0].update(received_body_bytes=-1),
     lambda report: report["observations"].append(dict(report["observations"][0])),
 ])
-def test_read_report_rejects_malformed_or_extraneous_details(tmp_path, mutate):
-    from src.lifecycle_public_sources import SourceReadObservation
-    _, store = setup_store(tmp_path)
-    run = start(store)
-    control = store.control(run["run_id"], owner="worker-1")
+def test_read_report_rejects_malformed_or_extraneous_details(mutate):
     report = {"requests": 1, "observations": [asdict(SourceReadObservation(1, 403, None, None, None, 0, 0, "source_unavailable"))]}
     mutate(report)
-    with pytest.raises(ValueError, match="^source_read_report_invalid$"):
-        store.fail(run["run_id"], owner="worker-1", code="source_read_incomplete", control=control, source_read_report=report)
-    assert store.read(run["run_id"])["status"] == "queued"
-
-
-def test_population_retains_failure_receipts_without_accepting_them_as_findings(tmp_path):
-    from src.lifecycle_public_sources import SourceReadObservation
-    from src.security_lifecycle_population import read_population_snapshot, build_population_manifest, _digest, LifecyclePopulationUnavailable
-    from tests.test_lifecycle_web_review import context, confirm, prepare
-
-    c = context(tmp_path)
-    confirm(c, prepare(c))
-    store = c["web"]
-    original = store.read(c["run_id"])
-    run = store.start(case_id=c["case_id"], observation_sha256=original["observation_sha256"], request=original["request"],
-                      selection=original["selection"], options=original["options"], owner="worker-1", request_key="failed-read")
-    report = {"requests": 1, "observations": [asdict(SourceReadObservation(1, 403, None, None, None, 0, 0, "source_unavailable"))]}
-    store.fail(run["run_id"], owner="worker-1", code="source_read_incomplete",
-               control=store.control(run["run_id"], owner="worker-1"), source_read_report=report)
-    snapshot = read_population_snapshot(c["market"], c["profile"], at=c["now"][0])
-    retained = build_population_manifest(snapshot)["retention"]["web_journal"]
-    assert run["run_id"] in {item["run_id"] for item in retained["results"]}
-    assert len(retained["acceptances"]) == 1
-    # A receipt for a failed read must never satisfy an adoption dependency.
-    snapshot["material"]["web_journal_inventory"]["acceptances"][0]["run_id"] = run["run_id"]
-    snapshot["sha256"] = _digest({key: snapshot[key] for key in ("version", "at", "material")})
-    with pytest.raises(LifecyclePopulationUnavailable, match="population_web_dependency_invalid"):
-        build_population_manifest(snapshot)
+    with pytest.raises(SourceReadError, match="^source_read_report_invalid$"):
+        validate_source_read_report(report, max_requests=4)
diff --git a/tests/test_lifecycle_web_attended_concurrency.py b/tests/test_lifecycle_web_attended_concurrency.py
deleted file mode 100644
index 0f0007ec..00000000
--- a/tests/test_lifecycle_web_attended_concurrency.py
+++ /dev/null
@@ -1,334 +0,0 @@
-"""Large-source work must not hold the shared profile writer hostage."""
-
-from contextlib import contextmanager
-import sqlite3
-from threading import Event, current_thread
-import time
-
-import pytest
-
-from tests.test_lifecycle_web_review import context, prepare, confirm
-
-
-@pytest.mark.parametrize("phase", ["decode", "finding"])
-@pytest.mark.parametrize("command", ["prepare", "confirm", "execute"])
-def test_attended_web_source_validation_leaves_other_profile_writers_available(tmp_path, monkeypatch, command, phase):
-    from src import lifecycle_web_store as journal
-
-    c = context(tmp_path, future=command == "execute")
-    packet = prepare(c)
-    if command == "execute":
-        scheduled = confirm(c, packet)
-        c["now"][0] = "2026-09-07T15:00:00Z"
-        with sqlite3.connect(c["profile"]) as conn:
-            preview = conn.execute("SELECT approved_preview_sha256 FROM ticker_identity_transitions WHERE transition_id=?",
-                                   (scheduled["transition_id"],)).fetchone()[0]
-    original = journal.LifecycleWebStore._decode_page if phase == "decode" else journal.validate_finding
-    observations = []
-
-    def validate(*args, **kwargs):
-        with sqlite3.connect(c["profile"], timeout=0) as other:
-            other.execute("UPDATE lifecycle_web_runs SET lease_until=lease_until")
-        observations.append("other_writer_committed")
-        return original(*args, **kwargs)
-
-    if phase == "decode":
-        monkeypatch.setattr(journal.LifecycleWebStore, "_decode_page", staticmethod(validate))
-    else:
-        monkeypatch.setattr(journal, "validate_finding", validate)
-    if command == "prepare":
-        result = prepare(c)
-        assert result["ready"] and "OLD" in c["sources"]()
-    elif command == "confirm":
-        result = confirm(c, packet)
-        assert result["status"] == "applied" and "OLD" not in c["sources"]()
-    else:
-        result = c["service"].execute_transition(scheduled["transition_id"], preview_sha256=preview, before_write=lambda: None)
-        assert result["status"] == "applied" and "OLD" not in c["sources"]()
-    assert observations == ["other_writer_committed"]
-    assert "LIVE" in c["sources"]()
-
-
-@pytest.mark.parametrize("change", ["source_added", "terminal_state", "cancellation", "schema_generation"])
-def test_validated_web_read_rechecks_its_binding_inside_the_transaction(tmp_path, change):
-    from dataclasses import asdict
-    from src.lifecycle_web_schema import TRIGGERS, WebJournalError
-    from src.lifecycle_journal_codec import canonical_json, digest_json
-    from tests.test_security_lifecycle_web_finding import source_page
-
-    c = context(tmp_path)
-    read = c["web"].validated_read(c["run_id"])
-    with c["web"].connection(write=True) as conn:
-        if change == "source_added":
-            material = asdict(source_page("A new source not covered by the verified read."))
-            conn.execute("INSERT INTO lifecycle_web_pages VALUES (?,?,?,?)", (c["run_id"], "source-2", canonical_json(material), digest_json(material)))
-        elif change == "terminal_state":
-            conn.execute("UPDATE lifecycle_web_runs SET status='failed',failure_code='web_execution_failed' WHERE run_id=?", (c["run_id"],))
-        elif change == "cancellation":
-            conn.execute("UPDATE lifecycle_web_runs SET cancel_requested_at=? WHERE run_id=?", (c["now"][0], c["run_id"]))
-        else:
-            trigger = "lifecycle_web_pages_update_immutable"
-            conn.execute("DROP TRIGGER " + trigger)
-            conn.execute(TRIGGERS[trigger])
-    with c["web"].connection(write=True) as conn:
-        with pytest.raises(WebJournalError, match="^web_journal_integrity$"):
-            c["web"].read_on_connection(conn, c["run_id"], validated=read)
-        assert conn.in_transaction
-    assert "OLD" in c["sources"]()
-
-
-@pytest.mark.parametrize("when", ["during_validation", "after_validation"])
-def test_page_rewrite_with_unchanged_digest_cannot_reuse_a_verified_read(tmp_path, monkeypatch, when):
-    from src.lifecycle_web_schema import TRIGGERS, WebJournalError
-    from src.lifecycle_web_store import LifecycleWebStore
-
-    c = context(tmp_path)
-    original, changed = LifecycleWebStore._decode_page, []
-
-    def rewrite():
-        with sqlite3.connect(c["profile"]) as conn:
-            trigger = "lifecycle_web_pages_update_immutable"
-            conn.execute("DROP TRIGGER " + trigger)
-            conn.execute("UPDATE lifecycle_web_pages SET page_json='{}' WHERE run_id=?", (c["run_id"],))
-            conn.execute(TRIGGERS[trigger])
-        changed.append(True)
-
-    if when == "during_validation":
-        def decode(row):
-            result = original(row)
-            rewrite()
-            return result
-        monkeypatch.setattr(LifecycleWebStore, "_decode_page", staticmethod(decode))
-        with pytest.raises(WebJournalError, match="^web_journal_integrity$"):
-            c["web"].validated_read(c["run_id"])
-    else:
-        read = c["web"].validated_read(c["run_id"])
-        rewrite()
-        with c["web"].connection(write=True) as conn:
-            with pytest.raises(WebJournalError, match="^web_journal_integrity$"):
-                c["web"].read_on_connection(conn, c["run_id"], validated=read)
-    assert changed == [True] and "OLD" in c["sources"]()
-
-
-@pytest.mark.parametrize("wrong", ["profile", "run", "transaction", "unvalidated_dict"])
-def test_verified_web_material_cannot_cross_its_profile_run_or_transaction(tmp_path, wrong):
-    from src.lifecycle_web_schema import WebJournalError
-
-    c = context(tmp_path)
-    read = c["web"].validated_read(c["run_id"])
-    path = c["profile"]
-    if wrong == "profile":
-        path = tmp_path / "copied-profile.db"
-        with sqlite3.connect(c["profile"]) as source, sqlite3.connect(path) as target:
-            source.backup(target)
-            target.execute(f"PRAGMA schema_version={read.binding[-1]}")
-    with sqlite3.connect(path) as conn:
-        conn.row_factory = sqlite3.Row
-        if wrong != "transaction":
-            conn.execute("BEGIN IMMEDIATE")
-        if wrong == "profile":
-            assert c["web"]._review_binding(conn, c["run_id"]) == read.binding
-        with pytest.raises(WebJournalError, match="^web_journal_integrity$"):
-            c["web"].read_on_connection(conn, "other-run" if wrong == "run" else c["run_id"],
-                validated=read.material if wrong == "unvalidated_dict" else read)
-        assert conn.in_transaction is (wrong != "transaction")
-
-
-@pytest.mark.parametrize("change", ["membership", "open_position", "observation", "active_otc", "stale"])
-def test_prevalidated_sources_do_not_cache_mutable_adoption_authority(tmp_path, monkeypatch, change):
-    from dataclasses import replace
-    from src.lifecycle_web_store import LifecycleWebStore
-    from src.portfolio_state import PortfolioStore
-    from src.profile_state import ProfileStateStore
-    from src.security_lifecycle_listing_evidence import _evidence
-    from tests.test_security_lifecycle_provider_authority import record
-
-    c = context(tmp_path)
-    packet = prepare(c)
-    original, changed = LifecycleWebStore.validated_read, []
-
-    def read(store, identity):
-        result = original(store, identity)
-        assert not changed
-        changed.append(True)
-        if change == "membership":
-            ProfileStateStore(c["profile"]).import_lists([{"name": "New", "kind": "custom", "tickers": ["OLD"]}])
-        elif change == "open_position":
-            portfolio = PortfolioStore(c["profile"])
-            account = portfolio.ensure_manual_account()
-            portfolio.upsert_manual_position(account_id=account.id, symbol="OLD", quantity=1)
-        elif change == "observation":
-            c["now"][0] = "2026-09-06T01:01:00Z"
-            c["checks"].record(ticker="OLD", at=c["now"][0], evidence=(), diagnostics={}, blockers=("massive_unavailable",))
-        elif change == "active_otc":
-            c["checks"].record(ticker="OLD", at=c["now"][0], evidence=[_evidence(replace(
-                record("massive_reference", "active", market="otc"), retrieved_at=c["now"][0]))], diagnostics={})
-        else:
-            c["now"][0] = "2026-09-10T01:00:00Z"
-        return result
-
-    monkeypatch.setattr(LifecycleWebStore, "validated_read", read)
-    with pytest.raises((ValueError, RuntimeError), match="review_changed|web_review_ineligible"):
-        confirm(c, packet)
-    assert changed == [True] and "OLD" in c["sources"]()
-    with sqlite3.connect(c["profile"]) as conn:
-        assert conn.execute("SELECT COUNT(*) FROM lifecycle_web_acceptances").fetchone()[0] == 0
-        assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_assessments").fetchone()[0] == 0
-
-
-def test_permission_is_rechecked_after_expensive_source_validation(tmp_path, monkeypatch):
-    from src.lifecycle_web_store import LifecycleWebStore
-
-    c = context(tmp_path)
-    packet = prepare(c)
-    original, verified, permission_checks = LifecycleWebStore.validated_read, [], []
-    connection, opened_writers = c["service"]._profile_connection, []
-
-    @contextmanager
-    def profile_connection(*, write):
-        if write:
-            opened_writers.append(True)
-        with connection(write=write) as conn:
-            yield conn
-
-    def read(store, identity):
-        result = original(store, identity)
-        verified.append(True)
-        return result
-
-    def before_write():
-        permission_checks.append(bool(verified))
-        if verified:
-            raise PermissionError("permission_revoked_during_validation")
-
-    monkeypatch.setattr(LifecycleWebStore, "validated_read", read)
-    monkeypatch.setattr(c["service"], "_profile_connection", profile_connection)
-    with pytest.raises(PermissionError, match="permission_revoked_during_validation"):
-        confirm(c, packet, before_write=before_write)
-    assert permission_checks == [False, True]
-    assert opened_writers == []
-    with sqlite3.connect(c["profile"]) as conn:
-        assert conn.execute("SELECT COUNT(*) FROM lifecycle_web_acceptances").fetchone()[0] == 0
-    assert "OLD" in c["sources"]()
-
-
-def test_source_validation_is_not_cached_between_user_commands(tmp_path, monkeypatch):
-    from src.lifecycle_web_store import LifecycleWebStore
-
-    c = context(tmp_path)
-    original, decoded = LifecycleWebStore._decode_page, []
-
-    def decode(row):
-        decoded.append(True)
-        return original(row)
-
-    monkeypatch.setattr(LifecycleWebStore, "_decode_page", staticmethod(decode))
-    packet = prepare(c)
-    assert decoded == [True]
-    assert confirm(c, packet)["status"] == "applied"
-    assert decoded == [True, True]
-    assert confirm(c, packet)["status"] == "already_applied"
-    assert decoded == [True, True, True]
-
-
-def test_generic_review_of_a_web_adoption_uses_the_same_verified_read(tmp_path, monkeypatch):
-    from src.lifecycle_web_store import LifecycleWebStore
-
-    c = context(tmp_path, future=True)
-    packet = prepare(c)
-    assert confirm(c, packet)["status"] == "scheduled"
-    original, decoded = LifecycleWebStore._decode_page, []
-
-    def decode(row):
-        with sqlite3.connect(c["profile"], timeout=0) as other:
-            other.execute("UPDATE lifecycle_web_runs SET lease_until=lease_until")
-        decoded.append(True)
-        return original(row)
-
-    monkeypatch.setattr(LifecycleWebStore, "_decode_page", staticmethod(decode))
-    current = c["service"].prepare_review(c["case_id"], assessment_id=packet["assessment_id"], options=c["options"])
-    assert current["packet_sha256"] == packet["packet_sha256"]
-    repeated = c["service"].confirm_review(c["case_id"], assessment_id=packet["assessment_id"],
-        packet_sha256=packet["packet_sha256"], action=packet["action"], options=c["options"], before_write=lambda: None)
-    assert repeated["status"] == "scheduled" and "OLD" in c["sources"]()
-    assert decoded == [True, True]
-
-
-def test_adoption_prevalidation_never_releases_a_callers_transaction(tmp_path):
-    from src.lifecycle_web_review import assessment_id_for, validated_adoption_read
-
-    c = context(tmp_path, future=True)
-    assert confirm(c, prepare(c))["status"] == "scheduled"
-    with c["web"].connection(write=True) as conn:
-        with pytest.raises(RuntimeError, match="^caller_transaction_open$"):
-            validated_adoption_read(c["service"], conn=conn, assessment_id=assessment_id_for(c["run_id"]))
-        assert conn.in_transaction
-
-
-def test_attended_confirmation_cannot_starve_a_real_current_worker(tmp_path, monkeypatch):
-    from src import lifecycle_web_store as journal
-    from src.auth_drivers.lifecycle_web_models import WebCredential
-    from src.lifecycle_investigation.controller import InvestigationController
-    from src.lifecycle_investigation.news import LocalNews
-    from src.lifecycle_investigation.schema import install_journal
-    from src.lifecycle_investigation.store import InvestigationStore
-    from src.lifecycle_investigation.target import TargetPreflight
-    from src.auth_drivers.lifecycle_web_models import credential_generation
-    from tests.lifecycle_investigation_fixtures import completed_runner, synthetic_credentials, wait_done
-    from tests.test_lifecycle_investigation_findings import NOTICE
-    from tests.test_lifecycle_investigation_news import corpus
-
-    c = context(tmp_path)
-    packet = prepare(c)
-    with sqlite3.connect(c["profile"]) as conn:
-        install_journal(conn, at=c["now"][0])
-    credentials, rows, route = synthetic_credentials()
-    preflight = TargetPreflight(c["service"], credential_store=credentials, route_loader=lambda: route)
-    binding, _ = preflight._material("OLD")
-    news_path = corpus(tmp_path, body=NOTICE)
-    store = InvestigationStore(c["profile"], clock=lambda: c["now"][0])
-    started, validating, progress = Event(), Event(), []
-    main_thread = current_thread()
-    original = journal.validate_finding
-    connect = sqlite3.connect
-
-    def scaled_connection(*args, **kwargs):
-        if kwargs.get("timeout") in {journal.JOURNAL_BUSY_SECONDS, 10}:
-            kwargs["timeout"] = 0.05
-        return connect(*args, **kwargs)
-
-    async def runner(*args, **kwargs):
-        started.set()
-        assert validating.wait(3)
-        result = await completed_runner(*args, **kwargs)
-        progress.append("model_and_source_terminal")
-        return result
-
-    controller = InvestigationController(store,
-        credential_loader=lambda selected: WebCredential(selected, api_key="synthetic", generation=credential_generation(rows[0])),
-        news_factory=lambda: LocalNews(news_path, None), runner=runner, heartbeat_seconds=0.02)
-    try:
-        run = controller.start(binding=binding, request_key="other-worker")
-        assert started.wait(3)
-
-        def validate(*args, **kwargs):
-            if current_thread() is main_thread:
-                validating.set()
-                deadline = time.monotonic() + 3
-                while controller.is_local_running(run["run_id"]) and time.monotonic() < deadline:
-                    time.sleep(0.01)
-                assert not controller.is_local_running(run["run_id"])
-                with connect(c["profile"]) as conn:
-                    assert conn.execute("SELECT status,failure_code FROM lifecycle_investigation_jobs WHERE run_id=?", (run["run_id"],)).fetchone() == ("succeeded", None)
-            return original(*args, **kwargs)
-
-        monkeypatch.setattr(sqlite3, "connect", scaled_connection)
-        monkeypatch.setattr(journal, "validate_finding", validate)
-        result = confirm(c, packet)
-        assert result["status"] == "applied"
-        assert wait_done(controller, run["run_id"])["status"] == "succeeded"
-        assert progress == ["model_and_source_terminal"]
-        assert "OLD" not in c["sources"]() and "LIVE" in c["sources"]()
-    finally:
-        validating.set()
-        controller.close()
diff --git a/tests/test_lifecycle_web_gaps.py b/tests/test_lifecycle_web_gaps.py
deleted file mode 100644
index be26a104..00000000
--- a/tests/test_lifecycle_web_gaps.py
+++ /dev/null
@@ -1,233 +0,0 @@
-import json
-import sqlite3
-
-import pytest
-from fastapi import FastAPI
-from fastapi.testclient import TestClient
-
-from src.lifecycle_web_projection import project_web_run
-from src.lifecycle_web_schema import WebJournalError
-from src.security_lifecycle_review import packet_digest, project_packet
-from tests.test_lifecycle_web_review import context, confirm, prepare, rows
-from tests.test_security_lifecycle_web_finding import finding_payload
-
-
-URL = "https://financial-news.example.com/old-listing-update"
-GAPS = [{"url": URL, "reason": "source_unavailable"}]
-COMPLETION = {"source_failures": {"source-2": "source_unavailable"},
-              "source_failure_urls": {"source-2": URL}, "source_requests": 2}
-
-
-@pytest.mark.parametrize("provider,auth", [("openai", "api_key"), ("openai", "chatgpt_oauth"),
-                                          ("anthropic", "api_key"), ("anthropic", "claude_code_oauth")])
-@pytest.mark.parametrize("kind", ["terminal_delisting", "symbol_continuation"])
-def test_gap_disclosure_follows_finding_review_and_explicit_human_receipt(tmp_path, provider, auth, kind):
-    c = context(tmp_path, provider=provider, auth=auth, kind=kind, completion=COMPLETION)
-    before = rows(c)
-    run = c["web"].read(c["run_id"])
-    assert run["source_failure_urls"] == COMPLETION["source_failure_urls"]
-    public = project_web_run(run, at=c["now"][0])
-    packet = prepare(c)
-    assert packet["ready"] and packet["block_reasons"] == []
-    assert public["source_gaps"] == packet["source_gaps"] == project_packet(packet)["source_gaps"] == GAPS
-    assert rows(c) == before and "OLD" in c["sources"]()
-    result = confirm(c, packet)
-    assert result["status"] == "applied"
-    assert ("NEW" in c["sources"]()) == (kind == "symbol_continuation")
-    assert "OLD" not in c["sources"]() and "LIVE" in c["sources"]()
-    with sqlite3.connect(c["profile"]) as conn:
-        receipt, actor = conn.execute("SELECT packet_json,actor FROM lifecycle_web_acceptances").fetchone()
-        assert actor == "attended_user" and json.loads(receipt)["source_gaps"] == GAPS
-        assert conn.execute("SELECT author,acceptance_authority FROM security_lifecycle_assessments").fetchone() == ("human", "human")
-    after = rows(c)
-    assert confirm(c, packet)["status"] == "already_applied" and rows(c) == after
-
-
-@pytest.mark.parametrize("change", ["omitted", "empty", "reason", "url"])
-def test_confirmation_rejects_a_different_gap_disclosure_without_any_write(tmp_path, change):
-    from src.lifecycle_web_review import confirm as adopt
-    c = context(tmp_path, completion=COMPLETION)
-    packet = prepare(c)
-    if change == "omitted":
-        packet.pop("source_gaps")
-    elif change == "empty":
-        packet["source_gaps"] = []
-    else:
-        packet["source_gaps"][0][change] = "source_timeout" if change == "reason" else "https://different.example.com/notice"
-    packet["packet_sha256"] = packet_digest(packet)
-    before = rows(c)
-    with pytest.raises((ValueError, RuntimeError), match="review_changed"):
-        adopt(c["service"], c["run_id"], packet_sha256=packet["packet_sha256"], action=packet["action"],
-              options=c["options"], before_write=lambda: None, acknowledge_source_gaps=True)
-    assert rows(c) == before and "OLD" in c["sources"]()
-
-
-@pytest.mark.parametrize("acknowledgement", ["omitted", False, None, 1, "true"])
-def test_old_or_malformed_confirmation_cannot_apply_unshown_gaps(tmp_path, monkeypatch, acknowledgement):
-    from src.api.routes import lifecycle_investigation as api
-    c = context(tmp_path, completion=COMPLETION)
-    app = FastAPI()
-    app.include_router(api.router)
-    app.dependency_overrides[api.get_ticker_identity_service] = lambda: c["service"]
-    monkeypatch.setattr(api, "require_db_write", lambda *args: None)
-    monkeypatch.setattr(api, "require_profile_state_write", lambda *args: None)
-    with TestClient(app) as client:
-        route = f"/security-lifecycle/investigations/runs/{c['run_id']}"
-        packet = client.get(route + "/review").json()
-        assert packet["ready"] and packet["source_gaps"] == GAPS
-        body = {"packet_sha256": packet["packet_sha256"], "action": packet["action"], **packet["options"]}
-        if acknowledgement != "omitted":
-            body["acknowledge_source_gaps"] = acknowledgement
-        before = rows(c)
-        response = client.post(route + "/confirm", json=body)
-        assert response.status_code == (409 if acknowledgement in ("omitted", False) else 422), response.text
-        if acknowledgement in ("omitted", False):
-            assert response.json()["detail"]["code"] == "web_source_gaps_not_acknowledged"
-        assert rows(c) == before and "OLD" in c["sources"]()
-        accepted = client.post(route + "/confirm", json={**body, "acknowledge_source_gaps": True})
-        assert accepted.status_code == 200 and accepted.json()["status"] == "applied", accepted.text
-        assert "OLD" not in c["sources"]() and "LIVE" in c["sources"]()
-
-
-@pytest.mark.parametrize("acknowledgement", [False, None, 1, "true"])
-def test_direct_adoption_requires_literal_gap_acknowledgement(tmp_path, acknowledgement):
-    from src.lifecycle_web_review import confirm as adopt
-    c = context(tmp_path, completion=COMPLETION)
-    packet = prepare(c)
-    before = rows(c)
-    with pytest.raises(WebJournalError, match="web_source_gaps_not_acknowledged"):
-        adopt(c["service"], c["run_id"], packet_sha256=packet["packet_sha256"], action=packet["action"],
-              options=c["options"], before_write=lambda: None, acknowledge_source_gaps=acknowledgement)
-    assert rows(c) == before and "OLD" in c["sources"]()
-
-
-@pytest.mark.parametrize("failed", [False, True])
-def test_gap_acknowledgement_never_substitutes_for_a_completed_investigation(tmp_path, failed):
-    from src.lifecycle_web_review import confirm as adopt
-    c = context(tmp_path)
-    row = c["web"].read(c["run_id"])
-    identity = c["web"].start(case_id=c["case_id"], observation_sha256=row["observation_sha256"], request=row["request"],
-        selection=row["selection"], options=row["options"], owner="worker-2", request_key="no-finding")["run_id"]
-    if failed:
-        c["web"].fail(identity, owner="worker-2", code="source_read_incomplete", control=c["web"].control(identity, owner="worker-2"))
-    before = rows(c)
-    with pytest.raises(ValueError, match="web_finding_not_complete"):
-        adopt(c["service"], identity, packet_sha256="a" * 64, action="terminal_delisting", options=c["options"],
-              before_write=lambda: None, acknowledge_source_gaps=True)
-    assert rows(c) == before and "OLD" in c["sources"]()
-
-
-@pytest.mark.parametrize("change,reason", [
-    ({"contradictions": ["The exchange reports continued trading."]}, "material_contradiction"),
-    ({"unresolved_conditions": ["The effective date cannot be established."]}, "finding_incomplete"),
-    ({"effective_date": None, "effective_date_text": None}, "effective_date_missing"),
-    ({"source_ticker": "OTHER"}, "security_identity_mismatch"),
-    ({"citations": []}, "source_passage_missing"),
-])
-def test_disclosed_read_gap_does_not_override_missing_essential_proof(tmp_path, change, reason):
-    c = context(tmp_path, completion={**COMPLETION, "payload": finding_payload(**change)})
-    before = rows(c)
-    packet = prepare(c)
-    assert not packet["ready"] and reason in packet["block_reasons"]
-    assert packet["source_gaps"] == GAPS
-    assert packet["action"] is None
-    assert rows(c) == before and "OLD" in c["sources"]()
-
-
-@pytest.mark.parametrize("urls", [None, [], {}, {"source-3": URL}, {"source-2": None},
-                                 {"source-2": "https://127.0.0.1/private"},
-                                 {"source-2": "https://user:secret@example.com/private"}])
-def test_present_malformed_gap_metadata_is_not_treated_as_legacy_absence(tmp_path, urls):
-    with pytest.raises(WebJournalError, match="web_source_gaps_invalid"):
-        context(tmp_path, completion={**COMPLETION, "source_failure_urls": urls})
-
-
-@pytest.mark.parametrize("value", [None, [], {}, {"source-2": "http://plain.example.com/notice"}])
-def test_reopened_journal_rejects_malformed_gap_urls_even_with_a_valid_payload_hash(tmp_path, value):
-    from src.lifecycle_web_schema import TRIGGERS
-    from src.lifecycle_journal_codec import canonical_json, digest_json
-    c = context(tmp_path, completion=COMPLETION)
-    with c["web"].connection(write=True) as conn:
-        saved = json.loads(conn.execute("SELECT payload_json FROM lifecycle_web_results").fetchone()[0])
-        saved["source_failure_urls"] = value
-        trigger = "lifecycle_web_results_update_immutable"
-        conn.execute("DROP TRIGGER " + trigger)
-        conn.execute("UPDATE lifecycle_web_results SET payload_json=?,result_sha256=?", (canonical_json(saved), digest_json(saved)))
-        conn.execute(TRIGGERS[trigger])
-    with pytest.raises(WebJournalError, match="web_source_gaps_invalid"):
-        c["web"].read(c["run_id"])
-    assert "OLD" in c["sources"]()
-
-
-@pytest.mark.parametrize("failures,urls", [
-    ({"source-1": "source_unavailable"}, {"source-1": URL}),
-    ({"source-2": "source_unavailable", "source-3": "source_read_timeout"}, {"source-2": URL, "source-3": URL + "-second"}),
-    ({"source-2": "raw exception: token=not-public"}, {"source-2": URL}),
-    ({2: "source_unavailable"}, {2: URL}),
-    ({"source-2": None}, {"source-2": URL}),
-])
-def test_gap_metadata_cannot_relabel_read_pages_exceed_source_count_or_export_raw_errors(tmp_path, failures, urls):
-    with pytest.raises(WebJournalError, match="web_source_gaps_invalid"):
-        context(tmp_path, completion={**COMPLETION, "source_failures": failures, "source_failure_urls": urls})
-
-
-@pytest.mark.parametrize("strip", [False, True])
-def test_central_writer_rechecks_gap_disclosure_even_if_an_acceptance_is_resigned(tmp_path, monkeypatch, strip):
-    from src import lifecycle_web_review as mod
-    from src.ticker_identity_transition import TickerIdentityTransitionStore
-    c = context(tmp_path, future=True, completion=COMPLETION)
-    result = confirm(c, prepare(c))
-    read_acceptance = mod.acceptance_for
-
-    def changed(conn, assessment_id):
-        accepted = read_acceptance(conn, assessment_id)
-        packet = accepted["packet"]
-        if strip:
-            packet.pop("source_gaps")
-        else:
-            packet["source_gaps"] = []
-        accepted["packet_sha256"] = packet["packet_sha256"] = packet_digest(packet)
-        return accepted
-
-    with sqlite3.connect(c["profile"]) as conn:
-        store = TickerIdentityTransitionStore(conn, clock=lambda: c["now"][0])
-        preview = store.get(result["transition_id"])["approved_preview"]
-        assert store._provider_guard(preview, at=c["now"][0], automation=False) == ()
-        monkeypatch.setattr(mod, "acceptance_for", changed)
-        # No confirmation argument here: the stored disclosure must stand on
-        # its own at the writer, not merely rely on a UI-supplied digest.
-        assessment = mod.SecurityLifecycleInvestigationStore(conn).get_assessment(preview["assessment_id"])
-        blockers = mod.web_transition_guard(conn, assessment=assessment, observation_sha256=preview["observation_fingerprint_sha256"],
-            transition_kind=preview["transition_kind"], successor_ticker=preview["successor_ticker"], at=c["now"][0])
-        assert "web_acceptance_invalid" in blockers
-    assert "OLD" in c["sources"]()
-
-
-def test_current_active_otc_evidence_still_vetoes_attended_adoption_with_read_gaps(tmp_path):
-    from src.security_lifecycle_listing_evidence import _evidence
-    from tests.test_security_lifecycle_provider_authority import record
-    c = context(tmp_path, completion=COMPLETION)
-    c["checks"].record(ticker="OLD", at=c["now"][0], evidence=[_evidence(record("massive_reference", "active", market="otc"))],
-                       diagnostics={}, blockers=("massive_unavailable",))
-    packet = prepare(c)
-    assert not packet["ready"] and "web_active_listing_conflict" in packet["block_reasons"]
-    assert packet["source_gaps"] == GAPS and "OLD" in c["sources"]()
-
-
-def test_legacy_read_gap_is_visible_without_inventing_a_source_url(tmp_path):
-    c = context(tmp_path, completion={"source_failures": {"source-2": "source_unavailable"}, "source_requests": 2})
-    packet = prepare(c)
-    assert packet["ready"] and packet["source_gaps"] == [{"url": None, "reason": "source_unavailable"}]
-    assert project_web_run(c["web"].read(c["run_id"]), at=c["now"][0])["source_gaps"] == packet["source_gaps"]
-    assert confirm(c, packet)["status"] == "applied"
-
-
-def test_no_gaps_is_an_empty_list_not_unknown_and_no_extra_internal_fields_escape(tmp_path):
-    c = context(tmp_path, completion={"source_failure_urls": {}})
-    run = project_web_run(c["web"].read(c["run_id"]), at=c["now"][0])
-    assert run["source_gaps"] == [] and project_packet(prepare(c))["source_gaps"] == []
-    c2 = context(tmp_path / "with-gap", completion=COMPLETION)
-    material = project_packet(prepare(c2))
-    assert material["source_gaps"] == GAPS
-    assert set(material["source_gaps"][0]) == {"url", "reason"}
-    assert "source_failure_urls" not in material and "source_failures" not in material and "web" not in material
diff --git a/tests/test_lifecycle_web_migration.py b/tests/test_lifecycle_web_migration.py
deleted file mode 100644
index ef9ce639..00000000
--- a/tests/test_lifecycle_web_migration.py
+++ /dev/null
@@ -1,80 +0,0 @@
-import sqlite3
-import stat
-
-import pytest
-
-from tests.test_lifecycle_web_store import AT, setup_store
-
-
-def test_web_installation_has_digest_bound_backup_and_keeps_all_existing_rows(tmp_path):
-    from src.lifecycle_web_migration import preview_web_installation, apply_web_installation
-    from src.lifecycle_web_schema import verify_web_journal
-    path, _ = setup_store(tmp_path, install=False)
-    with sqlite3.connect(path) as conn:
-        conn.execute("CREATE TABLE unrelated_payload(id INTEGER PRIMARY KEY, raw BLOB)")
-        conn.execute("INSERT INTO unrelated_payload VALUES (1,?)", (b"opaque-private-fixture",))
-    before = preview_web_installation(path)
-    backup = tmp_path / "backup.db"
-    result = apply_web_installation(path, backup_path=backup, approval_sha256=before["approval_sha256"], at=AT, app_stopped=True)
-    assert result["changed"] and result["previous_rows_sha256"] == before["rows_sha256"]
-    assert stat.S_IMODE(backup.stat().st_mode) == 0o600
-    assert preview_web_installation(backup) == before
-    assert "opaque-private" not in str(result) and len(result["backup_sha256"]) == 64
-    with sqlite3.connect(path) as conn:
-        verify_web_journal(conn)
-        assert conn.execute("SELECT raw FROM unrelated_payload").fetchone()[0] == b"opaque-private-fixture"
-    current = preview_web_installation(path)
-    assert apply_web_installation(path, backup_path=tmp_path / "unused.db", approval_sha256=current["approval_sha256"], at=AT, app_stopped=True)["changed"] is False
-    assert not (tmp_path / "unused.db").exists()
-
-
-def test_web_installation_requires_stopped_app_before_opening_any_store(tmp_path):
-    from src.lifecycle_web_migration import apply_web_installation
-    with pytest.raises(ValueError, match="web_installation_app_stop_required"):
-        apply_web_installation(tmp_path / "missing.db", backup_path=tmp_path / "backup.db", approval_sha256="a" * 64, at=AT, app_stopped=False)
-    assert not tuple(tmp_path.iterdir())
-
-
-@pytest.mark.parametrize("change", ["before_backup", "after_backup", "backup_exists"])
-def test_web_installation_rejects_changed_approval_and_never_overwrites_a_backup(tmp_path, monkeypatch, change):
-    from src import lifecycle_web_migration as module
-    path, _ = setup_store(tmp_path, install=False)
-    before = module.preview_web_installation(path)
-    backup = tmp_path / "backup.db"
-    def mutate():
-        with sqlite3.connect(path) as conn:
-            conn.execute("UPDATE security_lifecycle_cases SET updated_at='changed'")
-    if change == "before_backup":
-        mutate()
-    elif change == "backup_exists":
-        backup.write_bytes(b"must-retain")
-    else:
-        original = module._backup
-        def changed(*args, **kwargs):
-            result = original(*args, **kwargs)
-            mutate()
-            return result
-        monkeypatch.setattr(module, "_backup", changed)
-    with pytest.raises((ValueError, FileExistsError)):
-        module.apply_web_installation(path, backup_path=backup, approval_sha256=before["approval_sha256"], at=AT, app_stopped=True)
-    if change == "backup_exists":
-        assert backup.read_bytes() == b"must-retain"
-    with sqlite3.connect(path) as conn:
-        assert not conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name LIKE 'lifecycle_web_%'").fetchone()
-
-
-def test_web_installation_rolls_back_all_new_schema_on_failure_and_preserves_backup(tmp_path, monkeypatch):
-    from src import lifecycle_web_migration as module
-    from src import lifecycle_web_schema as schema
-    path, _ = setup_store(tmp_path, install=False)
-    before = module.preview_web_installation(path)
-    backup = tmp_path / "backup.db"
-    original = schema.verify_web_journal
-    def fail(conn):
-        original(conn)
-        raise ValueError("synthetic_postflight_failure")
-    monkeypatch.setattr(schema, "verify_web_journal", fail)
-    with pytest.raises(ValueError, match="synthetic_postflight_failure"):
-        module.apply_web_installation(path, backup_path=backup, approval_sha256=before["approval_sha256"], at=AT, app_stopped=True)
-    assert module.preview_web_installation(path) == before
-    assert module.preview_web_installation(backup) == before
diff --git a/tests/test_lifecycle_web_read.py b/tests/test_lifecycle_web_read.py
deleted file mode 100644
index 2372d6b3..00000000
--- a/tests/test_lifecycle_web_read.py
+++ /dev/null
@@ -1,103 +0,0 @@
-import json
-import socket
-import sqlite3
-
-import pytest
-
-from src.security_lifecycle_population import LifecyclePopulationUnavailable
-from tests.test_lifecycle_web_review import context, confirm, prepare, rows
-
-
-@pytest.fixture(autouse=True)
-def no_network(monkeypatch):
-    def denied(*args, **kwargs):
-        raise AssertionError("web_read_must_not_dispatch")
-    monkeypatch.setattr(socket.socket, "connect", denied)
-    monkeypatch.setattr(socket.socket, "connect_ex", denied)
-
-
-def current(c):
-    service = c["service"]._read_service
-    listing = service.list_current_reviews(at=c["now"][0], case_id=c["case_id"])
-    assert len(listing["items"]) == 1
-    return service.get_current_review(listing["items"][0]["review_id"], at=c["now"][0])
-
-
-@pytest.mark.parametrize("provider,auth", [("openai", "api_key"), ("openai", "chatgpt_oauth"),
-                                          ("anthropic", "api_key"), ("anthropic", "claude_code_oauth")])
-@pytest.mark.parametrize("with_gap", [False, True])
-def test_research_and_current_detail_share_readonly_web_findings_for_every_auth(tmp_path, monkeypatch, provider, auth, with_gap):
-    from src.tools import security_lifecycle_tools as tools
-    from tests.test_lifecycle_web_gaps import COMPLETION, GAPS
-    c = context(tmp_path, provider=provider, auth=auth, completion=COMPLETION if with_gap else None)
-    before = rows(c)
-    detail = current(c)
-    result = detail["web_runs"][0]
-    assert result["execution"] == {"provider": provider, "auth_mode": auth, "model": c["web"].read(c["run_id"])["selection"].model}
-    assert result["run_id"] == c["run_id"] and result["finding"]["action"] == "terminal_delisting"
-    assert result["finding"]["citations"][0]["quote"]
-    assert result["model_submissions"] == 2
-    assert result["source_gaps"] == (GAPS if with_gap else [])
-    monkeypatch.setattr(tools, "_profile_db_path", lambda: str(c["profile"]))
-    monkeypatch.setattr(tools, "resolve_market_db_path", lambda: str(c["market"]))
-    monkeypatch.setattr(tools, "SecurityLifecycleReadService", lambda **kwargs: c["service"]._read_service)
-    research = tools.get_security_lifecycle_review(detail["item"]["review_id"])
-    assert research["status"] == "ok" and research["web_runs"] == detail["web_runs"]
-    encoded = json.dumps(detail)
-    for private in ("local:7", "worker-1", "header_json", "header_sha256", "page_sha256", "credential_generation", "remote_id"):
-        assert private not in encoded
-    assert rows(c) == before and "OLD" in c["sources"]()
-    confirm(c, prepare(c))
-    after = current(c)
-    assert after["web_runs"] == detail["web_runs"]
-    assert after["item"]["next_action"]["state"] == "applied"
-    assert after["item"]["collection"]["state"] == "not_tracking"
-
-
-def test_population_retains_web_sources_and_human_adoption_without_exporting_pages_or_credentials(tmp_path):
-    c = context(tmp_path)
-    confirm(c, prepare(c))
-    before = rows(c)
-    manifest = c["service"]._read_service.population_manifest(at=c["now"][0])
-    web = manifest["retention"]["web_journal"]
-    assert web["installed"] is True
-    assert web["runs"][0]["run_id"] == c["run_id"] and web["runs"][0]["case_id"] == c["case_id"]
-    assert web["acceptances"][0]["run_id"] == c["run_id"]
-    assert len(web["pages"]) == 1 and len(web["pages"][0]["page_sha256"]) == 64
-    assert len(web["calls"]) == 2 and web["results"][0]["run_id"] == c["run_id"]
-    assert not manifest["deletion_authorized"] and not manifest["retention"]["deletion_candidates"]
-    for private in ("local:7", "worker-1", "header_json", "page_json", "payload_json", "packet_json"):
-        assert private not in json.dumps(web)
-    assert rows(c) == before
-
-
-def test_missing_journal_is_empty_but_malformed_installed_journal_is_not_silently_dropped(tmp_path):
-    from tests.test_security_lifecycle_terminal_workflow import setup_workflow
-    c = setup_workflow(tmp_path)
-    assert current(c)["web_runs"] == []
-    with sqlite3.connect(c["profile"]) as conn:
-        conn.execute("CREATE TABLE lifecycle_web_runs (run_id TEXT)")
-    with pytest.raises(LifecyclePopulationUnavailable):
-        current(c)
-
-
-def test_population_rejects_orphaned_web_adoption_dependency(tmp_path):
-    from src.security_lifecycle_population import _digest, build_population_manifest, read_population_snapshot
-    c = context(tmp_path)
-    confirm(c, prepare(c))
-    snapshot = read_population_snapshot(c["market"], c["profile"], at=c["now"][0])
-    snapshot["material"]["web_journal_inventory"]["acceptances"][0]["assessment_id"] = "missing"
-    snapshot["sha256"] = _digest({key: snapshot[key] for key in ("version", "at", "material")})
-    with pytest.raises(LifecyclePopulationUnavailable, match="population_web_dependency_invalid"):
-        build_population_manifest(snapshot)
-
-
-@pytest.mark.parametrize("value", [None, [], {}, {"installed": False}])
-def test_population_does_not_treat_a_malformed_web_inventory_as_absent(tmp_path, value):
-    from src.security_lifecycle_population import _digest, build_population_manifest, read_population_snapshot
-    c = context(tmp_path)
-    snapshot = read_population_snapshot(c["market"], c["profile"], at=c["now"][0])
-    snapshot["material"]["web_journal_inventory"] = value
-    snapshot["sha256"] = _digest({key: snapshot[key] for key in ("version", "at", "material")})
-    with pytest.raises(LifecyclePopulationUnavailable):
-        build_population_manifest(snapshot)
diff --git a/tests/test_lifecycle_web_review.py b/tests/test_lifecycle_web_review.py
deleted file mode 100644
index e7322963..00000000
--- a/tests/test_lifecycle_web_review.py
+++ /dev/null
@@ -1,243 +0,0 @@
-from dataclasses import replace
-import json
-import sqlite3
-
-import pytest
-
-from src.lifecycle_web_schema import install_web_journal
-from src.lifecycle_web_store import LifecycleWebStore
-from src.profile_state import ProfileStateStore
-from src.security_lifecycle_investigation import SecurityLifecycleInvestigationStore, observation_fingerprint
-from src.security_lifecycle_web_contract import validate_selection
-from src.ticker_identity_transition import TransitionOptions, TickerIdentityTransitionStore
-from tests.test_security_lifecycle_terminal_workflow import setup_workflow
-from tests.test_security_lifecycle_web_finding import NOTICE, finding_payload, public_input, source_page
-from tests.test_lifecycle_web_store import _options
-
-
-def context(tmp_path, *, auth="api_key", provider=None, kind="terminal_delisting", future=False, sec_case=False,
-            completion=None):
-    c = setup_workflow(tmp_path, assess=False, event_available=False)
-    c["now"][0] = "2026-09-06T01:00:00Z"
-    # Missing structured checks are the reason for Web investigation, not a
-    # requirement that must become successful before a human can confirm.
-    c["checks"].record(ticker="OLD", at=c["now"][0], evidence=(), diagnostics={}, blockers=("massive_unavailable",))
-    observation = c["checks"].latest()["OLD"]["observation"]
-    if sec_case:
-        from src.security_lifecycle import LifecycleObservation, ObservationKind, SecurityLifecycleStore
-        with sqlite3.connect(c["market"]) as conn:
-            SecurityLifecycleStore(conn).upsert_observation(LifecycleObservation(ticker="OLD", cik="0000012345", issuer_name="Issuer Old Inc",
-                filing_date="2026-09-01", source="sec_edgar", source_ref="0000012345-26-000042", filing_form="8-K", filing_items=("3.01",),
-                evidence_url="https://www.sec.gov/Archives/example/old.htm", description="Listing status under review.", observed_at=c["now"][0],
-                kinds=(ObservationKind("listing_removal_notice", "2026-09-01"),)))
-            observation = SecurityLifecycleStore(conn).get_observation("sec_edgar", "0000012345-26-000042", "OLD")
-        with sqlite3.connect(c["profile"]) as conn:
-            c["case_id"] = SecurityLifecycleInvestigationStore(conn).ensure_case(source="sec_edgar", source_ref="0000012345-26-000042", ticker="OLD", at=c["now"][0])
-    fingerprint = observation_fingerprint(observation)
-    with sqlite3.connect(c["profile"]) as conn:
-        install_web_journal(conn, at=c["now"][0])
-    store = LifecycleWebStore(c["profile"], clock=lambda: c["now"][0])
-    provider = provider or ("anthropic" if auth == "claude_code_oauth" else "openai")
-    selected = validate_selection(provider, auth, "claude-sonnet-5" if provider == "anthropic" else "gpt-5.6-luna", "local:7")
-    request = public_input().model_copy(update={"composite_figi": None})
-    run = store.start(case_id=c["case_id"], observation_sha256=fingerprint, request=request, selection=selected,
-                      options=_options(auth), owner="worker-1", request_key="click-1")
-    identity = run["run_id"]
-    control = store.control(identity, owner="worker-1")
-    for phase in ("search", "analysis"):
-        control.reserve_model_request(phase + "-1")
-        control.bind_remote_id(phase + "-1", phase)
-        control.observe_terminal(phase + "-1", response_id=phase, status="completed", selection=selected)
-    payload, notice = finding_payload(), NOTICE
-    if kind == "symbol_continuation":
-        notice = "Issuer Old Inc OLD Class A common stock on NASDAQ changes its ticker from OLD to NEW for the same security effective September 1, 2026."
-        payload.update(event_kind="symbol_continuation", successor_ticker="NEW")
-        payload["citations"][0]["supports"] = ["security_identity", "same_security_continuation", "effective_date"]
-    if future:
-        notice = notice.replace("September 1, 2026", "September 7, 2026")
-        payload.update(timing="scheduled", effective_date="2026-09-07", effective_date_text="September 7, 2026")
-    payload["citations"][0]["quote"] = notice
-    store.add_page(identity, owner="worker-1", source_id="source-1", page=source_page(notice))
-    store.complete(identity, owner="worker-1", **{"payload": payload, "source_failures": {},
-        "usage": {"input_tokens": 20, "output_tokens": 40}, "source_requests": 1, **(completion or {})})
-    c.update(web=store, run_id=identity, options=TransitionOptions(execute_on=payload["effective_date"]), action=kind)
-    return c
-
-
-def prepare(c):
-    from src.lifecycle_web_review import prepare
-    return prepare(c["service"], c["run_id"], options=c["options"])
-
-
-def confirm(c, packet, *, before_write=lambda: None):
-    from src.lifecycle_web_review import confirm
-    return confirm(c["service"], c["run_id"], packet_sha256=packet["packet_sha256"],
-                   action=packet["action"], options=c["options"], before_write=before_write,
-                   acknowledge_source_gaps=bool(packet.get("source_gaps")))
-
-
-def rows(c):
-    with sqlite3.connect(c["profile"]) as conn:
-        return tuple(conn.iterdump())
-
-
-def test_web_review_preparation_never_creates_a_human_assessment_or_tracking_change(tmp_path):
-    c = context(tmp_path)
-    before = rows(c)
-    packet = prepare(c)
-    assert packet["ready"], packet["block_reasons"]
-    assert packet["lane"] == "web" and packet["action"] == "terminal_delisting"
-    assert packet["web"]["run_id"] == c["run_id"]
-    assert rows(c) == before
-    assert "OLD" in c["sources"]()
-
-
-@pytest.mark.parametrize("provider,auth", [("openai", "api_key"), ("openai", "chatgpt_oauth"),
-                                          ("anthropic", "api_key"), ("anthropic", "claude_code_oauth")])
-@pytest.mark.parametrize("kind", ["terminal_delisting", "symbol_continuation"])
-def test_web_confirmation_uses_existing_atomic_writer_without_requiring_provider_success(tmp_path, provider, auth, kind):
-    c = context(tmp_path, provider=provider, auth=auth, kind=kind)
-    packet = prepare(c)
-    assert packet["ready"], packet["block_reasons"]
-    result = confirm(c, packet)
-    assert result["status"] == "applied" and result["current_effects_match"] is True
-    assert ("NEW" in c["sources"]()) == (kind == "symbol_continuation")
-    assert "OLD" not in c["sources"]() and "LIVE" in c["sources"]()
-    with sqlite3.connect(c["profile"]) as conn:
-        author, authority = conn.execute("SELECT author,acceptance_authority FROM security_lifecycle_assessments").fetchone()
-        assert (author, authority) == ("human", "human")
-        linked = conn.execute("SELECT run_id,actor,packet_sha256 FROM lifecycle_web_acceptances").fetchone()
-        assert linked == (c["run_id"], "attended_user", packet["packet_sha256"])
-        receipt = json.loads(conn.execute("SELECT approved_preview_json FROM ticker_identity_transitions").fetchone()[0])
-        assert receipt["review_confirmation"]["packet"]["web"]["execution"]["auth_mode"] == auth
-        assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_investigation_runs").fetchone()[0] == 0
-    before = rows(c)
-    assert confirm(c, packet)["status"] == "already_applied"
-    assert rows(c) == before
-
-
-@pytest.mark.parametrize("change", ["membership", "new_observation", "evidence", "future_lease", "open_position"])
-def test_web_confirmation_rejects_changed_material_without_partial_human_adoption(tmp_path, change):
-    c = context(tmp_path)
-    packet = prepare(c)
-    if change == "membership":
-        ProfileStateStore(c["profile"]).import_lists([{"name": "New", "kind": "custom", "tickers": ["OLD"]}])
-    elif change == "new_observation":
-        c["checks"].record(ticker="OLD", at="2026-09-06T01:01:00Z", evidence=(), diagnostics={}, blockers=("massive_unavailable",))
-        c["now"][0] = "2026-09-06T01:01:00Z"
-    elif change == "evidence":
-        with sqlite3.connect(c["profile"]) as conn:
-            SecurityLifecycleInvestigationStore(conn).add_evidence(case_id=c["case_id"], run_id=None, kind="manual_text", adapter="manual",
-                excerpt="Contradictory evidence", source_url=None, title=None, publisher=None, domain=None, source_published_at=None,
-                retrieved_at=None, mime_type=None, document_status=None, at=c["now"][0])
-    elif change == "future_lease":
-        c["now"][0] = "2026-09-10T01:00:00Z"
-    else:
-        # Use the same authoritative open-position source as ordinary review.
-        c["service"]._read_service.sources_by_ticker = lambda: {"OLD": ("manual_lists", "portfolio_open"), "LIVE": ("manual_lists",)}
-    before = rows(c)
-    with pytest.raises((ValueError, RuntimeError), match="review_changed|web_review_ineligible"):
-        confirm(c, packet)
-    assert rows(c) == before and "OLD" in c["sources"]()
-
-
-def test_current_active_otc_veto_is_not_lost_when_other_provider_requests_failed(tmp_path):
-    from src.security_lifecycle_listing_evidence import _evidence
-    from tests.test_security_lifecycle_provider_authority import record
-    c = context(tmp_path)
-    c["checks"].record(ticker="OLD", at=c["now"][0], evidence=[_evidence(record("massive_reference", "active", market="otc"))],
-                       diagnostics={}, blockers=("massive_unavailable",))
-    packet = prepare(c)
-    assert packet["ready"] is False and "web_active_listing_conflict" in packet["block_reasons"]
-    assert "OLD" in c["sources"]()
-
-
-def test_future_web_action_is_scheduled_and_rechecked_before_applying(tmp_path):
-    c = context(tmp_path, future=True)
-    packet = prepare(c)
-    result = confirm(c, packet)
-    assert result["status"] == "scheduled" and "OLD" in c["sources"]()
-    c["now"][0] = "2026-09-07T15:00:00Z"
-    with sqlite3.connect(c["profile"]) as conn:
-        digest = conn.execute("SELECT approved_preview_sha256 FROM ticker_identity_transitions WHERE transition_id=?", (result["transition_id"],)).fetchone()[0]
-    applied = c["service"].execute_transition(result["transition_id"], preview_sha256=digest, before_write=lambda: None)
-    assert applied["status"] == "applied" and "OLD" not in c["sources"]()
-
-
-def test_web_adoption_cannot_survive_an_approval_failure_in_a_partial_transaction(tmp_path, monkeypatch):
-    c = context(tmp_path)
-    packet = prepare(c)
-    before = rows(c)
-    def fail(*args, **kwargs):
-        raise RuntimeError("approval_failed")
-    monkeypatch.setattr(TickerIdentityTransitionStore, "_approve", fail)
-    with pytest.raises(RuntimeError, match="approval_failed"):
-        confirm(c, packet)
-    assert rows(c) == before
-
-
-def test_unrelated_sa_refresh_and_other_ticker_edits_do_not_block_web_review(tmp_path):
-    c = context(tmp_path)
-    packet = prepare(c)
-    ProfileStateStore(c["profile"]).import_lists([{"name": "Other", "kind": "custom", "tickers": ["OTHER"]}])
-    c["tracking"].reconcile(({**c["observed"], "observed_at": "2026-09-06T01:01:00Z"},), at="2026-09-06T01:01:00Z")
-    assert confirm(c, packet)["status"] == "applied"
-    assert set(c["sources"]()) == {"LIVE", "OTHER"}
-
-
-@pytest.mark.parametrize("kind", ["terminal_delisting", "symbol_continuation"])
-def test_unretained_sec_case_cannot_start_new_adoption_but_keeps_audit_material(tmp_path, kind):
-    from src.security_lifecycle_investigation import compose_security_lifecycle_audit
-
-    c = context(tmp_path, sec_case=True, kind=kind)
-    before = rows(c)
-    with pytest.raises(KeyError, match="case_not_found"):
-        prepare(c)
-    assert rows(c) == before and "OLD" in c["sources"]()
-    assert c["web"].read(c["run_id"])["status"] == "succeeded"
-    assert c["case_id"] in {case["case_id"] for case in compose_security_lifecycle_audit(str(c["market"]), str(c["profile"]))["cases"]}
-
-
-@pytest.mark.parametrize("mutation", ["strip_confirmation", "edit_finding", "automation"])
-def test_central_writer_rejects_forged_web_authority_even_with_recomputed_preview_digest(tmp_path, mutation):
-    from src.ticker_identity_transition import profile_snapshot_sha256
-    c = context(tmp_path, future=True)
-    packet = prepare(c)
-    result = confirm(c, packet)
-    c["now"][0] = "2026-09-07T15:00:00Z"
-    with sqlite3.connect(c["profile"]) as conn:
-        store = TickerIdentityTransitionStore(conn, clock=lambda: c["now"][0])
-        transition = store.get(result["transition_id"])
-        preview = transition["approved_preview"]
-        if mutation == "strip_confirmation":
-            preview.pop("review_confirmation")
-        elif mutation == "edit_finding":
-            conn.execute("UPDATE security_lifecycle_assessments SET effective_date='2026-08-01' WHERE assessment_id=?", (transition["assessment_id"],))
-        preview["preview_sha256"] = profile_snapshot_sha256(preview)
-        blockers = store._provider_guard(preview, at=c["now"][0], automation=mutation == "automation")
-        assert "web_acceptance_required" in blockers or "web_acceptance_invalid" in blockers
-    assert "OLD" in c["sources"]()
-
-
-def test_stale_provider_state_after_web_approval_blocks_the_real_due_writer(tmp_path):
-    from src.security_lifecycle_listing_evidence import _evidence
-    from tests.test_security_lifecycle_provider_authority import record
-    c = context(tmp_path, future=True)
-    packet = prepare(c)
-    result = confirm(c, packet)
-    with sqlite3.connect(c["profile"]) as conn:
-        digest = conn.execute("SELECT approved_preview_sha256 FROM ticker_identity_transitions WHERE transition_id=?", (result["transition_id"],)).fetchone()[0]
-    c["now"][0] = "2026-09-07T15:00:00Z"
-    c["checks"].record(ticker="OLD", at=c["now"][0], evidence=[_evidence(replace(record("massive_reference", "active", market="otc"), retrieved_at=c["now"][0]))], diagnostics={})
-    result = c["service"].execute_transition(result["transition_id"], preview_sha256=digest, before_write=lambda: None)
-    assert result["status"] == "blocked" and "OLD" in c["sources"]()
-
-
-def test_web_applied_receipt_can_reverse_without_erasing_investigation_or_reenrolling_on_sa_refresh(tmp_path):
-    c = context(tmp_path)
-    result = confirm(c, prepare(c))
-    c["tracking"].reconcile(({**c["observed"], "observed_at": "2026-09-06T01:01:00Z"},), at="2026-09-06T01:01:00Z")
-    assert "OLD" not in c["sources"]()
-    reversed_result = c["service"].reverse_transition(result["transition_id"], before_write=lambda: None)
-    assert reversed_result["status"] == "reversed"
-    assert "OLD" in c["sources"]() and c["web"].read(c["run_id"])["status"] == "succeeded"
diff --git a/tests/test_lifecycle_web_store.py b/tests/test_lifecycle_web_store.py
deleted file mode 100644
index d6e1a29a..00000000
--- a/tests/test_lifecycle_web_store.py
+++ /dev/null
@@ -1,182 +0,0 @@
-from dataclasses import asdict
-import json
-import sqlite3
-
-import pytest
-
-from src.auth_drivers.lifecycle_web_models import ModelCall, ModelReply
-from src.security_lifecycle_investigation import SecurityLifecycleInvestigationStore
-from src.security_lifecycle_schema import create_profile_schema, verify_profile_connection
-from src.security_lifecycle_web_contract import validate_selection
-from src.security_lifecycle_web_finding import WebFinding, strict_schema, validate_finding
-from tests.test_security_lifecycle_web_finding import NOTICE, finding_payload, public_input, source_page
-
-
-AT = "2026-09-06T01:00:00+00:00"
-
-
-def _options(auth):
-    from src.lifecycle_web_store import WebInvestigationOptions
-    return WebInvestigationOptions(max_sources=2, max_source_requests=4, max_redirects=1, max_source_bytes=65536,
-                                    source_timeout_seconds=3, model_timeout_seconds=3, max_search_uses=2,
-                                    output_token_limit=4096 if auth == "api_key" else None, effort="high")
-
-
-def setup_store(tmp_path, *, install=True):
-    from src.lifecycle_web_store import LifecycleWebStore, install_web_journal
-
-    path = tmp_path / "profile.sqlite"
-    with sqlite3.connect(path) as conn:
-        create_profile_schema(conn)
-        conn.execute("INSERT INTO security_lifecycle_cases VALUES (?,?,?,?,?,?)", ("case-1", "sec_edgar", "source-1", "OLD", AT, AT))
-        conn.commit()
-        if install:
-            install_web_journal(conn, at=AT)
-        verify_profile_connection(conn)
-    store = LifecycleWebStore(path, clock=lambda: AT)
-    return path, store
-
-
-def start(store, *, auth="api_key", owner="worker-1", request_key="request-1"):
-    selection = validate_selection("openai", auth, "gpt-5.6-luna", "local:7")
-    return store.start(case_id="case-1", observation_sha256="a" * 64, request=public_input(), selection=selection,
-                       options=_options(auth), owner=owner, request_key=request_key)
-
-
-def completed(store, *, usage_report=None):
-    run = start(store)
-    control = store.control(run["run_id"], owner="worker-1")
-    store.set_phase(run["run_id"], owner="worker-1", phase="searching")
-    control.reserve_model_request("search-1")
-    control.bind_remote_id("search-1", "remote-search")
-    control.observe_terminal("search-1", response_id="remote-search", status="completed", selection=control.selection)
-    store.set_phase(run["run_id"], owner="worker-1", phase="reading_sources")
-    store.add_page(run["run_id"], owner="worker-1", source_id="source-1", page=source_page(NOTICE))
-    store.set_phase(run["run_id"], owner="worker-1", phase="analyzing")
-    control.reserve_model_request("analysis-1")
-    control.bind_remote_id("analysis-1", "remote-analysis")
-    control.observe_terminal("analysis-1", response_id="remote-analysis", status="completed", selection=control.selection)
-    store.complete(run["run_id"], owner="worker-1", payload=finding_payload(), source_failures={},
-                   usage={"input_tokens": 20, "output_tokens": 40}, source_requests=1, usage_report=usage_report)
-    return run["run_id"]
-
-
-def test_web_journal_installation_is_explicit_and_preserves_existing_schema(tmp_path):
-    from src.lifecycle_web_store import WebJournalError, install_web_journal
-
-    path, store = setup_store(tmp_path, install=False)
-    with pytest.raises(WebJournalError, match="web_journal_not_installed"):
-        start(store)
-    with sqlite3.connect(path) as conn:
-        before = dict(conn.execute("SELECT name,sql FROM sqlite_master WHERE name LIKE 'security_lifecycle_%'"))
-        install_web_journal(conn, at=AT)
-        install_web_journal(conn, at=AT)
-        verify_profile_connection(conn)
-        assert dict(conn.execute("SELECT name,sql FROM sqlite_master WHERE name LIKE 'security_lifecycle_%'")) == before
-        assert conn.execute("SELECT COUNT(*) FROM lifecycle_web_installation").fetchone()[0] == 1
-
-
-def test_web_journal_preserves_model_authorship_without_creating_human_acceptance(tmp_path):
-    path, store = setup_store(tmp_path)
-    identity = completed(store)
-    row = store.read(identity)
-    assert row["status"] == "succeeded" and row["finding"].action == "terminal_delisting"
-    assert row["selection"].auth_mode == "api_key"
-    assert row["request"] == public_input()
-    assert row["calls"] == {"search-1": {"remote_id": "remote-search", "terminal": "completed"},
-                            "analysis-1": {"remote_id": "remote-analysis", "terminal": "completed"}}
-    with sqlite3.connect(path) as conn:
-        assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_assessments").fetchone()[0] == 0
-        assert conn.execute("SELECT COUNT(*) FROM security_lifecycle_investigation_runs").fetchone()[0] == 0
-
-
-def test_start_is_idempotent_and_does_not_reset_or_replay_existing_execution(tmp_path):
-    from src.lifecycle_web_store import WebJournalError
-
-    _, store = setup_store(tmp_path)
-    first = start(store)
-    assert start(store)["run_id"] == first["run_id"]
-    with pytest.raises(WebJournalError, match="web_investigation_running"):
-        start(store, request_key="second-command")
-    with pytest.raises(WebJournalError, match="web_request_identity_changed"):
-        start(store, auth="chatgpt_oauth")
-
-
-def test_stale_or_wrong_worker_cannot_record_provider_work(tmp_path):
-    from src.lifecycle_web_store import WebJournalError
-
-    _, store = setup_store(tmp_path)
-    run = start(store)
-    with pytest.raises(WebJournalError, match="web_owner_changed"):
-        store.control(run["run_id"], owner="other-worker")
-    store.request_cancel(run["run_id"])
-    control = store.control(run["run_id"], owner="worker-1")
-    with pytest.raises((ValueError, WebJournalError), match="stop_requested"):
-        control.reserve_model_request("search-1")
-    assert store.read(run["run_id"])["calls"] == {}
-
-
-def test_recording_failure_stops_before_dispatch_and_never_fakes_completion(tmp_path, monkeypatch):
-    from src.lifecycle_web_store import WebJournalError
-
-    _, store = setup_store(tmp_path)
-    run = start(store)
-    control = store.control(run["run_id"], owner="worker-1")
-    def fail(*args, **kwargs):
-        raise WebJournalError("web_recording_unavailable")
-    monkeypatch.setattr(store, "reserve_call", fail)
-    with pytest.raises(WebJournalError, match="web_recording_unavailable"):
-        control.reserve_model_request("search-1")
-    assert control.stop_state != "running"
-    assert store.read(run["run_id"])["status"] != "succeeded"
-
-
-def test_cancel_ack_does_not_write_a_cancelled_remote_terminal(tmp_path):
-    _, store = setup_store(tmp_path)
-    run = start(store)
-    control = store.control(run["run_id"], owner="worker-1")
-    control.reserve_model_request("search-1")
-    control.bind_remote_id("search-1", "remote-search")
-    store.request_cancel(run["run_id"])
-    control.request_stop()
-    control.observe_interrupt_ack("search-1", "remote-search")
-    control.observe_transport_loss("search-1")
-    store.fail(run["run_id"], owner="worker-1", code="stop_requested", control=control)
-    assert store.read(run["run_id"])["status"] == "remote_outcome_unknown"
-    assert store.read(run["run_id"])["calls"]["search-1"]["terminal"] is None
-
-
-@pytest.mark.parametrize("pending", [False, True])
-def test_expired_lease_recovers_honestly_without_provider_or_retry(tmp_path, pending):
-    _, store = setup_store(tmp_path)
-    run = start(store)
-    if pending:
-        control = store.control(run["run_id"], owner="worker-1")
-        control.reserve_model_request("search-1")
-    store.recover_expired(at="2026-09-06T01:10:00+00:00")
-    row = store.read(run["run_id"])
-    assert row["status"] == ("remote_outcome_unknown" if pending else "failed")
-    assert row["failure_code"] == "web_execution_interrupted"
-    assert start(store)["run_id"] == run["run_id"]
-
-
-def test_immutable_source_rows_cannot_be_rebound_after_investigation(tmp_path):
-    path, store = setup_store(tmp_path)
-    identity = completed(store)
-    with sqlite3.connect(path) as conn:
-        with pytest.raises(sqlite3.IntegrityError, match="web_immutable_record"):
-            conn.execute("UPDATE lifecycle_web_pages SET page_json='{}' WHERE run_id=?", (identity,))
-        with pytest.raises(sqlite3.IntegrityError, match="web_immutable_record"):
-            conn.execute("UPDATE lifecycle_web_results SET payload_json='{}' WHERE run_id=?", (identity,))
-    assert store.read(identity)["finding"].action == "terminal_delisting"
-
-
-def test_completed_result_requires_all_owned_remote_terminals(tmp_path):
-    from src.lifecycle_web_store import WebJournalError
-
-    _, store = setup_store(tmp_path)
-    run = start(store)
-    with pytest.raises(WebJournalError, match="web_model_work_incomplete"):
-        store.complete(run["run_id"], owner="worker-1", payload=finding_payload(), source_failures={},
-                       usage={"input_tokens": None, "output_tokens": None}, source_requests=0)
-    assert store.read(run["run_id"])["status"] != "succeeded"
diff --git a/tests/test_lifecycle_web_usage_journal.py b/tests/test_lifecycle_web_usage_journal.py
deleted file mode 100644
index 044a1648..00000000
--- a/tests/test_lifecycle_web_usage_journal.py
+++ /dev/null
@@ -1,141 +0,0 @@
-from copy import deepcopy
-import json
-
-import pytest
-
-from tests.test_lifecycle_web_store import AT, completed, setup_store, start
-
-
-def test_legacy_usage_has_no_fabricated_scope_or_zero_counters(tmp_path):
-    from src.lifecycle_web_projection import project_web_run
-
-    _, store = setup_store(tmp_path)
-    result = project_web_run(store.read(completed(store)), at=AT)
-    assert result["usage"] == {"input_tokens": 20, "output_tokens": 40}
-    assert result["usage_report"] is None
-
-
-def _report():
-    return {"version": 1, "phases": [{"call_id": "search-1", "remote_id": "remote-search", "observation": {
-        "basis": "adapter_report", "values": {"input_tokens": 10, "output_tokens": 20,
-            "cache_creation_input_tokens": None, "cache_read_input_tokens": None, "web_search_requests": None}, "main_loop": None}}]}
-
-
-def saved_usage_receipt(tmp_path, *, failure=None):
-    _, store = setup_store(tmp_path)
-    report = _report()
-    if failure is None:
-        analysis = deepcopy(report["phases"][0])
-        analysis.update(call_id="analysis-1", remote_id="remote-analysis")
-        report["phases"].append(analysis)
-        return store, completed(store, usage_report=report)
-    identity = start(store)["run_id"]
-    control = store.control(identity, owner="worker-1")
-    control.reserve_model_request("search-1")
-    control.bind_remote_id("search-1", "remote-search")
-    control.observe_terminal("search-1", response_id="remote-search", status="completed", selection=control.selection)
-    if failure == "lost":
-        control.reserve_model_request("analysis-1")
-        control.bind_remote_id("analysis-1", "remote-analysis")
-        control.observe_transport_loss("analysis-1")
-    store.fail(identity, owner="worker-1", code="source_read_incomplete", control=control, usage_report=report)
-    return store, identity
-
-
-@pytest.mark.parametrize("mutate", [
-    lambda report: report["phases"][0].update(remote_id="another-run"),
-    lambda report: report["phases"].append(deepcopy(report["phases"][0])),
-    lambda report: report["phases"][0].update(call_id="analysis-1"),
-    lambda report: report["phases"][0]["observation"]["values"].update(input_tokens=True),
-    lambda report: report["phases"][0]["observation"].update(secret="not-public"),
-    lambda report: report.update(phases=None),
-    lambda report: report.update(version=True),
-])
-def test_usage_receipt_rejects_cross_call_duplicate_and_malformed_observations_before_write(tmp_path, mutate):
-    from src.lifecycle_web_store import WebJournalError
-
-    _, store = setup_store(tmp_path)
-    identity = start(store)["run_id"]
-    control = store.control(identity, owner="worker-1")
-    control.reserve_model_request("search-1")
-    control.bind_remote_id("search-1", "remote-search")
-    control.observe_terminal("search-1", response_id="remote-search", status="completed", selection=control.selection)
-    report = _report()
-    mutate(report)
-    with pytest.raises(WebJournalError, match="^web_result_invalid$"):
-        store.fail(identity, owner="worker-1", code="source_read_incomplete", control=control, usage_report=report)
-    assert store.read(identity)["status"] == "queued"
-    with store.connection() as conn:
-        assert conn.execute("SELECT COUNT(*) FROM lifecycle_web_results").fetchone()[0] == 0
-
-
-def test_usage_only_failure_receipt_is_readable_and_does_not_create_a_finding(tmp_path):
-    from src.lifecycle_web_projection import project_web_run
-
-    _, store = setup_store(tmp_path)
-    identity = start(store)["run_id"]
-    control = store.control(identity, owner="worker-1")
-    control.reserve_model_request("search-1")
-    control.bind_remote_id("search-1", "remote-search")
-    control.observe_terminal("search-1", response_id="remote-search", status="completed", selection=control.selection)
-    store.fail(identity, owner="worker-1", code="search_no_sources", control=control, usage_report=_report())
-    result = project_web_run(store.read(identity), at=AT)
-    assert result["status"] == "failed" and result["source_reads"] is None and result["finding"] is None
-    assert result["usage_report"]["totals"] == {"input_tokens": 10, "output_tokens": 20}
-
-
-def rewrite_result(store, mutate):
-    from src.lifecycle_web_schema import TRIGGERS
-    from src.lifecycle_journal_codec import canonical_json, digest_json
-
-    with store.connection(write=True) as conn:
-        value = json.loads(conn.execute("SELECT payload_json FROM lifecycle_web_results").fetchone()[0])
-        mutate(value)
-        trigger = "lifecycle_web_results_update_immutable"
-        conn.execute("DROP TRIGGER " + trigger)
-        conn.execute("UPDATE lifecycle_web_results SET payload_json=?,result_sha256=?", (canonical_json(value), digest_json(value)))
-        conn.execute(TRIGGERS[trigger])
-
-
-@pytest.mark.parametrize("value", [None, [], {}, {"version": 1, "phases": None}, {"version": True, "phases": []}])
-def test_present_malformed_saved_usage_is_not_treated_as_legacy_absence(tmp_path, value):
-    from src.lifecycle_web_store import WebJournalError
-
-    _, store = setup_store(tmp_path)
-    identity = completed(store)
-    rewrite_result(store, lambda material: material.update(usage_report=value))
-    with pytest.raises(WebJournalError, match="^web_journal_integrity$"):
-        store.read(identity)
-
-
-@pytest.mark.parametrize("failure", [None, "sources", "lost"])
-def test_reopened_usage_receipt_rechecks_remote_binding_even_with_valid_hash(tmp_path, failure):
-    from src.lifecycle_web_store import WebJournalError
-
-    store, identity = saved_usage_receipt(tmp_path, failure=failure)
-    assert store.read(identity)["status"] == {None: "succeeded", "sources": "failed", "lost": "remote_outcome_unknown"}[failure]
-    rewrite_result(store, lambda material: material["usage_report"]["phases"][0].update(remote_id="another-run"))
-    with pytest.raises(WebJournalError, match="^web_journal_integrity$"):
-        store.read(identity)
-
-
-def test_completed_result_rechecks_aggregate_agreement_on_read(tmp_path):
-    from src.lifecycle_web_store import WebJournalError
-
-    store, identity = saved_usage_receipt(tmp_path)
-    assert store.read(identity)["status"] == "succeeded"
-    rewrite_result(store, lambda material: material["usage"].update(input_tokens=4))
-    with pytest.raises(WebJournalError, match="^web_journal_integrity$"):
-        store.read(identity)
-
-
-@pytest.mark.parametrize("value", [None, {}, "unknown", {"input_tokens": True, "output_tokens": 40},
-                                   {"input_tokens": 20, "output_tokens": 40, "secret": "forbidden"}])
-def test_legacy_usage_pair_rejects_malformed_shape_instead_of_exporting_it(tmp_path, value):
-    from src.lifecycle_web_store import WebJournalError
-
-    _, store = setup_store(tmp_path)
-    identity = completed(store)
-    rewrite_result(store, lambda material: material.update(usage=value))
-    with pytest.raises(WebJournalError, match="^web_journal_integrity$"):
-        store.read(identity)
diff --git a/tests/test_sec_research_config.py b/tests/test_sec_research_config.py
new file mode 100644
index 00000000..b83443c8
--- /dev/null
+++ b/tests/test_sec_research_config.py
@@ -0,0 +1,195 @@
+"""SEC capture-budget ownership and persistence contracts."""
+
+import sqlite3
+from pathlib import Path
+
+import pytest
+
+from src.profile_state import ProfileStateStore
+
+
+ROOT = Path(__file__).resolve().parents[1]
+KEY = "sec_research.capture_budget_bytes"
+
+
+@pytest.mark.parametrize("name", ["__init__.py", "config.py"])
+def test_sec_configuration_owner_exists(name):
+    assert (ROOT / "src" / "sec_research" / name).is_file()
+
+
+def _config():
+    assert (ROOT / "src" / "sec_research" / "config.py").is_file()
+    from src.sec_research import config
+
+    return config
+
+
+@pytest.fixture
+def profile(tmp_path):
+    return ProfileStateStore(tmp_path / "profile" / "state.db")
+
+
+def _settings_rows(profile):
+    with sqlite3.connect(profile.db_path) as conn:
+        return conn.execute(
+            "SELECT key, value, updated_at FROM profile_settings ORDER BY key"
+        ).fetchall()
+
+
+def test_budget_defaults_only_when_the_key_is_absent(profile):
+    config = _config()
+    assert config.get_capture_budget_bytes(profile) == 107374182400
+    assert profile.get_settings_snapshot([KEY]) == {}
+    assert _settings_rows(profile) == []
+    profile.set_setting(KEY, None)
+    before = _settings_rows(profile)
+    with pytest.raises(ValueError):
+        config.get_capture_budget_bytes(profile)
+    assert _settings_rows(profile) == before
+
+
+@pytest.mark.parametrize(
+    ("stored", "expected"),
+    [
+        ("1", 1),
+        ("107374182399", 107374182399),
+        ("107374182400", 107374182400),
+        ("214748364800", 214748364800),
+        ("9007199254740989", 9007199254740989),
+        ("9007199254740991", 9007199254740991),
+    ],
+    ids=["minimum", "below-default", "default", "above-default", "large-odd", "maximum"],
+)
+def test_budget_reads_exact_canonical_integers_without_writes(profile, stored, expected):
+    config = _config()
+    profile.set_setting(KEY, stored)
+    before = _settings_rows(profile)
+    result = config.get_capture_budget_bytes(profile)
+    assert type(result) is int
+    assert result == expected
+    assert _settings_rows(profile) == before
+
+
+@pytest.mark.parametrize(
+    "stored",
+    [
+        pytest.param("", id="empty"),
+        pytest.param("0", id="zero"),
+        pytest.param("-1", id="negative"),
+        pytest.param("+1", id="plus"),
+        pytest.param("01", id="leading-zero"),
+        pytest.param(" 1", id="leading-space"),
+        pytest.param("1 ", id="trailing-space"),
+        pytest.param("1\n", id="newline"),
+        pytest.param("1\x00", id="nul"),
+        pytest.param("1.0", id="whole-float"),
+        pytest.param("1.5", id="fraction"),
+        pytest.param("1e3", id="exponent"),
+        pytest.param("NaN", id="nan"),
+        pytest.param("Infinity", id="infinity"),
+        pytest.param("-inf", id="negative-infinity"),
+        pytest.param("true", id="true-text"),
+        pytest.param("false", id="false-text"),
+        pytest.param("NULL", id="null-text"),
+        pytest.param("1_024", id="underscore"),
+        pytest.param("0x400", id="hex"),
+        pytest.param("\u0661", id="unicode-digit"),
+        pytest.param("\uff11", id="fullwidth-digit"),
+        pytest.param("9007199254740992", id="overflow"),
+        pytest.param("9" * 5000, id="huge-overflow"),
+        pytest.param(b"1", id="blob"),
+    ],
+)
+def test_budget_rejects_corrupt_persisted_values_without_repair(profile, stored):
+    config = _config()
+    profile.set_setting(KEY, stored)
+    before = _settings_rows(profile)
+    with pytest.raises(ValueError):
+        config.get_capture_budget_bytes(profile)
+    assert _settings_rows(profile) == before
+
+
+@pytest.mark.parametrize(
+    "value",
+    [
+        pytest.param(None, id="null"),
+        pytest.param(True, id="bool-true"),
+        pytest.param(False, id="bool-false"),
+        pytest.param(0, id="zero"),
+        pytest.param(-1, id="negative"),
+        pytest.param(1.0, id="whole-float"),
+        pytest.param(1.5, id="fraction"),
+        pytest.param(107374182400.0, id="default-float"),
+        pytest.param(float("nan"), id="nan"),
+        pytest.param(float("inf"), id="infinity"),
+        pytest.param(float("-inf"), id="negative-infinity"),
+        pytest.param("1", id="numeric-text"),
+        pytest.param(b"1", id="bytes"),
+        pytest.param([], id="list"),
+        pytest.param({}, id="dict"),
+        pytest.param(9007199254740992, id="overflow"),
+        pytest.param(10**200, id="huge-overflow"),
+    ],
+)
+def test_budget_setter_rejects_invalid_values_before_writing(profile, value):
+    config = _config()
+    profile.set_setting(KEY, "4096")
+    before = _settings_rows(profile)
+    with pytest.raises(ValueError):
+        config.set_capture_budget_bytes(profile, value)
+    assert _settings_rows(profile) == before
+
+
+def test_rejected_budget_does_not_create_an_absent_setting(profile):
+    config = _config()
+    with pytest.raises(ValueError):
+        config.set_capture_budget_bytes(profile, True)
+    assert _settings_rows(profile) == []
+
+
+def test_budget_changes_persist_exact_text_and_leave_other_settings_untouched(profile):
+    config = _config()
+    profile.update_settings(
+        {
+            "security_lifecycle.automation.enabled": "false",
+            "security_lifecycle.automation.interval_minutes": "5",
+            "use_local_market": "true",
+            "default_watchlist_id": None,
+        }
+    )
+    with sqlite3.connect(profile.db_path) as conn:
+        conn.execute("UPDATE profile_settings SET updated_at = '2001-01-01T00:00:00Z'")
+        schema_before = conn.execute(
+            "SELECT type, name, sql FROM sqlite_master ORDER BY type, name"
+        ).fetchall()
+    unrelated_before = _settings_rows(profile)
+
+    for value, text in [
+        (107374182400, "107374182400"),
+        (214748364800, "214748364800"),
+        (9007199254740991, "9007199254740991"),
+        (9007199254740989, "9007199254740989"),
+        (1, "1"),
+    ]:
+        result = config.set_capture_budget_bytes(profile, value)
+        assert type(result) is int
+        assert result == value
+        assert profile.get_settings_snapshot([KEY]) == {KEY: text}
+        assert config.get_capture_budget_bytes(profile) == value
+        assert [row for row in _settings_rows(profile) if row[0] != KEY] == unrelated_before
+
+    with sqlite3.connect(profile.db_path) as conn:
+        assert conn.execute(
+            "SELECT type, name, sql FROM sqlite_master ORDER BY type, name"
+        ).fetchall() == schema_before
+    reopened = ProfileStateStore(profile.db_path)
+    assert config.get_capture_budget_bytes(reopened) == 1
+
+
+def test_budget_accessors_do_not_create_market_or_capture_files(profile, tmp_path, monkeypatch):
+    config = _config()
+    market = tmp_path / "uncreated" / "market.db"
+    monkeypatch.setenv("ARKSCOPE_MARKET_DB", str(market))
+    assert config.get_capture_budget_bytes(profile) == 107374182400
+    assert config.set_capture_budget_bytes(profile, 214748364800) == 214748364800
+    assert not market.parent.exists()
diff --git a/tests/test_sec_research_paths.py b/tests/test_sec_research_paths.py
new file mode 100644
index 00000000..00ff6b1f
--- /dev/null
+++ b/tests/test_sec_research_paths.py
@@ -0,0 +1,288 @@
+"""SEC capture-root authority and portable object-key contracts."""
+
+from pathlib import Path
+
+import pytest
+
+
+ROOT = Path(__file__).resolve().parents[1]
+
+
+def test_sec_paths_owner_exists():
+    assert (ROOT / "src" / "sec_research" / "paths.py").is_file()
+
+
+def _paths_type():
+    assert (ROOT / "src" / "sec_research" / "paths.py").is_file()
+    from src.sec_research.paths import SecResearchPaths
+
+    return SecResearchPaths
+
+
+def test_capture_root_keeps_the_resolved_database_filename_without_creating_files(tmp_path):
+    paths = _paths_type().from_market_db(tmp_path / "uncreated" / "market.snapshot.db")
+    assert paths.market_db_path == tmp_path / "uncreated" / "market.snapshot.db"
+    assert paths.capture_root == tmp_path / "uncreated" / "market.snapshot.db.sec-research"
+    assert paths.object_path("objects/body.txt") == (
+        tmp_path / "uncreated" / "market.snapshot.db.sec-research" / "objects" / "body.txt"
+    )
+    assert list(tmp_path.iterdir()) == []
+
+
+def test_two_market_databases_in_one_directory_have_distinct_capture_roots(tmp_path):
+    paths_type = _paths_type()
+    first = paths_type.from_market_db(tmp_path / "first.db")
+    second = paths_type.from_market_db(tmp_path / "second.db")
+    assert first.object_path("body") == tmp_path / "first.db.sec-research" / "body"
+    assert second.object_path("body") == tmp_path / "second.db.sec-research" / "body"
+    assert list(tmp_path.iterdir()) == []
+
+
+@pytest.mark.parametrize("factory", ["from_market_db", "constructor"])
+def test_relative_market_binding_survives_cwd_changes(tmp_path, monkeypatch, factory):
+    paths_type = _paths_type()
+    elsewhere = tmp_path / "elsewhere"
+    elsewhere.mkdir()
+    monkeypatch.chdir(tmp_path)
+    if factory == "from_market_db":
+        paths = paths_type.from_market_db("data/../data/market.db")
+    else:
+        paths = paths_type(market_db_path=Path("data/../data/market.db"))
+    monkeypatch.chdir(elsewhere)
+    assert paths.market_db_path == tmp_path / "data" / "market.db"
+    assert paths.object_path("body") == tmp_path / "data" / "market.db.sec-research" / "body"
+    assert not (tmp_path / "data").exists()
+
+
+def test_market_binding_cannot_be_reassigned(tmp_path):
+    from dataclasses import FrozenInstanceError
+
+    paths = _paths_type().from_market_db(tmp_path / "market.db")
+    with pytest.raises(FrozenInstanceError):
+        paths.market_db_path = tmp_path / "other.db"
+    assert paths.object_path("body") == tmp_path / "market.db.sec-research" / "body"
+
+
+def test_resolve_uses_market_environment_authority(tmp_path, monkeypatch):
+    paths_type = _paths_type()
+    monkeypatch.chdir(tmp_path)
+    monkeypatch.setenv("ARKSCOPE_MARKET_DB", "custom/../custom/prices.sqlite")
+    paths = paths_type.resolve()
+    monkeypatch.setenv("ARKSCOPE_MARKET_DB", str(tmp_path / "other.db"))
+    assert paths.market_db_path == tmp_path / "custom" / "prices.sqlite"
+    assert paths.object_path("body") == tmp_path / "custom" / "prices.sqlite.sec-research" / "body"
+    assert list(tmp_path.iterdir()) == []
+
+
+@pytest.mark.parametrize("env_value", [None, ""], ids=["absent", "empty"])
+def test_resolve_uses_existing_default_authority(tmp_path, monkeypatch, env_value):
+    paths_type = _paths_type()
+    from src import market_data_admin
+
+    if env_value is None:
+        monkeypatch.delenv("ARKSCOPE_MARKET_DB", raising=False)
+    else:
+        monkeypatch.setenv("ARKSCOPE_MARKET_DB", env_value)
+    monkeypatch.setattr(market_data_admin, "_PROJECT_ROOT", tmp_path / "application")
+    paths = paths_type.resolve()
+    assert paths.market_db_path == tmp_path / "application" / "data" / "market_data.db"
+    assert paths.capture_root == (
+        tmp_path / "application" / "data" / "market_data.db.sec-research"
+    )
+    assert list(tmp_path.iterdir()) == []
+
+
+def test_resolve_delegates_to_existing_market_path_resolver(tmp_path, monkeypatch):
+    paths_type = _paths_type()
+    from src import market_data_admin
+
+    monkeypatch.setattr(
+        market_data_admin, "resolve_market_db_path", lambda: str(tmp_path / "authority.db")
+    )
+    paths = paths_type.resolve()
+    assert paths.object_path("body") == tmp_path / "authority.db.sec-research" / "body"
+    assert list(tmp_path.iterdir()) == []
+
+
+def test_market_database_symlink_binds_the_target_store(tmp_path):
+    paths_type = _paths_type()
+    target = tmp_path / "real" / "market.db"
+    target.parent.mkdir()
+    target.write_bytes(b"path-only fixture, never opened as SQLite")
+    alias = tmp_path / "alias.db"
+    alias.symlink_to(target)
+    paths = paths_type.from_market_db(alias)
+    assert paths.market_db_path == target
+    assert paths.object_path("body") == tmp_path / "real" / "market.db.sec-research" / "body"
+    assert not paths.capture_root.exists()
+
+
+def test_relative_object_key_reopens_the_capture_after_relocation(tmp_path):
+    paths_type = _paths_type()
+    original = tmp_path / "original"
+    original.mkdir()
+    market = original / "market.db"
+    market.write_bytes(b"path-only database fixture")
+    root = original / "market.db.sec-research"
+    (root / "objects").mkdir(parents=True)
+    (root / "objects" / "abc.txt").write_bytes(b"retained capture")
+    old_paths = paths_type.from_market_db(market)
+    key = "objects/abc.txt"
+    assert old_paths.object_path(key).read_bytes() == b"retained capture"
+
+    moved = tmp_path / "relocated"
+    original.rename(moved)
+    new_paths = paths_type.from_market_db(moved / "market.db")
+    assert new_paths.object_path(key) == moved / "market.db.sec-research" / "objects" / "abc.txt"
+    assert new_paths.object_path(key).read_bytes() == b"retained capture"
+    assert not old_paths.object_path(key).exists()
+
+
+@pytest.mark.parametrize(
+    "key",
+    [
+        "objects/sha256/ab/abcdef0123.html",
+        "text/canonical-1_utf8.txt",
+        "objects/a..b",
+        "objects/%2e%2e.txt",
+        "objects/\u6587\u672c.txt",
+    ],
+    ids=["nested-hash", "canonical-text", "embedded-dots", "literal-percent", "unicode-name"],
+)
+def test_safe_relative_object_keys_are_resolved_without_writes(tmp_path, key):
+    paths = _paths_type().from_market_db(tmp_path / "market.db")
+    assert paths.object_path(key) == tmp_path / "market.db.sec-research" / key
+    assert list(tmp_path.iterdir()) == []
+
+
+@pytest.mark.parametrize(
+    "key",
+    [
+        pytest.param("", id="empty"),
+        pytest.param(".", id="dot"),
+        pytest.param("..", id="parent"),
+        pytest.param("../escape", id="parent-prefix"),
+        pytest.param("objects/../../escape", id="nested-traversal"),
+        pytest.param("objects/../body", id="contained-traversal"),
+        pytest.param("./body", id="dot-prefix"),
+        pytest.param("objects/./body", id="dot-component"),
+        pytest.param("objects//body", id="empty-component"),
+        pytest.param("objects/body/", id="trailing-separator"),
+        pytest.param("/outside/body", id="posix-absolute"),
+        pytest.param("//server/share/body", id="forward-unc"),
+        pytest.param("C:/outside/body", id="windows-forward-drive"),
+        pytest.param(r"C:\outside\body", id="windows-drive"),
+        pytest.param("C:body", id="windows-drive-relative"),
+        pytest.param("C:", id="windows-drive-only"),
+        pytest.param(r"\outside", id="windows-rooted"),
+        pytest.param(r"\\server\share\body", id="windows-unc"),
+        pytest.param(r"\\?\C:\outside", id="windows-extended-drive"),
+        pytest.param(r"\\?\UNC\server\share\body", id="windows-extended-unc"),
+        pytest.param(r"\\.\device", id="windows-device-path"),
+        pytest.param(r"objects\..\escape", id="windows-traversal"),
+        pytest.param(r"objects\body", id="windows-separator"),
+        pytest.param("objects/C:body", id="nested-drive-or-stream"),
+        pytest.param("objects/body:stream", id="alternate-stream"),
+        pytest.param("objects/body\x00", id="nul"),
+        pytest.param("objects/body\n", id="newline"),
+        pytest.param("objects/\x1fbody", id="control-character"),
+        pytest.param("objects/body\x7f", id="delete-character"),
+        pytest.param("objects/body.", id="trailing-dot"),
+        pytest.param("objects/body ", id="trailing-space"),
+        pytest.param("objects/CON", id="reserved-device"),
+        pytest.param("objects/nul.txt", id="reserved-device-extension"),
+        pytest.param("AUX/body", id="reserved-directory"),
+        pytest.param("objects/COM1", id="reserved-port"),
+        pytest.param("objects/a?b", id="question-mark"),
+        pytest.param("objects/a*b", id="asterisk"),
+        pytest.param("objects/a<b", id="left-angle"),
+        pytest.param("objects/a>b", id="right-angle"),
+        pytest.param('objects/a"b', id="double-quote"),
+        pytest.param("objects/a|b", id="pipe"),
+        pytest.param(None, id="null"),
+        pytest.param(1, id="integer"),
+        pytest.param(b"objects/body", id="bytes"),
+        pytest.param(Path("objects/body"), id="path-object"),
+    ],
+)
+def test_object_path_rejects_unsafe_or_malformed_keys(tmp_path, key):
+    paths = _paths_type().from_market_db(tmp_path / "market.db")
+    with pytest.raises(ValueError):
+        paths.object_path(key)
+    assert list(tmp_path.iterdir()) == []
+
+
+@pytest.mark.parametrize(
+    "kind", ["directory", "file", "dangling", "chain", "prefix-sibling", "capture-root"]
+)
+def test_object_path_rejects_symlink_escape(tmp_path, kind):
+    paths = _paths_type().from_market_db(tmp_path / "market.db")
+    root = tmp_path / "market.db.sec-research"
+    outside = tmp_path / ("market.db.sec-research-other" if kind == "prefix-sibling" else "outside")
+    outside.mkdir()
+    (outside / "body").write_bytes(b"outside sentinel")
+    if kind == "capture-root":
+        root.symlink_to(outside, target_is_directory=True)
+        key = "body"
+    else:
+        root.mkdir()
+        if kind == "file":
+            (root / "link").symlink_to(outside / "body")
+            key = "link"
+        elif kind == "dangling":
+            (root / "link").symlink_to(outside / "missing", target_is_directory=True)
+            key = "link/body"
+        elif kind == "chain":
+            (root / "link").symlink_to(root / "second", target_is_directory=True)
+            (root / "second").symlink_to(outside, target_is_directory=True)
+            key = "link/body"
+        else:
+            (root / "link").symlink_to(outside, target_is_directory=True)
+            key = "link/body"
+    with pytest.raises(ValueError):
+        paths.object_path(key)
+    assert (outside / "body").read_bytes() == b"outside sentinel"
+    assert not (outside / "missing").exists()
+
+
+def test_object_path_rejects_preexisting_capture_root_symlink(tmp_path):
+    paths_type = _paths_type()
+    outside = tmp_path / "outside"
+    outside.mkdir()
+    (outside / "body").write_bytes(b"outside sentinel")
+    root = tmp_path / "market.db.sec-research"
+    root.symlink_to(outside, target_is_directory=True)
+    paths = paths_type.from_market_db(tmp_path / "market.db")
+    assert paths.capture_root == root
+    with pytest.raises(ValueError):
+        paths.object_path("body")
+    assert (outside / "body").read_bytes() == b"outside sentinel"
+
+
+def test_object_path_allows_symlinks_that_stay_beneath_the_capture_root(tmp_path):
+    paths = _paths_type().from_market_db(tmp_path / "market.db")
+    root = tmp_path / "market.db.sec-research"
+    (root / "objects").mkdir(parents=True)
+    (root / "objects" / "body").write_bytes(b"inside capture")
+    (root / "alias").symlink_to("objects", target_is_directory=True)
+    assert paths.object_path("alias/body") == root / "objects" / "body"
+    assert paths.object_path("alias/body").read_bytes() == b"inside capture"
+
+
+def test_object_path_does_not_accept_a_symlink_to_the_root_as_an_object(tmp_path):
+    paths = _paths_type().from_market_db(tmp_path / "market.db")
+    root = tmp_path / "market.db.sec-research"
+    root.mkdir()
+    (root / "alias").symlink_to(".", target_is_directory=True)
+    with pytest.raises(ValueError):
+        paths.object_path("alias")
+
+
+def test_object_path_rejects_symlink_loops_as_invalid_keys(tmp_path):
+    paths = _paths_type().from_market_db(tmp_path / "market.db")
+    root = tmp_path / "market.db.sec-research"
+    root.mkdir()
+    (root / "first").symlink_to("second")
+    (root / "second").symlink_to("first")
+    with pytest.raises(ValueError):
+        paths.object_path("first/body")
diff --git a/tests/test_security_lifecycle_current.py b/tests/test_security_lifecycle_current.py
index c2ea346b..515e6286 100644
--- a/tests/test_security_lifecycle_current.py
+++ b/tests/test_security_lifecycle_current.py
@@ -60,41 +60,41 @@ def test_current_reviews_account_for_unpersisted_missing_and_recovered_cases(tmp
     assert by_ticker["GONE"]["next_action"]["kind"] == "recheck"
     assert by_ticker["OLD"]["finding"] == "old_listing_inactive"
     assert by_ticker["OLD"]["next_action"]["kind"] == "recheck"  # No persisted assessment yet.
     assert by_ticker["OLD"]["collection"] == {"state": "tracking", "sources": ["manual_lists"]}
     assert by_ticker["NEW"]["issuer_name"] == "Synthetic issuer"
     history = service.list_current_reviews(at=later, view="history")
     assert [row["ticker"] for row in history["items"]] == ["RECOVER"]
     assert history["items"][0]["finding"] == "active"
     assert history["items"][0]["next_action"]["kind"] == "none"
 
 
 def test_current_review_and_list_share_one_closed_projection(tmp_path):
     c = context(tmp_path)
     service = reader(c["market"], c["profile"], c["sources"])
     row = service.list_current_reviews(at=NOW)["items"][0]
     assert set(row) == {"review_id", "case_ids", "ticker", "issuer_name", "bucket", "finding", "reason", "collection",
                         "listing", "continuation", "observed_at", "next_check_at", "diagnostics", "next_action", "source_checks", "source_notices"}
     assert row["next_action"]["kind"] == "review_removal"
     assert row["next_action"]["assessment_id"] == c["assessment_id"]
     assert row["next_action"]["state"] == "not_prepared"
-    assert service.get_current_review(row["review_id"], at=NOW) == {"version": 1, "as_of": NOW, "item": row, "web_runs": []}
+    assert service.get_current_review(row["review_id"], at=NOW) == {"version": 1, "as_of": NOW, "item": row}
     text = json.dumps(row)
     for private in ("snapshot_sha256", "source_locator", "_ordinal", "canonical_payload", "decision_provenance", "BBG", "source_ref"):
         assert private not in text
     assert {check["provider"] for check in row["source_checks"]} == {"massive", "eodhd", "nasdaq"}
     assert sorted((check["check"], check["status"]) for check in row["source_checks"] if check["provider"] == "massive") == [
         ("delisting", "inactive"), ("otc", "not_found"), ("stocks", "not_found")]
 
 
 def test_applied_removal_keeps_unresolved_continuation_in_attention(tmp_path):
     c = context(tmp_path)
     receipt = confirm(c, prepare(c))
     result = current(c)
     assert result["counts"] == {"attention": 1, "history": 0}
     row = result["items"][0]
     assert row["reason"] == "continuation_followup_pending"
     assert row["collection"] == {"state": "not_tracking", "sources": []}
     assert row["next_action"]["state"] == "applied"
     assert row["next_action"]["current_effects_match"] is True
     assert row["next_action"]["transition_id"] == receipt["transition_id"]
     assert row["next_action"]["kind"] == "recheck"
@@ -310,41 +310,43 @@ def test_always_active_coverage_expires_instead_of_staying_green(tmp_path):
     market, profile = stores(tmp_path)
     ProviderCheckStore(profile).record(ticker="LIVE", at=NOW, evidence=(active("LIVE"),), diagnostics={})
     result = reader(market, profile, lambda: {"LIVE": ("manual_lists",)}).list_current_reviews(at="2026-09-15T01:00:00Z")
     assert result["coverage"] == {"tracked": 1, "confirmed_active": 0, "unconfirmed": 1}
     assert result["items"][0]["finding"] == "unresolved"
 
 
 def test_research_reads_exactly_the_same_current_projection_and_no_mutation_tool(tmp_path, monkeypatch):
     from src.tools import security_lifecycle_tools as tools
     from src.tools.registry import create_default_registry
     c = context(tmp_path)
     service = reader(c["market"], c["profile"], c["sources"])
     original_list, original_get = service.list_current_reviews, service.get_current_review
     expected = original_list(at=NOW)
     monkeypatch.setattr(service, "list_current_reviews", lambda **kwargs: original_list(at=NOW, **kwargs))
     monkeypatch.setattr(service, "get_current_review", lambda review_id: original_get(review_id, at=NOW))
     monkeypatch.setattr(tools, "SecurityLifecycleReadService", lambda **kwargs: service)
     payload = tools.list_security_lifecycle_reviews()
     assert payload == {"status": "ok", **expected}
     review_id = payload["items"][0]["review_id"]
-    assert tools.get_security_lifecycle_review(review_id) == {"status": "ok", **original_get(review_id, at=NOW)}
+    detail = tools.get_security_lifecycle_review(review_id)
+    assert detail == {"status": "ok", "version": 1, "as_of": NOW, "item": payload["items"][0]}
+    assert original_get(review_id, at=NOW) == {key: value for key, value in detail.items() if key != "status"}
     registry = create_default_registry()
     assert registry.get("list_security_lifecycle_cases") is None
     assert registry.get("get_security_lifecycle_case") is None
     assert registry.get("confirm_security_lifecycle_review") is None
 
 
 def test_current_source_checks_keep_both_nasdaq_directories_identifiable(tmp_path):
     row = current(context(tmp_path))["items"][0]
     assert {check["directory"] for check in row["source_checks"] if check["provider"] == "nasdaq"} == {
         "nasdaq_listed", "other_listed"}
     assert all(check["directory"] is None for check in row["source_checks"] if check["provider"] != "nasdaq")
 
 
 def test_current_action_keeps_the_receipt_kind_for_an_honest_resume_prompt(tmp_path, monkeypatch):
     from tests.test_security_lifecycle_review import stage_approval
     c = context(tmp_path)
     stage_approval(c, monkeypatch)
     row = current(c)["items"][0]
     assert row["next_action"]["kind"] == "resume"
     assert row["next_action"]["transition_kind"] == "terminal_delisting"
diff --git a/tests/test_security_lifecycle_population.py b/tests/test_security_lifecycle_population.py
index e1284ed1..541d7838 100644
--- a/tests/test_security_lifecycle_population.py
+++ b/tests/test_security_lifecycle_population.py
@@ -56,40 +56,70 @@ def persist(profile, observation):
 
 
 def active(ticker, *, figi=FIGI, venue="XNYS", security_type="CS", at=NOW):
     return _evidence(replace(record("massive_reference", "active", ticker=ticker, figi=figi),
                              primary_exchange=venue, security_type=security_type, issuer_cik="0000000001", retrieved_at=at))
 
 
 def terminal(ticker):
     return tuple(_evidence(replace(row, ticker=ticker)) for row in terminal_records())
 
 
 def manifest(market, profile, *, at=NOW):
     from src.security_lifecycle_population import read_population_manifest
     return read_population_manifest(market, profile, at=at)
 
 
 def review_for(result, case_id):
     return next(row for row in result["reviews"] if case_id in row["case_ids"])
 
 
+@pytest.mark.parametrize("journal_installed", (False, True))
+def test_population_material_contains_only_current_reference_owners(tmp_path, journal_installed):
+    from src.lifecycle_investigation.schema import install_journal
+    from src.security_lifecycle_population import build_population_manifest, read_population_snapshot
+
+    market, profile = stores(tmp_path)
+    persist(profile, sec(market, "OLD", "retained"))
+    if journal_installed:
+        with sqlite3.connect(profile) as conn:
+            install_journal(conn, at=NOW)
+    snapshot = read_population_snapshot(market, profile, at=NOW)
+    assert set(snapshot["material"]) == {"market_observations", "profile_tables", "identity_tables", "composed_cases", "schemas"}
+    retention = build_population_manifest(snapshot)["retention"]
+    assert "web_journal" not in retention
+    assert retention["table_counts"]["security_lifecycle_cases"] == 1
+
+
+@pytest.mark.parametrize("field", ("web_journal_inventory", "unreviewed_retention"))
+def test_population_manifest_rejects_unexpected_material_even_when_sealed(tmp_path, field):
+    from src.security_lifecycle_population import LifecyclePopulationUnavailable, build_population_manifest, read_population_snapshot
+
+    market, profile = stores(tmp_path)
+    snapshot = read_population_snapshot(market, profile, at=NOW)
+    snapshot["material"][field] = {"installed": False, "runs": [], "calls": [], "actions": [], "pages": [], "results": [], "acceptances": []}
+    unsigned = {key: snapshot[key] for key in ("version", "at", "material")}
+    snapshot["sha256"] = hashlib.sha256(json.dumps(unsigned, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False).encode()).hexdigest()
+    with pytest.raises(LifecyclePopulationUnavailable, match="population_material_invalid"):
+        build_population_manifest(snapshot)
+
+
 @pytest.mark.parametrize("journal_installed", (False, True))
 def test_population_manifest_accounts_for_all_three_input_populations(tmp_path, journal_installed):
     from src.lifecycle_investigation.schema import install_journal
 
     market, profile = stores(tmp_path)
     matched = persist(profile, sec(market, "MIX", "matched"))
     observation_only = sec(market, "NEW", "not-persisted")
     missing = persist(profile, {"source": "sec_edgar", "source_ref": "gone", "ticker": "GONE"})
     checks = ProviderCheckStore(profile)
     checks.record(ticker="RECOVER", at=NOW, evidence=(), diagnostics={})
     later = "2026-09-05T01:01:00Z"
     checks.record(ticker="RECOVER", at=later, evidence=(active("RECOVER", at=later),), diagnostics={})
     checks.record(ticker="LIVE", at=NOW, evidence=(active("LIVE"),), diagnostics={})
     checks.record(ticker="MIX", at=NOW, evidence=terminal("MIX"), diagnostics={})
     if journal_installed:
         with sqlite3.connect(profile) as conn:
             install_journal(conn, at=NOW)
     result = manifest(market, profile, at=later)
     provider_id = case_id_for("listing_authority", "listing:MIX", "MIX")
     recovered_id = case_id_for("listing_authority", "listing:RECOVER", "RECOVER")
diff --git a/tests/test_sqlite_backup.py b/tests/test_sqlite_backup.py
new file mode 100644
index 00000000..639d9e4e
--- /dev/null
+++ b/tests/test_sqlite_backup.py
@@ -0,0 +1,183 @@
+"""Shared SQLite backup safety and its current installation consumer."""
+
+from contextlib import closing
+import hashlib
+from importlib import import_module
+from pathlib import Path
+import sqlite3
+import stat
+
+import pytest
+
+
+ROOT = Path(__file__).resolve().parents[1]
+AT = "2026-09-08T00:00:00Z"
+
+
+def backup_owner():
+    assert (ROOT / "src/sqlite_backup.py").is_file(), "shared SQLite backup owner is missing"
+    return import_module("src.sqlite_backup")
+
+
+@pytest.mark.parametrize("name", ("lifecycle_web_schema.py", "lifecycle_web_migration.py"))
+def test_current_journal_has_no_obsolete_schema_owner(name):
+    assert not (ROOT / "src" / name).exists()
+
+
+def test_backup_captures_committed_wal_rows_without_changing_the_source(tmp_path):
+    backup_connection = backup_owner().backup_connection
+    source = tmp_path / "source.db"
+    backup = tmp_path / "private" / "backup.db"
+    with closing(sqlite3.connect(source)) as conn:
+        assert conn.execute("PRAGMA journal_mode=WAL").fetchone() == ("wal",)
+        conn.execute("PRAGMA wal_autocheckpoint=0")
+        conn.execute("CREATE TABLE retained(id INTEGER PRIMARY KEY, payload BLOB)")
+        conn.commit()
+        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
+        conn.execute("INSERT INTO retained VALUES (1,?)", (b"committed-in-wal",))
+        conn.commit()
+        assert Path(str(source) + "-wal").stat().st_size > 0
+        with closing(sqlite3.connect(source.as_uri() + "?immutable=1", uri=True)) as main_only:
+            assert main_only.execute("SELECT * FROM retained").fetchall() == []
+        assert backup_connection(conn, backup) is None
+        assert conn.execute("SELECT * FROM retained").fetchall() == [(1, b"committed-in-wal")]
+        with closing(sqlite3.connect(backup)) as restored:
+            assert restored.execute("PRAGMA integrity_check").fetchall() == [("ok",)]
+            assert restored.execute("SELECT * FROM retained").fetchall() == [(1, b"committed-in-wal")]
+    assert stat.S_IMODE(backup.stat().st_mode) == 0o600
+
+
+def test_backup_never_overwrites_an_existing_destination(tmp_path):
+    backup_connection = backup_owner().backup_connection
+    existing = tmp_path / "backup.db"
+    existing.write_bytes(b"owned-backup")
+    with closing(sqlite3.connect(":memory:")) as conn:
+        with pytest.raises(FileExistsError):
+            backup_connection(conn, existing)
+    assert existing.read_bytes() == b"owned-backup"
+
+
+def test_backup_rejects_a_dangling_destination_symlink(tmp_path):
+    backup_connection = backup_owner().backup_connection
+    target = tmp_path / "must-not-create.db"
+    backup = tmp_path / "backup.db"
+    backup.symlink_to(target)
+    with closing(sqlite3.connect(":memory:")) as conn:
+        with pytest.raises(FileExistsError):
+            backup_connection(conn, backup)
+    assert backup.is_symlink() and not target.exists()
+
+
+@pytest.mark.parametrize("failure", (False, True))
+def test_backup_explicitly_closes_destination_on_success_and_failure(tmp_path, monkeypatch, failure):
+    module = backup_owner()
+    real_connect = sqlite3.connect
+    destinations = []
+
+    class FailingBackup(sqlite3.Connection):
+        def backup(self, destination, **kwargs):
+            raise OSError("synthetic backup failure")
+
+    def connect(*args, **kwargs):
+        destination = real_connect(*args, **kwargs)
+        destinations.append(destination)
+        return destination
+
+    with closing(real_connect(":memory:", factory=FailingBackup if failure else sqlite3.Connection)) as conn:
+        monkeypatch.setattr(module.sqlite3, "connect", connect)
+        if failure:
+            with pytest.raises(OSError, match="synthetic backup failure"):
+                module.backup_connection(conn, tmp_path / "backup.db")
+        else:
+            module.backup_connection(conn, tmp_path / "backup.db")
+        assert conn.execute("SELECT 1").fetchone() == (1,)
+    assert len(destinations) == 1
+    with pytest.raises(sqlite3.ProgrammingError, match="closed database"):
+        destinations[0].execute("SELECT 1")
+
+
+def test_current_installation_backup_preserves_unrelated_rows_and_is_idempotent(tmp_path):
+    from src.lifecycle_investigation.migration import apply_installation, preview_installation
+    from src.lifecycle_investigation.schema import verify_journal
+    from tests.test_security_lifecycle_population import persist, stores
+
+    _, profile = stores(tmp_path)
+    case_id = persist(profile, {"source": "sec_edgar", "source_ref": "retained", "ticker": "OLD"})
+    with closing(sqlite3.connect(profile)) as conn:
+        conn.execute("CREATE TABLE unrelated_payload(id INTEGER PRIMARY KEY, raw BLOB)")
+        conn.execute("INSERT INTO unrelated_payload VALUES (1,?)", (b"opaque-private-fixture",))
+        conn.commit()
+    before = preview_installation(profile)
+    backup = tmp_path / "backup.db"
+    result = apply_installation(profile, backup_path=backup, approval_sha256=before["approval_sha256"], at=AT, app_stopped=True)
+    assert result["changed"] is True
+    assert result["backup_sha256"] == hashlib.sha256(backup.read_bytes()).hexdigest()
+    assert stat.S_IMODE(backup.stat().st_mode) == 0o600
+    assert preview_installation(backup) == before
+    assert "opaque-private" not in str(result)
+    with closing(sqlite3.connect(profile)) as conn:
+        verify_journal(conn)
+        assert conn.execute("SELECT raw FROM unrelated_payload").fetchall() == [(b"opaque-private-fixture",)]
+        assert conn.execute("SELECT case_id FROM security_lifecycle_cases").fetchall() == [(case_id,)]
+    current = preview_installation(profile)
+    assert apply_installation(profile, backup_path=tmp_path / "unused.db", approval_sha256=current["approval_sha256"], at=AT, app_stopped=True)["changed"] is False
+    assert not (tmp_path / "unused.db").exists()
+
+
+def test_current_installation_requires_stopped_app_before_opening_any_store(tmp_path):
+    from src.lifecycle_investigation.migration import apply_installation
+
+    with pytest.raises(ValueError, match="investigation_install_app_stop_required"):
+        apply_installation(tmp_path / "missing.db", backup_path=tmp_path / "backup.db", approval_sha256="a" * 64, at=AT, app_stopped=False)
+    assert not tuple(tmp_path.iterdir())
+
+
+@pytest.mark.parametrize("change", ("after_backup", "backup_exists"))
+def test_current_installation_rejects_backup_races_and_existing_destinations(tmp_path, monkeypatch, change):
+    from src.lifecycle_investigation import migration
+    from tests.test_security_lifecycle_population import stores
+
+    _, profile = stores(tmp_path)
+    before = migration.preview_installation(profile)
+    backup = tmp_path / "backup.db"
+    if change == "backup_exists":
+        backup.write_bytes(b"must-retain")
+        expected = FileExistsError
+    else:
+        original = migration.preview_installation
+
+        def changed(path):
+            result = original(path)
+            with closing(sqlite3.connect(profile)) as conn:
+                conn.execute("CREATE TABLE independent_data(value TEXT)")
+                conn.commit()
+            return result
+
+        monkeypatch.setattr(migration, "preview_installation", changed)
+        expected = ValueError
+    with pytest.raises(expected):
+        migration.apply_installation(profile, backup_path=backup, approval_sha256=before["approval_sha256"], at=AT, app_stopped=True)
+    if change == "backup_exists":
+        assert backup.read_bytes() == b"must-retain"
+    with closing(sqlite3.connect(profile)) as conn:
+        assert not conn.execute("SELECT 1 FROM sqlite_master WHERE name='lifecycle_investigation_jobs'").fetchone()
+
+
+def test_current_installation_rolls_back_schema_on_postflight_failure(tmp_path, monkeypatch):
+    from src.lifecycle_investigation import migration, schema
+    from tests.test_security_lifecycle_population import stores
+
+    _, profile = stores(tmp_path)
+    before = migration.preview_installation(profile)
+    backup = tmp_path / "backup.db"
+    original = schema.verify_journal
+
+    def fail(conn):
+        original(conn)
+        raise ValueError("synthetic_postflight_failure")
+
+    monkeypatch.setattr(schema, "verify_journal", fail)
+    with pytest.raises(ValueError, match="synthetic_postflight_failure"):
+        migration.apply_installation(profile, backup_path=backup, approval_sha256=before["approval_sha256"], at=AT, app_stopped=True)
+    assert migration.preview_installation(profile) == before
+    assert migration.preview_installation(backup) == before
diff --git a/tests/test_ticker_identity_history.py b/tests/test_ticker_identity_history.py
index d2ff8753..0e9d25d6 100644
--- a/tests/test_ticker_identity_history.py
+++ b/tests/test_ticker_identity_history.py
@@ -78,84 +78,67 @@ def test_approved_review_snapshot_survives_later_assessment_and_source_changes(t
     packet = prepare(c)
     confirm(c, packet)
     with sqlite3.connect(c["profile"]) as conn:
         conn.execute("UPDATE security_lifecycle_assessments SET conclusion='Different later text',impact_summary='Different effect'")
     c["checks"].record(ticker="OLD", at="2026-09-07T01:00:00Z", evidence=(), diagnostics={}, blockers=())
     before = rows(c)
     decision = history(c, monkeypatch)[0].get("decision")
     assert decision is not None
     assert decision["summary"] == "Reviewed explicit delisting with current trading checks; no acquirer alias is authorized."
     assert decision["impact"] == "Stop collection, preserve history."
     assert {source["name"] for source in decision["sources"]} == {"Massive", "EODHD", "Nasdaq"}
     assert rows(c) == before
 
 
 @pytest.mark.parametrize("provider,auth,model", [
     ("anthropic", "claude_code_oauth", "claude-sonnet-5"), ("anthropic", "api_key", "claude-sonnet-5"),
     ("openai", "chatgpt_oauth", "gpt-5.6-luna"), ("openai", "api_key", "gpt-5.6-luna"),
 ])
 def test_target_investigation_history_names_the_recorded_model_and_cited_news_only(tmp_path, monkeypatch, provider, auth, model):
     from tests.test_lifecycle_investigation_review import context
-    from src.lifecycle_web_review import prepare, confirm
+    from src.lifecycle_investigation.review import prepare, confirm
     c = context(tmp_path, provider=provider, auth=auth)
     options = TransitionOptions(execute_on=None)
     packet = prepare(c["service"], c["run_id"], options=options)
     assert confirm(c["service"], c["run_id"], packet_sha256=packet["packet_sha256"], action=packet["action"],
         options=options, before_write=lambda: None)["status"] == "applied"
     def forbidden(*args, **kwargs):
         raise AssertionError("History must not re-run source parsing or current model admission")
     monkeypatch.setattr("src.lifecycle_investigation.adoption.validated_read", forbidden)
     monkeypatch.setattr("src.lifecycle_investigation.adoption.as_adoption", forbidden)
     monkeypatch.setattr("src.security_lifecycle_web_contract.validate_selection", forbidden)
     before = rows(c)
     decision = history(c, monkeypatch)[0].get("decision")
     assert decision is not None
     assert decision["summary"] == "The common stock no longer trades."
     assert decision["method"] == "llm_investigation"
     assert decision["approval_authority"] == "attended_user"
     assert decision["model"] == {"provider": provider, "auth_mode": auth, "model": model}
     assert decision["event_date"] == "2026-09-01"
     assert len(decision["sources"]) == 1, "Citations to different passages of one article are one source"
     assert decision["sources"][0]["kind"] == "local_news"
     assert decision["sources"][0]["url"] == "https://issuer.example/notice"
     assert decision["gaps"] == []
     assert rows(c) == before
     assert not any(key in json.dumps(decision) for key in ("credential_id", "remote_id", "sha256", "passage_id", "run_id"))
 
 
-def test_legacy_web_investigation_history_preserves_auth_model_and_source_link(tmp_path, monkeypatch):
-    from tests.test_lifecycle_web_review import context, prepare, confirm
-    c = context(tmp_path, provider="anthropic", auth="claude_code_oauth")
-    confirm(c, prepare(c))
-    monkeypatch.setattr("src.lifecycle_web_store.LifecycleWebStore._decode_page",
-        lambda *a, **k: (_ for _ in ()).throw(AssertionError("Do not parse full source bodies in history")))
-    before = rows(c)
-    decision = history(c, monkeypatch)[0].get("decision")
-    assert decision is not None
-    assert decision["method"] == "llm_investigation"
-    assert decision["model"] == {"provider": "anthropic", "model": "claude-sonnet-5", "auth_mode": "claude_code_oauth"}
-    assert decision["summary"] == "The old NASDAQ listing ended; no claim is made about a replacement."
-    assert decision["sources"][0]["url"] == "https://ir.example.com/notice"
-    assert decision["sources"][0]["observed_at"] == "2026-09-06T01:00:00Z"
-    assert rows(c) == before
-
-
 def test_acknowledgement_and_reversal_keep_original_explanation(tmp_path, monkeypatch):
     c = setup_workflow(tmp_path)
     transition = legacy(c)
     item = history(c, monkeypatch)[0]
     assert item.get("decision") is not None
     browser = client(c, monkeypatch, [])
     response = browser.post(f"/security-lifecycle/transition-activity/{item['activity_id']}/acknowledge")
     assert response.status_code == 200, response.text
     assert response.json()["decision"] == item["decision"]
     with sqlite3.connect(c["profile"]) as conn:
         assert TickerIdentityTransitionStore(conn).reverse(transition["transition_id"], trigger="attended_user")["status"] == "reversed"
     assert [row["activity_type"] for row in history(c, monkeypatch)] == ["reversed", "applied"]
     assert all(row["decision"] == item["decision"] for row in history(c, monkeypatch))
 
 
 def test_missing_bound_provider_receipt_does_not_borrow_a_later_receipt(tmp_path, monkeypatch):
     c = setup_workflow(tmp_path)
     legacy(c)
     with sqlite3.connect(c["profile"]) as conn:
         damage_saved_rows(conn, "security_lifecycle_provider_checks", "DELETE FROM security_lifecycle_provider_checks")
@@ -177,82 +160,134 @@ def test_unsealed_legacy_assessment_is_qualified_even_when_its_fingerprint_still
         conn.execute("UPDATE security_lifecycle_assessments SET conclusion='Replacement explanation',effective_date='2025-06-01'")
     after = history(c, monkeypatch)[0]["decision"]
     assert "legacy_assessment_unsealed" in after["gaps"]
     assert after["summary"] == "Replacement explanation"
     assert after["sources"] == before["sources"]
 
 
 @pytest.mark.parametrize("bad", ["[]", "null", '"bad"', '{"snapshot_format":1,"observation":[]}'])
 def test_malformed_unbound_provider_observation_cannot_poison_bound_history(tmp_path, monkeypatch, bad):
     c = setup_workflow(tmp_path)
     legacy(c)
     before = history(c, monkeypatch)[0]["decision"]
     c["checks"].record(ticker="OLD", at="2026-09-07T01:00:00Z", evidence=(), diagnostics={})
     with sqlite3.connect(c["profile"]) as conn:
         damage_saved_rows(conn, "security_lifecycle_provider_checks",
             "UPDATE security_lifecycle_provider_checks SET observation_json=? WHERE rowid=(SELECT max(rowid) FROM security_lifecycle_provider_checks)", (bad,))
     assert history(c, monkeypatch)[0]["decision"] == before
 
 
 @pytest.mark.parametrize("field,value", [("url", "https://unrelated.example/forged"),
-    ("retrieved_at", "2026-09-06T02:00:00Z"), ("text_sha256", "f" * 64), ("body_sha256", "f" * 64)])
-def test_legacy_web_source_metadata_must_match_the_approved_passage_digest(tmp_path, monkeypatch, field, value):
-    from tests.test_lifecycle_web_review import context, prepare, confirm
-    c = context(tmp_path, provider="anthropic", auth="claude_code_oauth")
-    confirm(c, prepare(c))
+    ("retrieved_at", "2026-09-08T02:00:00Z"), ("text", "Unbound replacement quotation")])
+def test_current_history_requires_approved_passage_digest_even_when_result_is_resigned(tmp_path, monkeypatch, field, value):
+    from src.lifecycle_journal_codec import canonical_json, digest_json
+    from src.security_lifecycle_review import packet_digest, confirmation_for
+    from src.ticker_identity_transition import profile_snapshot_sha256
+    from tests.test_lifecycle_investigation_review import context, prepare, confirm
+    c = context(tmp_path)
+    applied = confirm(c, prepare(c))
     with sqlite3.connect(c["profile"]) as conn:
-        damage_saved_rows(conn, "lifecycle_web_pages",
-            "UPDATE lifecycle_web_pages SET page_json=json_set(page_json,?,?)", (f"$.{field}", value))
+        saved = json.loads(conn.execute("SELECT payload_json FROM lifecycle_investigation_results").fetchone()[0])
+        saved["validated"]["passages"][0][field] = value
+        result_digest = digest_json(saved)
+        damage_saved_rows(conn, "lifecycle_investigation_results",
+            "UPDATE lifecycle_investigation_results SET payload_json=?,payload_sha256=?", (canonical_json(saved), result_digest))
+        store = TickerIdentityTransitionStore(conn)
+        preview = store.get(applied["transition_id"])["approved_preview"]
+        receipt = preview["review_confirmation"]
+        packet = receipt["packet"]
+        packet["web"]["result_sha256"] = result_digest
+        receipt["packet_sha256"] = packet["packet_sha256"] = packet_digest(packet)
+        digest = preview["preview_sha256"] = profile_snapshot_sha256(preview)
+        conn.execute("UPDATE ticker_identity_transitions SET approved_preview_json=?,approved_preview_sha256=? WHERE transition_id=?",
+            (json.dumps(preview), digest, applied["transition_id"]))
+        assert confirmation_for(store.get(applied["transition_id"]))["packet"] == packet
     decision = history(c, monkeypatch)[0]["decision"]
-    assert decision["summary"] == "The old NASDAQ listing ended; no claim is made about a replacement."
+    assert decision["summary"] is None
     assert decision["sources"] == []
-    assert decision["gaps"] == ["sources_missing"]
+    assert decision["gaps"] == ["record_invalid"]
 
 
 @pytest.mark.parametrize("published", ["September 1, 2026", "Sep 1, 2026 08:30 ET"])
 def test_history_preserves_valid_publisher_date_text_from_the_real_investigation(tmp_path, monkeypatch, published):
     from tests.test_lifecycle_investigation_review import context
-    from src.lifecycle_web_review import prepare, confirm
+    from src.lifecycle_investigation.review import prepare, confirm
     publisher_date_fixture(monkeypatch, published)
     c = context(tmp_path, provider="anthropic", auth="claude_code_oauth")
     options = TransitionOptions(execute_on=None)
     packet = prepare(c["service"], c["run_id"], options=options)
     confirm(c["service"], c["run_id"], packet_sha256=packet["packet_sha256"], action=packet["action"], options=options, before_write=lambda: None)
     decision = history(c, monkeypatch)[0]["decision"]
     assert decision["gaps"] == []
     assert decision["sources"][0]["published_at"] == published
 
 
 def test_damaged_approval_does_not_erase_activity_or_offer_a_fabricated_explanation(tmp_path, monkeypatch):
     from tests.test_security_lifecycle_review import context, prepare, confirm
     c = context(tmp_path)
     confirm(c, prepare(c))
     with sqlite3.connect(c["profile"]) as conn:
         value = json.loads(conn.execute("SELECT approved_preview_json FROM ticker_identity_transitions").fetchone()[0])
         value["review_confirmation"]["packet"]["finding"]["conclusion"] = "Unbound false story"
         conn.execute("UPDATE ticker_identity_transitions SET approved_preview_json=?", (json.dumps(value),))
     before = rows(c)
     result = history(c, monkeypatch)
     assert len(result) == 1 and result[0]["activity_type"] == "applied"
     assert result[0].get("decision") is not None
     assert result[0]["decision"]["summary"] is None
     assert result[0]["decision"]["gaps"] == ["record_invalid"]
     assert "Unbound false story" not in json.dumps(result)
     assert rows(c) == before
 
 
+@pytest.mark.parametrize("binding", ["missing", "null", "wrong_lane", "unbound_result"])
+def test_current_history_rejects_resigned_missing_or_corrupt_investigation_binding(tmp_path, monkeypatch, binding):
+    from src.security_lifecycle_review import packet_digest, confirmation_for
+    from src.ticker_identity_transition import profile_snapshot_sha256
+    from tests.test_lifecycle_investigation_review import context, prepare, confirm
+    c = context(tmp_path)
+    applied = confirm(c, prepare(c))
+    with sqlite3.connect(c["profile"]) as conn:
+        store = TickerIdentityTransitionStore(conn)
+        transition = store.get(applied["transition_id"])
+        preview = transition["approved_preview"]
+        receipt = preview["review_confirmation"]
+        packet = receipt["packet"]
+        if binding == "missing":
+            packet.pop("web")
+        elif binding == "null":
+            packet["web"] = None
+        elif binding == "wrong_lane":
+            packet["lane"] = "manual"
+        else:
+            packet["web"]["result_sha256"] = "0" * 64
+        receipt["packet_sha256"] = packet["packet_sha256"] = packet_digest(packet)
+        digest = preview["preview_sha256"] = profile_snapshot_sha256(preview)
+        conn.execute("UPDATE ticker_identity_transitions SET approved_preview_json=?,approved_preview_sha256=? WHERE transition_id=?",
+            (json.dumps(preview), digest, applied["transition_id"]))
+        assert confirmation_for(store.get(applied["transition_id"]))["packet"] == packet
+    before = rows(c)
+    items = history(c, monkeypatch)
+    assert len(items) == 1 and items[0]["activity_type"] == "applied"
+    decision = items[0]["decision"]
+    assert decision["summary"] is None and decision["sources"] == []
+    assert decision["gaps"] == ["record_invalid"]
+    assert decision["method"] != "manual_review"
+    assert rows(c) == before
+
+
 @pytest.mark.parametrize("lane", ("provider", "llm"))
 def test_shared_frontend_fixture_is_owned_by_real_persisted_history(tmp_path, monkeypatch, lane):
     if lane == "provider":
         c = setup_workflow(tmp_path, event_available=False)
         legacy(c)
     else:
         from tests.test_lifecycle_investigation_review import context
-        from src.lifecycle_web_review import prepare, confirm
+        from src.lifecycle_investigation.review import prepare, confirm
         publisher_date_fixture(monkeypatch, "September 1, 2026")
         c = context(tmp_path, provider="anthropic", auth="claude_code_oauth")
         options = TransitionOptions(execute_on=None)
         packet = prepare(c["service"], c["run_id"], options=options)
         confirm(c["service"], c["run_id"], packet_sha256=packet["packet_sha256"], action=packet["action"],
             options=options, before_write=lambda: None)
     expected = json.loads((Path(__file__).parent / "fixtures/ticker_history_decisions_v1.json").read_text())[lane]
     assert history(c, monkeypatch)[0]["decision"] == expected

```
