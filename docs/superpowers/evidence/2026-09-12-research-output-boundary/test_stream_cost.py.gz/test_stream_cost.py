"""Synthetic latency observation for realistic-length bearer representations."""
import hashlib
import json
import time

from src.agents.shared.output_boundary import OutputGuard


def test_synthetic_bearer_small_delta_cost():
    secret = "eyJ" + "".join(hashlib.sha256(str(i).encode()).hexdigest() for i in range(32))
    text = ("Consolidated Statements of Operations 391035000000. " * 200)
    guard = OutputGuard([secret])
    stream = guard.stream()
    start = time.monotonic()
    parts = []
    first_emission = None
    for offset in range(0, len(text), 3):
        part = stream.feed(text[offset:offset + 3])
        if part and first_emission is None:
            first_emission = offset + 3
        parts.append(part)
    parts.append(stream.finish())
    elapsed = time.monotonic() - start
    assert "".join(parts) == text
    print(json.dumps({"synthetic_secret_chars": len(secret), "public_chars": len(text),
                      "delta_chars": 3, "seconds": round(elapsed, 4),
                      "first_emission_input_chars": first_emission}))
