"""Scoped I2 audit: shield/drain outcomes not covered by a successful close.

Run this file only through run_checks.py backend mode. No SDK, provider, or
credential access: a synthetic iterator exercises close outcome precedence.
"""

import asyncio

import pytest

from src.agents.shared.events import AgentEvent, EventType
from src.agents.shared.output_boundary import OutputGuard, current_output_guard, output_scope
from src.agents.shared.output_events import protect_events


@pytest.mark.parametrize("close_result", ["success", "error", "self-cancel"])
@pytest.mark.parametrize("cancel_consumer", [False, True], ids=["normal", "cancel-twice"])
def test_shielded_close_settles_and_preserves_outcome(close_result, cancel_consumer):
    async def drive():
        entered, release = asyncio.Event(), asyncio.Event()
        guard = OutputGuard(["review-synthetic-credential"])
        close_tasks, close_guards, outcomes, events = [], [], [], []

        class Raw:
            step = 0

            def __aiter__(self):
                return self

            async def __anext__(self):
                self.step += 1
                if self.step == 1:
                    return AgentEvent(EventType.text, {"content": "rev"})
                if self.step == 2:
                    return AgentEvent(EventType.done, {"answer": "Public answer"})
                raise AssertionError("advanced after terminal")

            async def aclose(self):
                close_tasks.append(asyncio.current_task())
                close_guards.append(current_output_guard())
                entered.set()
                await release.wait()
                close_guards.append(current_output_guard())
                if close_result == "error":
                    raise RuntimeError("synthetic close failure")
                if close_result == "self-cancel":
                    raise asyncio.CancelledError("synthetic close cancellation")

        stream = protect_events(Raw(), guard=guard)
        with output_scope("consumer-only-credential") as consumer_guard:
            async def consume():
                try:
                    async for event in stream:
                        assert current_output_guard() is consumer_guard
                        events.append(event)
                except BaseException as exc:
                    outcomes.append(exc)
                    raise
                finally:
                    assert current_output_guard() is consumer_guard
                    await stream.aclose()

            consumer = asyncio.create_task(consume())
            try:
                await asyncio.wait_for(entered.wait(), timeout=2)
                if cancel_consumer:
                    for message in ("first consumer cancellation", "second consumer cancellation"):
                        consumer.cancel(message)
                        await asyncio.sleep(0)
                        assert not consumer.done(), "consumer detached in-flight cleanup"
                release.set()
                result = await asyncio.wait_for(asyncio.gather(consumer, return_exceptions=True), timeout=2)
                assert len(close_tasks) == 1
                assert close_tasks[0].done()
                assert close_guards == [guard, guard]
                if cancel_consumer:
                    assert isinstance(outcomes[0], asyncio.CancelledError)
                    assert outcomes[0].args == ("first consumer cancellation",)
                    assert events == []
                elif close_result == "error":
                    assert type(outcomes[0]) is RuntimeError
                    assert str(outcomes[0]) == "synthetic close failure"
                    assert events == []
                elif close_result == "self-cancel":
                    assert isinstance(outcomes[0], asyncio.CancelledError)
                    assert events == []
                else:
                    assert result == [None] and outcomes == []
                    assert [(event.type, event.data) for event in events] == [
                        (EventType.text, {"content": "rev"}),
                        (EventType.done, {"answer": "Public answer"}),
                    ]
                await stream.aclose()
                with pytest.raises(StopAsyncIteration):
                    await anext(stream)
                assert current_output_guard() is consumer_guard
                assert len(close_tasks) == 1
            finally:
                release.set()
                if not consumer.done():
                    consumer.cancel()
                await asyncio.gather(consumer, return_exceptions=True)
                await stream.aclose()

    asyncio.run(drive())
    assert current_output_guard() is None
