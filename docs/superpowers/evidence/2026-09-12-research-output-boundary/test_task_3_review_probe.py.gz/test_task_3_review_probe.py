"""Review-only probe: cancel a real adapter wrapper during terminal cleanup.

Plan: use the existing synthetic ChatGPT producer, pause only its fake client's
close, and cancel once after cleanup starts. Compare with normal close. Run
only this file via the Task 3 run_checks.py backend offline runner.
"""

import asyncio

import pytest

from tests.test_research_output_events import SECRET, collect, make_producer, terminal
from tests.test_task_runtime_binding import isolated


@pytest.mark.parametrize("cancel", [False, True], ids=["normal-close", "cancel-during-close"])
def test_client_cleanup_completes_before_wrapper_forgets_upstream(make_producer, monkeypatch, cancel):
    from src.auth_drivers import chatgpt_oauth_driver as driver

    producer = make_producer("chatgpt", answer="Public answer")
    execution_client = driver._execution_client

    async def drive():
        entered, release = asyncio.Event(), asyncio.Event()
        original_closes = []

        def client_factory(token):
            client = execution_client(token)
            close = client.close
            original_closes.append(close)

            async def delayed_close():
                entered.set()
                await release.wait()
                await close()

            client.close = delayed_close
            return client

        monkeypatch.setattr(driver, "_execution_client", client_factory)
        stream = producer.stream()
        consumer = asyncio.create_task(collect(stream))
        try:
            await asyncio.wait_for(entered.wait(), timeout=2)
            if cancel:
                consumer.cancel()
                await asyncio.sleep(0)
            release.set()
            await asyncio.wait_for(asyncio.gather(consumer, return_exceptions=True), timeout=2)
            await stream.aclose()
            assert producer.closed, "client close was interrupted and the wrapper cannot retry cleanup"
        finally:
            release.set()
            if not consumer.done():
                consumer.cancel()
            await asyncio.gather(consumer, return_exceptions=True)
            await stream.aclose()
            for close in original_closes:
                await close()

    asyncio.run(drive())


def test_client_cleanup_error_is_guarded_before_diagnostic_logging(make_producer, monkeypatch, caplog):
    from src.auth_drivers import chatgpt_oauth_driver as driver

    producer = make_producer("chatgpt", answer="Public answer")
    execution_client = driver._execution_client

    def client_factory(token):
        client = execution_client(token)
        close = client.close

        async def failing_close():
            await close()
            raise RuntimeError("synthetic cleanup error: " + SECRET)

        client.close = failing_close
        return client

    monkeypatch.setattr(driver, "_execution_client", client_factory)
    with caplog.at_level("WARNING", logger="src.auth_drivers.chatgpt_oauth_driver"):
        events = asyncio.run(collect(producer.stream()))
    assert terminal(events)["answer"] == "Public answer"
    assert producer.closed
    assert SECRET not in caplog.text, "captured bearer reached cleanup diagnostic traceback"
